--- STEAMODDED HEADER
--- MOD_NAME: Foiled Wild Deck
--- MOD_ID: foiledwildDeck
--- MOD_AUTHOR: [itiseren]
--- MOD_DESCRIPTION: foiled wild deck

----------------------------------------------
------------MOD CODE -------------------------

local Backapply_to_runRef = Back.apply_to_run
function Back.apply_to_run(arg_56_0)
	Backapply_to_runRef(arg_56_0)

	if arg_56_0.effect.config.foilwild then
		G.E_MANAGER:add_event(Event({
			func = function()
				for iter_57_0 = #G.playing_cards, 1, -1 do
					sendDebugMessage(G.playing_cards[iter_57_0].base.id)

					G.playing_cards[iter_57_0]:set_ability(G.P_CENTERS.m_wild)

					G.playing_cards[iter_57_0]:set_edition({
						polychrome = true
					}, true, true)
				end

				return true
			end
		}))
	end
end

local loc_def = {
	["name"]="Foiled Wild Deck",
	["text"]={
		[1]="All the cards are",
		[2]="Wild",
		[3]="and Foiled"
	},
}

local foilwild = SMODS.Deck:new("Foiled Wild Deck", "foiledwildDeck", {foilwild = true}, {x = 4, y = 2}, loc_def)
foilwild:register()

----------------------------------------------
------------MOD CODE END----------------------
