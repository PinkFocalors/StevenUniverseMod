return {
    NegativesOnly = false,
    StackAnything = false,
	UnsafeMode = false
}
