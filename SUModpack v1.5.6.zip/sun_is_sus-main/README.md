Renames The Sun tarot card to The Sus and replaces its texture

Requires [Malverk](https://github.com/Eremel/Malverk)
