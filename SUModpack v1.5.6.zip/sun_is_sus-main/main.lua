AltTexture({
    key = 'sus',
    set = 'Tarot',
    path = 'sus.png',
    keys = {
        'c_sun'
    },
    localization = {
        'c_sun'
    }
})
TexturePack({
    key = 'sus',
    textures = {
        'sus_sus'
    }
})
