return {
    descriptions = {
        alt_texture = {
            alt_tex_sus_sus = {
                c_sun = {
                    name = "The Sus"
                }
            }
        },
        texture_packs = {
            texpack_sus_sus = {
                name = "When the impostor is Sun",
                text = {
                    "Renames {C:tarot}The Sun{} tarot",
                    "card to {C:tarot}The Sus",
                    "and replaces its texture",
                }
            }
        }
    }
}
