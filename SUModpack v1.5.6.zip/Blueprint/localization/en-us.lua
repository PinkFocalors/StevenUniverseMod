return {
    misc = {
        dictionary = {
            testtesttest = "hi hello hi",
        }
    }
}