return {
    descriptions = {
        Sleeve = {
            sleeve_finity_challenger_alt = { 
                name = "Challenger's Sleeve",
                text = { "{C:attention}+1{} Joker slot",
				"Start run with {C:attention,T:v_retcon}Retcon",
				"and extra {C:money}6$",
				"All {C:attention}Big Blinds{} are {C:attention}Showdowns", 
				}
            }
        }
    }
}