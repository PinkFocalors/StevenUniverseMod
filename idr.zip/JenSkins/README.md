# Jen's Skins

An assortment of various playing card skins for Balatro.

Currently there is only one, but there will be more soon.

- **Simplified** : Reduces the card art to be just a symbol accompanied with a letter/number.
![image](https://github.com/user-attachments/assets/39ee1d46-c6da-4905-8a10-a574e337ce0a)
![image](https://github.com/user-attachments/assets/b0e0ea26-ce72-457e-a306-9e8c5d609807)

# How to install

This guide will assume you've already installed DeckSkins+.

Open the .zip and simply drag the **assets** and **skins** folders directly onto **DeckSkins+**'s folder, or you can open up the folder and drag them inside.

![image](https://github.com/user-attachments/assets/c6bd72b8-a788-4bbb-8dc8-585ee468e6c9)
