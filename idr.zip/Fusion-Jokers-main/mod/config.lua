return {
    ["block_components"] = true,
}