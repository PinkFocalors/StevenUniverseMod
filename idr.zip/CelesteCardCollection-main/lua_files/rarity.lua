SMODS.Gradient({
    key="ccc_secret", 
    colours={HEX("ffc0ff"), HEX("80d3cb"), HEX("4f0a81")},
    cycle=33
})
SMODS.Rarity({
    key="secret",
    badge_colour=SMODS.Gradients.ccc_secret,
})


SMODS.Gradient({
    key="ccc_what", 
    colours={HEX("A70874"), HEX("3A631D"), HEX("4B4660"),
             HEX("146158"), HEX("315E68"), HEX("7A4B06")}
})
SMODS.Rarity({
    key="what",
    badge_colour=SMODS.Gradients.ccc_what,
    default_weight=0.033
})

--SMODS.Rarity{
--    key = "secret",
--    loc_txt = {name = 'Secret'},
--    badge_colour = HEX('ffc0ff'),-
--}

sendDebugMessage("[CCC] Rarities loaded")
