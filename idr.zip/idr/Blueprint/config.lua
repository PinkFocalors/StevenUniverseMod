
return {
    INTERNAL_debug = false,
    brainstorm = true,
    blueprint = true,
}

