--- Global Definitions
--- These are run independent of what Jokers you have

return {
    Replace = {
    }
}