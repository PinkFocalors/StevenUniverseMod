return {
	misc = {
		dictionary = {
			jdis_enabled = "Activé",
			jdis_hide_by_default = "Masquer par défaut",
			jdis_hide_empty = "Masquer vide",
			jdis_disable_collapse = "Désactiver repli",
			jdis_disable_perishable = "Désactiver Périssable",
			jdis_disable_rental = "Désactiver Location",
			jdis_modifiers = "Modificateurs",
			jdis_reminders = "Rappels",
			jdis_extras = "Extras",
			jdis_default_display = "Défaut",
			jdis_small_display = "Réduit",
			jdis_active = "Actif!",
			jdis_inactive = "Inactif",
			jdis_all_suits = "Toutes les couleurs"
		},
		v_dictionary = {
			jdis_odds = "#1# chance(s) sur #2#"
		}
	},
}