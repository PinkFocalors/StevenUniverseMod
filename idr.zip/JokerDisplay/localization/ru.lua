return {
	misc = {
		dictionary = {
			jdis_enabled = "Включено",
			jdis_hide_by_default = "Скрывать по умолчанию",
			jdis_hide_empty = "Скрывать пустые",
			jdis_disable_collapse = "Отключить сворачивание",
			jdis_disable_perishable = "Отключить Временные",
			jdis_disable_rental = "Отключить Арендуемые",
			jdis_modifiers = "Модификаторы",
			jdis_reminders = "Напоминания",
			jdis_extras = "Экстра",
			jdis_default_display = "По умолчанию",
			jdis_small_display = "Свернутый вид",
			jdis_active = "Активно!",
			jdis_inactive = "Неактивно",
			jdis_all_suits = "Все масти"
		},
		v_dictionary = {
			jdis_odds = "#1# к #2#"
		}
	},
}
