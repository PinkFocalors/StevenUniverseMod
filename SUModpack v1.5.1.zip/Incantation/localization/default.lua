return {
    misc = {
        dictionary = {
            incant_negatives_only = "Stack negatives only",
            incant_stack_anything = "Allow stack & divide on any consumable",
			incant_unsafe_mode = 'Unsafe mode'
        }
    }
}