return {
    right_mouse_button_click = true,
    right_mouse_button_hold = true,
    middle_mouse_button_click = true,
    middle_mouse_button_hold = false,
    middle_mouse_button_up = true,
    middle_mouse_button_down = true,
    x1_click = true,
    x2_click = true,
    
    swap_mouse_wheel_up_with_down = false,
    swap_x1_with_x2 = false,
    swap_mouse_wheel_with_x1_x2 = false,

    b_click_or_hold = true,
    rightstick_click_or_hold = true,
    left_shoulder_click = true,
    left_shoulder_click = true,
    swap_a_with_b = false,
}