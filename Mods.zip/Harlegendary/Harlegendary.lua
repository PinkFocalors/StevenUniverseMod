--- STEAMODDED HEADER
--- MOD_NAME: Harlequin Legendary Pack
--- MOD_ID: Harlegendary
--- MOD_AUTHOR: [Pepperfaced]
--- MOD_DESCRIPTION: Harlequin texture pack for legendary jokers

----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.Harlegendary()

    jokers = {
        j_caino = { pos = 0 },
        j_triboulet = { pos = 1 },
        j_yorick = { pos = 2 },
        j_chicot = { pos = 3 },
        j_perkeo = { pos = 4 }
    }

    SMODS.Atlas {
            key = "LegendaryJokers",
            path = "LegendaryJokers.png",
            px = 71,
            py = 95
    }

    for jkr,data in pairs(jokers) do
        SMODS["Joker"]:take_ownership(jkr, { atlas = "LegendaryJokers", 
            pos = { x = 0 + data.pos, y = 0 },
            soul_pos = { x = 0 + data.pos, y = 1 }}, true)
    end

end

----------------------------------------------
------------MOD CODE END----------------------