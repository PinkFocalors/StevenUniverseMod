return {
    selected = {}
}