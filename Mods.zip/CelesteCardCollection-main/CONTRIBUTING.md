# Info for jokers:

Each joker should be it's own file somewhere in the jokers folder (subfolders are okay) that returns the config you would give to SMODS.Joker()
We also have 3 custom config values:

```
credit = {
		art = "???",
		code = "???",
		concept = "???"
	}
```
credit lets you set the credit values that are shown next to the joker, we keep track of who made the Aart, code and had the concept idea.
Please be sure to keep this up to date!

```
description = "This joker immediately wins the game"
```
descripton is used for automatic readme creation. WIP.
