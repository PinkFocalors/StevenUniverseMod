return {
	default_rows = {
		reminder = true,
		extra = true,
		modifiers = true,
	},
	hide_by_default = false,
	hide_empty = true,
	shift_to_hide = false,
	disable_collapse = false,
	disable_perishable = false,
	disable_rental = false,
	small_rows = {
		reminder = false,
		extra = false,
		modifiers = true,
	},
	enabled = true,
}
