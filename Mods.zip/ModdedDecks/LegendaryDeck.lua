--- STEAMODDED HEADER
--- MOD_NAME: Legendary Deck
--- MOD_ID: LegendaryDeck
--- MOD_AUTHOR: [UnknownEternity]
--- MOD_DESCRIPTION: Adds 1 deck (Legendary Deck) and 1 legendary joker (Charon).

----------------------------------------
--------------- MOD CODE ---------------
----------------------------------------
function add_card_to_deck(arg_card)
    arg_card:add_to_deck()
    table.insert(G.playing_cards, arg_card)
    G.deck.config.card_limit = G.deck.config.card_limit + 1
    G.deck:emplace(arg_card)
end

function add_joker_to_game(arg_key, arg_loc, arg_joker)
    arg_joker.key = arg_key
    arg_joker.order = #G.P_CENTER_POOLS["Joker"] + 1

    G.P_CENTERS[arg_key] = arg_joker
    table.insert(G.P_CENTER_POOLS["Joker"], arg_joker)
    table.insert(G.P_JOKER_RARITY_POOLS[arg_joker.rarity], arg_joker)

    G.localization.descriptions.Joker[arg_key] = arg_loc
end

function SMODS.INIT.LegendaryDeck()
    local jokers = {
        j_charon = {order = 0, unlocked = true, discovered = true, blueprint_compat = true, eternal_compat = true, rarity = 4, cost = 20, name = "Charon", set = "Joker", effect = "", config = {extra = {repeats = 1, dollars = 100}}, pos = {x = 3, y = 4}}
    }

    local texts = {
        j_charon = {
            name = "Charon",
            text = {"Retrigger all played {C:attention}Gold{} cards.",
                    "Prevents death if you pay {C:money}$100{}"}
        }
    }

    for key,val in pairs(jokers) do
        add_joker_to_game(key, texts[key], val)
    end
end

local card_calculate_joker_ref = Card.calculate_joker
function Card.calculate_joker(self, context)
    local calculate_joker_ref = card_calculate_joker_ref(self, context)

    if self.ability.name == "Charon" then
        if context.game_over and G.GAME.dollars >= self.ability.extra.dollars then
            G.E_MANAGER:add_event(Event({
                func = function()
                    G.hand_text_area.blind_chips:juice_up()
                    G.hand_text_area.game_chips:juice_up()
                    ease_dollars(self.ability.extra.dollars * -1, true)
                    play_sound("tarot1")
                    return true
                end
            })) 
            return {
                message = "Saved by Charon",
                saved = true,
                colour = G.C.RED
            }
        elseif context.repetition and context.cardarea == G.play then
            if context.other_card.ability.name == 'Gold Card' then
                return {
                    message = localize('k_again_ex'),
                    repetitions = self.ability.extra.repeats,
                    card = self
                }
            end
        end
    end

    return calculate_joker_ref
end

local back_apply_to_run_ref = Back.apply_to_run
function Back.apply_to_run(arg_legend)
    back_apply_to_run_ref(arg_legend)

    if arg_legend.effect.config.legendary then
        G.E_MANAGER:add_event(Event({
            func = function()
                -- code for cards
                local cards_by_suit = {
                    ["S"] = {},
                    ["H"] = {},
                    ["C"] = {},
                    ["D"] = {}
                }

                for idx = #G.playing_cards, 1, -1 do
                    sendDebugMessage(G.playing_cards[idx].base.suit .. G.playing_cards[idx].base.id)

                    local suit = string.sub(G.playing_cards[idx].base.suit, 1, 1)
                    local rank = tostring(G.playing_cards[idx].base.id)
                    if rank == "1" then rank = "T"
                    elseif rank == "10" then rank = "T"
                    elseif rank == "11" then rank = "J"
                    elseif rank == "12" then rank = "Q"
                    elseif rank == "13" then rank = "K"
                    elseif rank == "14" then rank = "A"
                    end
                  --G.playing_cards[idx]:set_base(G.P_CARDS[suit .. "_" .. rank])

                    G.playing_cards[idx]:set_ability(G.P_CENTERS.m_steel, true, false)
                    G.playing_cards[idx]:set_seal("Red", true, true)

                    table.insert(cards_by_suit[suit], G.playing_cards[idx])
                end

                for idx = #cards_by_suit["S"], 1, -1 do
                    local card = copy_card(cards_by_suit["S"][idx], nil, nil, 1, false)
                    card:set_ability(G.P_CENTERS.m_glass, true, false)
                    card:set_edition({polychrome = true}, true, true)
                    card:set_seal(nil, true, true)
                    add_card_to_deck(card)
                end
                for idx = #cards_by_suit["H"], 1, -1 do
                    local card = copy_card(cards_by_suit["H"][idx], nil, nil, 1, false)
                    card:set_ability(G.P_CENTERS.m_glass, true, false)
                    card:set_edition({polychrome = true}, true, true)
                    card:set_seal(nil, true, true)
                    add_card_to_deck(card)
                end
                for idx = #cards_by_suit["C"], 1, -1 do
                    local card = copy_card(cards_by_suit["C"][idx], nil, nil, 1, false)
                    card:set_ability(G.P_CENTERS.m_glass, true, false)
                    card:set_edition({polychrome = true}, true, true)
                    card:set_seal(nil, true, true)
                    add_card_to_deck(card)
                end
                for idx = #cards_by_suit["D"], 1, -1 do
                    local card = copy_card(cards_by_suit["D"][idx], nil, nil, 1, false)
                    card:set_ability(G.P_CENTERS.m_glass, true, false)
                    card:set_edition({polychrome = true}, true, true)
                    card:set_seal(nil, true, true)
                    add_card_to_deck(card)
                end

                G.starting_deck_size = #G.playing_cards

                -- code for jokers
                local joker_list = {
                    "j_blueprint",
                    "j_brainstorm",
                    "j_rocket",
                    "j_ring_master"
                }
                for idx = 1, #joker_list, 1 do
                    local card = create_card('Joker', G.jokers, false, nil, nil, nil, joker_list[idx], nil)
                    if idx <= (#joker_list / 2) then
                        card:set_edition({foil = true}, true, true)
                    else
                        card:set_edition({holo = true}, true, true)
                    end
                    card:set_eternal(true)
                    card:add_to_deck()
                    G.jokers:emplace(card)
                end

                joker_list = {}
                for key,val in pairs(G.P_CENTERS) do
                    if string.sub(key, 1, 2) == "j_" and val["rarity"] ~= nil and val["rarity"] >= 4 then
                        table.insert(joker_list, key)
                    end
                end
                for idx = 1, #joker_list, 1 do
                    local card = create_card('Joker', G.jokers, true, nil, nil, nil, joker_list[idx], nil)
                    card:set_edition({negative = true}, true, true)
                    card:set_eternal(true)
                    card:add_to_deck()
                    G.jokers:emplace(card)
                end
                return true
            end
        }))
    end
end

local loc_def_legend = {
    ["name"]="Legendary Deck",
    ["text"]={
        [1]="Doubled and enhanced deck.",
        [2]="Start with extra jokers:",
        [3]="{C:attention,T:j_blueprint}Blueprint{}, {C:attention,T:j_brainstorm}Brainstorm{}, {C:attention,T:j_rocket}Rocket{}, {C:attention,T:j_ring_master}Showman{}",
        [4]="- with Foil/Holographic & Eternal",
        [5]="Also all legendary jokers",
        [6]="- with Negative & Eternal"
    }
}

local d_legend = SMODS.Deck:new("Legendary_Deck", "legend", {legendary = true}, {x = 4, y = 1}, loc_def_legend)
d_legend:register()
----------------------------------------
------------- MOD CODE END -------------
----------------------------------------