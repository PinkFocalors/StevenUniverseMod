--- STEAMODDED HEADER
--- MOD_NAME: Steven Universe Mod
--- MOD_ID: SUMOD
--- MOD_AUTHOR: [Pink Focalors]
--- MOD_DESCRIPTION: Trying to add some Steven Universe themed jokers. Also contains other mods as dependencies. ExampleMod, JellyJokers, Salt & Panasco, etc.
--- PREFIX: sbeven
--- PRIORITY: -9999
--- BADGE_COLOR: #FF00FF
--- BADGE_TEXT_COLOR: #DC143C

----------------------------------------------
------------MOD CODE -------------------------

local localize_ref = localize
function localize(args, misc_cat)
    local ret = localize_ref(args, misc_cat) or ""
    -- Remove color codes from info_queue tooltip names
    if args and type(args) == 'table' and args.type == "name_text" then
        if string.len(ret) > 2 and string.sub(ret, string.len(ret) - 1, string.len(ret)) == "{}" then
            ret = string.sub(ret, 1, string.len(ret) - 2)
        end
        if string.sub(ret, 1, 3) == "{C:" then
            local _, _, _, real_name = string.find(ret, "{C:(.*)}(.*)")
            ret = real_name
        end
    end

    return ret
end

local seppy_quotes = {
    'Where\'s the smoke?',
    'Let me at \'em!'
}


if not _G._joker_quotes_seeded then
    math.randomseed(os.time())
    _G._joker_quotes_seeded = true
end
--[[function Card:speak(text, col)
	if type(text) == 'table' then text = text[math.random(#text)] end
	card_eval_status_text(self, 'extra', nil, nil, nil, {message = text, colour = col or G.C.FILTER})
end]]

-- Registers the mod icon
SMODS.Atlas { -- modicon
  key = 'modicon',
  px = 32,
  py = 32,
  path = 'modicon.png'
}
---- Modded Rarities
SMODS.Rarity{
    key = "Diamond", 
    loc_txt = { name = "Diamond" },
    badge_colour = HEX("FF69B4"),  -- pink background (hot pink)
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{
    key = "Gem", 
    loc_txt = { name = "Gem" },
    badge_colour = HEX("5dade2"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = true },
    default_weight = 1
}

SMODS.Rarity{
    key = "AGem", 
    loc_txt = { name = "Anomalous Gem" },
    badge_colour = HEX("373D49"),  -- background color 
    badge_text_colour = HEX("FFFFFF"),  -- text color
    pools = { ["Joker"] = true },
    default_weight = 0
}

SMODS.Rarity{
    key = "CGem", 
    loc_txt = { name = "Crystal Gem" },
    badge_colour = HEX("5dade2"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = true },
    default_weight = 1
}

SMODS.Rarity{
    key = "Hidden", 
    loc_txt = { name = "Crystal Gem" },
    badge_colour = HEX("5dade2"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{
    key = "Hidden3", 
    loc_txt = { name = "Gem" },
    badge_colour = HEX("5dade2"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{
    key = "Off", 
    loc_txt = { name = "Off-Colors" },
    badge_colour = HEX("7f6a93"),  -- background color 
    badge_text_colour = HEX("c4b7d0"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{
    key = "PFusion", 
    loc_txt = { name = "Perfect Fusion" },
    badge_colour = HEX("FFD700"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{
    key = "Fusion", 
    loc_txt = { name = "Fusion" },
    badge_colour = HEX("40E0D0"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{
    key = "UFusion", 
    loc_txt = { name = "Unstable Fusion" },
    badge_colour = HEX("CCFF00"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{
    key = "Hidden2", 
    loc_txt = { name = "Unstable Fusion" },
    badge_colour = HEX("CCFF00"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = true },
    default_weight = 0.08
}

SMODS.Rarity{
    key = "Monster", 
    loc_txt = { name = "Corrupted" },
    badge_colour = HEX("CCFF00"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

SMODS.Rarity{ -- Just for Pale Rose
    key = "Unique", 
    loc_txt = { name = "Unique" },
    badge_colour = HEX("E8A2BE"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = true },
    default_weight = 0.5
}

SMODS.Rarity{
    key = "Human", 
    loc_txt = { name = "Human" },
    badge_colour = HEX("E8A2BE"),  -- background color 
    badge_text_colour = HEX("333333"),  -- text color
    pools = { ["Joker"] = true },
    default_weight = 1
}

SMODS.Rarity{
    key = "Unobtainable", 
    loc_txt = { name = "Unobtainable" },
    badge_colour = HEX("000000"),  -- background color 
    badge_text_colour = HEX("FF0000"),  -- text color
    pools = { ["Joker"] = false },
    default_weight = 0
}

-- Atlas for most Jokers
SMODS.Atlas{ key = 'Jokers', path = 'Jokers.png', px = 71, py = 95 }
-- Atlas for the Diamond Ships
SMODS.Atlas{ key = 'DiamondShips', path = 'DiamondShips.png', px = 71, py = 95 }
-- Atlas for the Destabilized Enhancement
SMODS.Atlas{ key = 'Unstable', path = 'Enhancement.png', px = 71, py = 95 }
-- Atlas for the Controlled Enhancement
SMODS.Atlas{ key = 'Control', path = 'Control.png', px = 71, py = 95 }
-- Atlas for Bluebird Azurite
SMODS.Atlas{ key = 'Bluebird', path = 'Bluebird.png', px = 71, py = 95 }
-- Atlas for Bluebird's Ice Cutlass
SMODS.Atlas{ key = 'Cutlass', path = 'Cutlass.png', px = 71, py = 95 }
-- Atlas for Aquamarine
SMODS.Atlas{ key = 'Aquamarine', path = 'Aquamarine.png', px = 71, py = 95 }
-- Atlas for the Bubbled Enhancement CARD
SMODS.Atlas{ key = 'Bubble', path = 'Bubble.png', px = 71, py = 95 }
-- Atlas for Bubbled Enhancement (i think)
SMODS.Atlas{ key = 'Bubbled', path = 'Bubbled.png', px = 71, py = 95 }
-- Atlas for Yellow's Destabilizer
SMODS.Atlas{ key = 'Destabilizer', path = 'Destabilizer.png', px = 71, py = 95 }
-- Atlas for Aquamarine's Wand
SMODS.Atlas{ key = 'Wand', path = 'Wand.png', px = 71, py = 95 }
-- Atlas for The Cluster
SMODS.Atlas{ key = 'Cluster', path = 'Cluster.png', px = 71, py = 95 }
-- Atlas for the Corruption Consumable & Joker
SMODS.Atlas{ key = 'Consumables', path = 'Consumables.png', px = 71, py = 95 }
-- Atlas for Stevonnie
SMODS.Atlas{ key = "Stevonnie", path = "Stevonnie.png", px = 71, py = 95 }
-- Atlas for Lapis Lazuli
SMODS.Atlas{ key = "Lapis", path = "Lapis.png", px = 71, py = 95 }
-- Atlas for Ruby
SMODS.Atlas{ key = "Ruby", path = "Ruby.png", px = 71, py = 95 }
-- Atlas for Moonstone
SMODS.Atlas{ key = "moon", path = "Moonstone.png", px = 71, py = 95 }
-- Atlas for Bloodstone
SMODS.Atlas{ key = "blood", path = "Bloodstone.png", px = 71, py = 95 }
-- Atlas for Lars Barriga
SMODS.Atlas{ key = "Lars", path = "Lars.png", px = 71, py = 95 }
-- Atlas for Lars of the Stars
SMODS.Atlas{ key = "CLars", path = "Captain_Lars.png", px = 71,py = 95 }
-- Atlas for Padparadscha
SMODS.Atlas{ key = "Padparadscha", path = "Padparadscha.png", px = 71, py = 95 }
-- Atlas for The Rutile Twins
SMODS.Atlas{ key = "Rutile", path = "Rutile.png", px = 71, py = 95 }
-- Atlas for Fluorite
SMODS.Atlas{ key = "Fluorite", path = "Fluorite.png", px = 71, py = 95 }
-- Atlas for Blood Money
SMODS.Atlas{ key = "bloodM", path = "BloodMoney.png", px = 71, py = 95 }
-- Atlas for Spinel's Rejuvenator
SMODS.Atlas{ key = "Rejuvenator", path = "Rejuvenator.png", px = 71, py = 95 }
-- Atlas for Connie's Sword
SMODS.Atlas{ key = "ConnieW", path = "ConnieSword.png", px = 71, py = 95 }
-- Atlas for Stevonnie's Sword & Shield
SMODS.Atlas{ key = "StevonnieW", path = "StevonnieWeapons.png", px = 71, py = 95 }
-- Atlas for Steven's Shield
SMODS.Atlas{ key = "StevenS", path = "StevenShield.png", px = 71, py = 95 }
-- Atlas for Volleyball's Ribbon Wand
SMODS.Atlas{ key = "RibbonWand", path = "RibbonWand.png", px = 71, py = 95 }
-- Atlas for Mega Pearl's Drill-Ribbon Wand
SMODS.Atlas{ key = "DrillWand", path = "DrillWand.png", px = 71, py = 95 }
-- Atlas for Obisidian
SMODS.Atlas{ key = "Obsidian", path = "Obsidian.png", px = 71, py = 95 }
-- Atlas for Obsidian's Greatsword
SMODS.Atlas{ key = "ObsidianSword", path = "ObsidianSword.png", px = 71, py = 95 }
-- Atlas for Carbonado
SMODS.Atlas{ key = "Black", path = "BlackDiamond.png", px = 71, py = 95 }
-- Atlas for Pearl's Spear
SMODS.Atlas{ key = "PearlS", path = "PearlSpear.png", px = 71, py = 95 }
-- Atlas for Opal's Bow
SMODS.Atlas{ key = "OpalB", path = "OpalBow.png", px = 71, py = 95 }
-- Atlas for Ruby's Gauntlet
SMODS.Atlas{ key = "RubyG", path = "RubyArm.png", px = 71, py = 95 }
-- Atlas for Garnet's Gauntlets
SMODS.Atlas{ key = "Gauntlets", path = "Gauntlets.png", px = 71, py = 95 }
-- Atlas for Jasper's Helmet
SMODS.Atlas{ key = "JasperH", path = "JasperHelmet.png", px = 71, py = 95 }
-- Atlas for Peridot's Tablet
SMODS.Atlas{ key = "PeridotT", path = "PeridotTablet.png", px = 71, py = 95 }
-- Atlas for Amethyst's Whip
SMODS.Atlas{ key = "AmethystW", path = "AmethystWhip.png", px = 71, py = 95 }
-- Atlas for Turquoise (Aventurine)
SMODS.Atlas{ key = "Lapis&Peridot", path = "Turquoise.png", px = 71, py = 95 }
-- Atlas for Orange Spodumene (Coochie Gem)
SMODS.Atlas{ key = "Orange", path = "Orange.png", px = 71, py = 95 }
-- Atlas for BlackAuraQuartz (Carbonado & Black Pearl fusion)
SMODS.Atlas{ key = "Aura", path = "Black Aura Quartz.png", px = 71, py = 95 }
-- Atlas for Black Pearl 
SMODS.Atlas{ key = "Black Pearl", path = "Black Pearl.png", px = 71, py = 95 }
-- Atlas for Debut Carbonado (Carbonado v0)
SMODS.Atlas{ key = "CarbonadoDebut", path = "CarbonadoDebut.png", px = 71, py = 95 }
-- Atlas for Blue Aura Quartz (Blue Diamond & Blue Pearl fusion)
SMODS.Atlas{ key = "BlueAura", path = "BlueAuraQuartz.png", px = 71, py = 95 }
-- Atlas for Homeworld (Consumable)
SMODS.Atlas{ key = "Homeworld", path = "Homeworld.png", px = 71, py = 95 }
-- Atlas for Homeworld (Consumable)
SMODS.Atlas{ key = "Temple", path = "CrystalTemple.png", px = 71, py = 95 }
-- Atlas for Sepulcher Black Spinel
SMODS.Atlas{ key = "Seppy", path = "Seppy.png", px = 71, py = 95 }
-- Atlas for Thunder Arm
SMODS.Atlas{ key = "ThunderArm", path = "ThunderArm.png", px = 71, py = 95 }

---- Fusion Recipes
FusionJokers.fusions:add_fusion( -- Bloodstone Fusion
'j_sbeven_garnet', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_peridot', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_blood', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Blue Aura Quartz (Blue Diamond & Blue Pearl) Fusion
'j_sbeven_blue', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_blue_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_blue_aura', --result of fusion 
750 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Captain Lars Fusion
'j_sbeven_lars', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pale_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_clars', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Moonstone Fusion
'j_sbeven_sapphire', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_moon', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Moonstone Fusion 2
'j_sbeven_sapphire', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_volleyball', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_moon', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Monster Steven Fusion
'j_sbeven_corruption', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_steven', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_monster', --result of fusion 
1000 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Zebra Jasper Fusion
'j_sbeven_corruption', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_jasper', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_zebra', --result of fusion 
250 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- White Diamond Fusion
'j_sbeven_pale_rose', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pink', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_white', --result of fusion 
750 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Blue Diamond Fusion
'j_sbeven_lapis', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pale_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_blue', --result of fusion 
400 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Yellow Diamond Fusion
'j_sbeven_jasper', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pale_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_yellow', --result of fusion 
400 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Mega Pearl Fusion
'j_sbeven_pearl', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_volleyball', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_mega', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Stevonnie Fusion
'j_sbeven_steven', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_connie', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_stevonnie', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Healed Lapis Fusion
'j_sbeven_cracked_lapis', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pale_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_lapis', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Aventurine Fusion
'j_sbeven_lapis', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_peridot', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_aventurine', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Pink Diamond Fusion 1
'j_sbeven_rose', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pale_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_pink', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Pink Diamond Fusion 2
'j_sbeven_steven', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_pink', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Pink Diamond Fusion 3
'j_sbeven_steven', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pale_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_pink', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Pink Diamond Fusion 4
'j_sbeven_volleyball', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pale_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_pink', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Malachite Fusion
'j_sbeven_lapis', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_jasper', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_malachite', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Bluebird Fusion
'j_sbeven_aqua', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_ruby', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_bluebird', --result of fusion 
75 --cost to fuse
)

-- Fusions for Obsidian

FusionJokers.fusions:add_fusion( -- Obisidian Fusion 1 (Alexandrite & Steven)
'j_sbeven_alex', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_steven', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_obsidian', --result of fusion 
500 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Obsidian Fusion 2 (Alexandrite & Rose)
'j_sbeven_alex', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_rose', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_obsidian', --result of fusion 
500 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Obsidian Fusion 3 (Opal & Sunstone)
'j_sbeven_opal', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_sunstone', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_obsidian', --result of fusion 
500 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Obsidian Fusion 4 (Rainbow & Sugilite)
'j_sbeven_rainbow', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_sugilite', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_obsidian', --result of fusion 
500 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Obsidian Fusion 5 (Rainbow 2.0 & Sugilite)
'j_sbeven_rainbow2', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_sugilite', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_obsidian', --result of fusion 
500 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Obsidian Fusion 6 (Sardonyx & Smokey)
'j_sbeven_smokey', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_sardonyx', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_obsidian', --result of fusion 
500 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Obsidian Fusion 7 (Stevonnie & Alexandrite)
'j_sbeven_stevonnie', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_alex', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_obsidian', --result of fusion 
500 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Opal Fusion
'j_sbeven_pearl', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_amethyst', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_opal', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Opal Fusion 2
'j_sbeven_volleyball', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_amethyst', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_opal', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Garnet Fusion
'j_sbeven_ruby', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_sapphire', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_garnet', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Garnet Fusion 2
'j_sbeven_ruby', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pad', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_garnet', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Rhodonite Fusion
'j_sbeven_ruby', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_rhodonite_off', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Rhodonite Fusion 2
'j_sbeven_ruby', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_volleyball', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_rhodonite_off', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Alexandrite Fusion (Sugilite & Pearl)
'j_sbeven_sugilite', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_alex', --result of fusion 
250 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Alexandrite Fusion 2 (Sardonyx & Amethyst)
'j_sbeven_sardonyx', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_amethyst', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_alex', --result of fusion 
250 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Alexandrite Fusion 3 (Opal & Garnet)
'j_sbeven_opal', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_garnet', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_alex', --result of fusion 
250 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Sardonyx Fusion 1 (Rhodonite & Sapphire)
'j_sbeven_rhodonite_off', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_sapphire', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_sardonyx', --result of fusion 
125 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Sardonyx Fusion 2 (Garnet & Pearl)
'j_sbeven_garnet', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_sardonyx', --result of fusion 
125 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Sardonyx Fusion 3 (Ruby + Fusion of Pearl & Sapphire)
'j_sbeven_ruby', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_moon', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_sardonyx', --result of fusion 
125 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Sugilite Fusion 1 (Garnet & Amethyst)
'j_sbeven_garnet', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_amethyst', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_sugilite', --result of fusion 
125 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Rainbow Quartz Fusion (Rose & Pearl)
'j_sbeven_rose', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_rainbow', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Rainbow Quartz Fusion 2 (Rose & Volleyball)
'j_sbeven_rose', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_volleyball', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_rainbow', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Rainbow Quartz 2.0 Fusion (Steven & Pearl)
'j_sbeven_steven', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_rainbow2', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Rainbow Quartz 2.0 Fusion 2 (Steven & Volleyball)
'j_sbeven_steven', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_volleyball', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_rainbow2', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Smokey Quartz Fusion (Amethyst & Steven)
'j_sbeven_amethyst', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_steven', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_smokey', --result of fusion 
75 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Sunstone Fusion (Garnet & Steven)
'j_sbeven_garnet', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_steven', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_sunstone', --result of fusion 
125 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Sunstone Fusion (Garnet & Stevonnie)
'j_sbeven_garnet', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_stevonnie', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_sunstone', --result of fusion 
125 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Black Aura Quartz Fusion (CarbonadoDebut & Black Pearl)
'j_sbeven_black', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_black_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_aura', --result of fusion 
999 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Black Aura Quartz Fusion (Carbonado & Black Pearl)
'j_sbeven_carbonado', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_black_pearl', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_aura', --result of fusion 
999 --cost to fuse
)

FusionJokers.fusions:add_fusion( -- Zebra Jasper Fusion
'j_sbeven_corruption', --string, component joker's key
nil, --string, name of stat to carry into fusion
false, --boolean, is the carry stat in an "extra" table or not
'j_sbeven_spinel', -- same as 1, but for the other component joker
nil, -- same
false, -- same
'j_sbeven_seppy', --result of fusion 
777 --cost to fuse
)

SMODS.Tag {
    key = 'seppy_tag',
    atlas = 'modicon',
    loc_txt = {
        name = '{C:spectral}Anomalous Tag',
        text = {
            'Creates',
            '{C:spectral}Sepulcher Black Spinel',
            'in next shop.'
        }
    },
    pos = {x = 0, y = 0},
    apply = function(self, tag, context)
        if context.type == 'store_joker_create' then
            local card = create_card("Joker", context.area, nil, nil, nil, nil, "j_sbeven_seppy")
			create_shop_card_ui(card, "Joker", context.area)
			card.states.visible = false
			tag:yep("+", G.C.RED, function()
				card:start_materialize()
				card:set_cost()
				return true
			end)
            tag.triggered = true
            return card
        end
    end
}

SMODS.Enhancement({
    key    = "destabilized",
    atlas  = "Unstable",
    pos    = { x = 0, y = 0 },

    loc_txt = {
        name = "{C:diamonds}Destabilized",
        text = {
            "{C:white,X:chips}X#1#{} Chips",
            "{C:green}#2# in 3{} chance of",
            "being destroyed after scoring."
        }
    },

    config = {
      x_chips = 2,
      chance = 2,
    },
    weight = 5,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            if SMODS.pseudorandom_probability(card, 'group_0_24833e70', 1, card.ability.extra.odds, 'm_sbeven_destabilized') then
                card.should_destroy = true
            end
            return { x_chips = card.ability.extra.x_chips }
        end
    end,
    loc_vars = function(self, info_queue, card)
      return { vars = {
        card and card.ability.x_chips or self.config.x_chips,
        card and G.GAME.probabilities.normal,
        card and card.ability.chance or self.config.chance
      }}
    end,

    set_badges = function(self, card, badges)
      badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
    unlocked = true,
    discovered = true,
})

SMODS.Enhancement({
  key    = "controlled",
  atlas  = "Control",
  pos    = { x = 0, y = 0 },
  weight = 5,
  loc_txt = {
    name = "{C:dark_edition}Controlled",
    text = {
      "{C:white,X:mult}X#1#{} Mult & {C:white,X:chips}X#2#{} Chips",
      "{X:gold,C:white,E:1}$#3#{} when scored.",
      "{C:attention}Destroyed{} after scoring."
    }
  },
    config = {
        p_dollars = 12,
        extra = {
            x_chips = 4,
            x_mult = 4
        }
    },
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            card.should_destroy = true
            SMODS.calculate_effect({x_chips = card.ability.extra.x_chips}, card)
            SMODS.calculate_effect({x_mult = card.ability.extra.x_mult}, card)
        end
    end,
  loc_vars = function(self, info_queue, card)
    return { vars = {
      card and card.ability.x_mult  or self.config.x_mult,
      card and card.ability.x_chips or self.config.x_chips,
      self.config.p_dollars
    }}
  end,
  set_badges = function(self, card, badges)
    badges[#badges+1] = create_badge(
      "Steven Universe",
      G.C.PURPLE,
      G.C.EDITION,
      1
    )
  end,
  unlocked   = true,
  discovered = true,
})

SMODS.Enhancement({
    key = "bubbledE",
    atlas = "Bubbled",
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = "{C:hearts}Bubbled",
        text = {
            "{C:white,X:mult}X#1#{} Mult if held in hand",
        }
    },
    config = {
      x_mult = 2.5
    },
    weight = 5,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return { x_mult = card.ability.extra.x_mult }
        end
    end,
    loc_vars = function(self, info_queue, card)
      return { vars = { 
        card and card.ability.h_x_mult or self.config.h_x_mult,
      } }
    end,
    set_badges = function(self, card, badges)
      badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
})

SMODS.Atlas{ key = "Placeholder", path = "Textureless.png", px = 71, py = 95 }

SMODS.Joker{ --Reunited (Ruby & Sapphire's Wedding)
    key = 'reunited',
    loc_txt = {
        name = '{C:dark_edition}Reunited',
        text = {
            'Scored {C:hearts}#2#{} cards give {C:white,X:mult}X#1#{} Mult.',
            'Scored {C:clubs}#3#{} cards give {C:white,X:chips}X#1#{} Chips.',
            '{C:hearts,s:0.8,E:1}Then by the power vested in me',
            '{C:hearts,s:0.8,E:1}by the state of Delmarva,',
            '{C:hearts,s:0.8,E:1}I now pronounce you...',
            '{C:tarot,s:0.8,E:1}Garnet!',
            '{C:legendary,s:0.7,E:1}- From \"Reunited\"',
        }
    },
    atlas = 'Placeholder',
    rarity = 3,
    cost = 9,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0},
    credit = {
        art = 'aaceofhearts',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = {
        extra = {
            x_mult_chips = 2,
            suit = 'Hearts', 
            suit2 = 'Clubs', 
        }
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.x_mult_chips,
        localize(card.ability.extra.suit, 'suits_singular'), 
        localize(card.ability.extra.suit2, 'suits_singular') } }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play and
            context.other_card:is_suit(card.ability.extra.suit) then
            return {
                x_mult = card.ability.extra.x_mult_chips
            }
        end
        if context.individual and context.cardarea == G.play and
            context.other_card:is_suit(card.ability.extra.suit2) then
            return {
                x_chips = card.ability.extra.x_mult_chips
            }
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_reunited' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,

}

SMODS.Joker{ -- Galaxy Warp
    key = 'galaxy_warp',
    loc_txt = {
        name = '{C:dark_edition}Galaxy Warp',
        text = {
            '{C:white,X:mult}X???{} Mult.',
            '{C:green}#1# in #2#{} chance of creating a',
            '{C:edition,E:1}Warp Pad{} voucher',
            'at end of round.',
            '{C:inactive,s:0.8}Warp Pad:{} {C:attention,s:0.8}-1{} {C:inactive,s:0.8}Ante.'
        }
    },
    atlas = 'Placeholder',
    rarity = 3,
    cost = 7,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0},
    credit = {
        art = "aaceofhearts",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            odds = 10,
            max = 300,
            min = 3,
        }
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { (G.GAME and G.GAME.probabilities.normal or 1), card.ability.extra.odds, } }
    end,
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval and not context.blueprint then
            if pseudorandom('galaxy_warp') < G.GAME.probabilities.normal / card.ability.extra.odds then
                G.E_MANAGER:add_event(Event({ func = function()
                    Card.apply_to_run(nil, G.P_CENTERS['v_dlx_warp_glyph'])
                    return true
                end }))
                return { message = 'SWOOOOSH!' }
            end
        end
        if context.joker_main then
            return {
                x_mult = pseudorandom('galaxy_warp2', card.ability.extra.min, card.ability.extra.max),
            }
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_galaxy_warp' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}
-- instead of making this the joker's ability, i just used VanillaRemade's Hieroglyph code
SMODS.Voucher {
    key = 'warp_glyph',
    atlas = 'Placeholder',
    credit = {
        art = "aaceofhearts",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    pos = { x = 0, y = 0 },
    config = { extra = { deduction = 1 } },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.deduction } }
    end,
    --[[process_loc_text = function(self)
        --use another planet's loc txt instead
        local target_text = G.localization.descriptions[self.set]['v_hieroglyph'].text
        SMODS.Consumable.process_loc_text(self)
        G.localization.descriptions[self.set][self.key].text = target_text
    end,
    generate_ui = 0,]]
    loc_txt = {
        ['en-us'] = {
            name = '{C:dark_edition}Warp Pad',
            text = {
                '{C:attention}-#1#{} Ante',
            }
        }
    },
    redeem = function(self, card)
        -- Apply ante change
        ease_ante(-card.ability.extra.deduction)
        G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante or G.GAME.round_resets.ante
        G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante - card.ability.extra.deduction
        -- Apply hand change (NOT)
        --G.GAME.round_resets.hands = G.GAME.round_resets.hands - card.ability.extra.deduction
        --ease_hands_played(-card.ability.extra.deduction)
    end,
    in_pool = function()
        return false, { allow_duplicates = false }
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- White Diamond
    key = 'white', --joker key
    loc_txt = { -- local text
        name = '{C:edition,s:1.75,E:1}White Diamond{}',
        text = {
          'Jokers with {C:edition}editions{}',
          'each give {X:mult,C:white}X#1#{} Mult and {C:white,X:chips}X#1#{} Chips.',
          'When {C:attention}Boss Blind{} is defeated,',
          'a random {C:attention}Joker{} without an {C:attention}edition{} becomes {C:dark_edition}negative{}.',
          '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
          '{C:edition,s:0.8,E:1}After all, I am every color of the light.{}',
          '{C:edition,s:0.8,E:1}But you\'re a part of me...{}',
          '{C:edition,s:0.8,E:1}The part I always have to repress.{}',
          '{s:0.7,C:legendary,E:1}- From \"Change Your Mind\"{}'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Diamond', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    -- soul_pos = { x = 0, y = 2 },
    cost = 1000, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 2, y = 3}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = { 
        white_xmult = 2.5,
        card_limit = 12
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.white_xmult
        }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
    calculate = function(self,card,context)
        if context.other_joker and context.other_joker.edition then
		 if context.other_joker.edition.key == 'e_polychrome' 
         or context.other_joker.edition.key == 'e_holo' 
         or context.other_joker.edition.key == 'e_foil' 
         or context.other_joker.edition.key == 'e_negative' then
			return {
				x_mult = card.ability.extra.white_xmult,
                x_chips = card.ability.extra.white_xmult,
				card = other_joker,
				message = 'Hello, Starlight.',
				colour = G.C.EDITION,
				card:juice_up(0.5,0.5)
				}
				end
        end
        if context.end_of_round 
        and not context.repetition 
        and not context.individual 
        and not context.game_over then
            local blind = G.GAME.blind
            if blind.boss then
                local pool = {}
                for _, j in ipairs(G.jokers.cards) do
                    if not j.edition then
                        table.insert(pool, j)
                    end
                end
                if #pool > 0 then
                    local choice = pseudorandom_element(pool)
                    choice:set_edition('e_negative', true)
                    choice:juice_up(0.5, 0.5)
                end
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                --SMODS.add_card{ key = "c_sbeven_yellow_destabilizer", stickers = {"eternal"} }
                SMODS.add_card{ key = "c_sbeven_white_ship", stickers = {"eternal"} }
                --SMODS.add_card{ key = "c_sbeven_diamondseal_card", stickers = {"eternal"} }
                return true
            end}))
        end
        if context.joker_main then
            if context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_sbeven_Era 3', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'The Light!',
                    colour  = G.C.SUITS.EDITION,
                    e_chips = card.ability.extra.white_xmult
                }                
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_white' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_white')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_white_ship", stickers = {"eternal"} }
            --SMODS.add_card{ key = "c_sbeven_diamondseal_card", stickers = {"eternal"} }
            --SMODS.add_card{ key = "c_sbeven_yellow_destabilizer", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_white_ship')) do
            bm:start_dissolve()
        end
        --[[for _, bm in ipairs(SMODS.find_card('c_sbeven_diamondseal_card')) do
            bm:start_dissolve()
        end
        for _, bm in ipairs(SMODS.find_card('c_sbeven_yellow_destabilizer')) do
            bm:start_dissolve()
        end]]
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'c_star' }
            --SMODS.add_card{ key = 'c_hermit' }
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ --- Lonely Pearl (with Blueprint compatibility)
    key                   = 'lonely_pearl',
    atlas                 = 'DiamondShips',
    rarity                = 'sbeven_Gem',
    cost                  = 20,
    unlocked              = true,
    discovered            = true,
    blueprint_compat      = true,
    eternal_compat        = true,
    perishable_compat     = true,
    pos                   = { x = 2, y = 2 },
    credit = {
      art     = "Crewniverse",
      code    = "Pink Focalors",
      concept = "Pink Focalors"
    },

    loc_txt = {
        name = '{C:inactive,E:1}Lonely Pearl{}',
        text = {
            '{C:attention}+#1#{} hand size.',
            'Playing cards {C:attention}always{} score.',
            '{C:attention}Copies{} the ability of {C:attention}Joker{} to the right.',
            '{C:inactive,s:0.8}You finally came back... for me?{}',
            '{C:legendary,s:0.7,E:1}- From \"The Phantom Fable\"{}'
        }
    },

    config = {
        extra = {
          slots                   = 3,
          lonely_h_size           = 2
        }
    },

    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.extra.lonely_h_size } }
    end,

    -- ─── Blueprint overlay at right of the card row ─────────────────
    main_end = function(self, card)
      if card.area ~= G.jokers then return nil end

      -- find the "next" joker in the row
      local other = nil
      for i, v in ipairs(G.jokers.cards) do
        if v == card then
          other = G.jokers.cards[i+1]
          break
        end
      end
      if not other then return nil end

      local compat = other.config.center
                  and other.config.center.blueprint_compat
      local color = compat
        and mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
        or mix_colours(G.C.RED,   G.C.JOKER_GREY, 0.8)

      return {{
        n = G.UIT.C, config = { align="bm", minh=0.4 }, nodes = {{
          n = G.UIT.C, config = {
            ref_table = card,
            align     = "m",
            colour    = color,
            r         = 0.05,
            padding   = 0.06
          }, nodes = {{
            n      = G.UIT.T,
            config = {
              text   = ' ' .. localize('k_' .. (compat and 'compatible' or 'incompatible')) .. ' ',
              colour = G.C.UI.TEXT_LIGHT,
              scale  = 0.32 * 0.8
            }
          }}
        }}
      }}
    end,

    calculate = function(self, card, context)
      -- (A) Blueprint effect
      -- identify the "next" joker in the row, same as above
      local other = nil
      if G.jokers and G.jokers.cards then
        for i, v in ipairs(G.jokers.cards) do
            if v == card then
                other = G.jokers.cards[i+1]
                break
            end
        end
      end
      if other then
      local bp = SMODS.blueprint_effect(card, other, context)
      if bp then
        return bp
      end
    end

      -- (B) Always score your playing cards
      if context.modify_scoring_hand and not context.blueprint then
        return { add_to_hand = true }
      end
    end,

    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_lonely_pearl' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,

    add_to_deck = function(self, card, from_debuff)
        -- increase your hand size
        G.hand:change_size(card.ability.extra.lonely_h_size)
        if not from_debuff and next(SMODS.find_card('j_sbeven_lonely_pearl')) then
            card:start_dissolve()
        end
        -- add your slot count
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    remove_from_deck = function(self, card)
        G.hand:change_size(-card.ability.extra.lonely_h_size)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        G.E_MANAGER:add_event(Event({
            func = function()
                SMODS.add_card{ key = 'c_temperance' }
                return true
            end
        }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}


SMODS.Joker{ --- Blue Diamond
    key = 'blue', --joker key
    loc_txt = { -- local text
        name = '{C:clubs,s:1.4,E:1}Blue Diamond{}', --name of joker
        text = {
          'Each played {C:attention}Ace{} gives',
          '{X:dark_edition,C:white}^#1#{} Mult when scored',
          '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
          '{C:clubs,s:0.8,E:1}It was a{} {C:clubs,s:1,E:1}SWORD!{}',
          '{s:0.7,C:legendary,E:1}- From \"The Trial\"{}'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Diamond', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 100, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 3, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = {
        blue_AceMult = 1.4,
        card_limit = 6 --configurable value
      }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.blue_AceMult
        }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
    calculate = function(self,card,context)
        if context.individual and context.cardarea == G.play then
            if context.other_card:get_id() == 14 then
			return {
				e_mult = card.ability.extra.blue_AceMult,
				card = card,
				message = 'This is Pink\'s world!',
				}
			end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                --SMODS.add_card{ key = "c_sbeven_yellow_destabilizer", stickers = {"eternal"} }
                SMODS.add_card{ key = "c_sbeven_blue_ship", stickers = {"eternal"} }
                return true
            end}))
        end
        if context.joker_main then
            if context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_sbeven_Era 3', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'White\'s Light!',
                    colour  = G.C.SUITS.EDITION,
                    e_mult = card.ability.extra.blue_AceMult
                }                
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_blue' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_blue')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_blue_ship", stickers = {"eternal"} }
            SMODS.add_card{ key = "j_sbeven_blue_pearl" }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_blue_ship')) do
            bm:start_dissolve()
        end
        for _, bm in ipairs(SMODS.find_card('j_sbeven_blue_pearl')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ --- Blue Pearl
    key = 'blue_pearl', --joker key
    loc_txt = { -- local text
        name = '{C:planet,E:1}Blue Pearl{}', --name of joker
        text = {
          'Played {C:clubs}Clubs{} become ',
          'become {C:attention}polychrome{} cards when {C:attention}scored{}.',
          '{C:attention}Retriggers{} held in hand abilities once.',
          '{C:planet,s:0.8}Ahem, everyone prepare yourselves emotionally for the overpowering elegance that is, Blue Diamond.{}',
          '{C:legendary,s:0.7,E:1}- From \"Together Alone\"'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'DiamondShips', --atlas' key
    rarity = 'sbeven_Gem', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 20, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 2, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
          slots = 1,
          blue_pearl_repetitions = 1 -- gives +5 Joker slots
        }
    },
    calculate = function(self, card, context)
        -- Run once before the main scoring pass
        if context.before and context.main_eval and not context.blueprint then
            local turned = false

            for _, scored_card in ipairs(context.scoring_hand) do
                if scored_card.base.suit == "Clubs" then
                    turned = true

                    -- Turn it into the Polychrome edition
                    scored_card:set_edition("e_polychrome", true)

                    -- Optional visual flourish
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            scored_card:juice_up(0.2, 0.2)
                            return true
                        end
                    }))
                end
            end

            if turned then
                return {
                    message = "My Diamond...",   
                    colour  = G.C.DARK_EDITION
                }
            end
        end
        if context.repetition 
        and context.cardarea == G.hand 
        and (next(context.card_effects[1]) 
        or #context.card_effects > 1) then
            return {
                repetitions = card.ability.extra.blue_pearl_repetitions,
                message = "Yes... My Diamond...",   
                colour  = G.C.DARK_EDITION
            }
        end
    end,

    -- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_blue_pearl' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_blue_pearl')) then
            card:start_dissolve()
        end
        --[[if not next(SMODS.find_card('j_sbeven_blue')) then
            card:start_dissolve()
        end]]
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    remove_from_deck = function(self, card)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        G.E_MANAGER:add_event(Event({
            func = function()
                SMODS.add_card{ key = 'c_temperance' }
                return true
            end
        }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Yellow Diamond
    key = 'yellow', --joker key
    loc_txt = { -- local text
        collection = 'Universe', -- collection name
        name = '{C:gold,s:1.4,E:1}Yellow Diamond{}', --name of joker
        text = {
          'Played {C:attention,E:1}Aces{} are {C:diamonds}retriggered{}',
          '{C:dark_edition,E:1}#1#{} times',
          '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
          '{C:gold,s:0.8,E:1}What\'s the use of feeling,{} {C:clubs,s:1,E:1}Blue?{}',
          '{s:0.7,C:legendary,E:1}- From \"That Will Be All\"{}'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Diamond', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 100, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 3, y = 3}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = {
        yellow_AceRepeats = 14,
        card_limit = 6 --configurable value
      }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.yellow_AceRepeats
        }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
    calculate = function(self,card,context)
        if context.cardarea == G.play and context.repetition and not context.repetition_only then
			if (context.other_card:get_id() == 14) then
			return {
				message = 'That Will Be All!',
				repetitions = card.ability.extra.yellow_AceRepeats,
                message_card = card,
				card = context.other_card
				}
			end
		end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_yellow_destabilizer", stickers = {"eternal"} }
                SMODS.add_card{ key = "c_sbeven_yellow_ship", stickers = {"eternal"} }
                return true
            end}))
        end
        if context.joker_main then
            if context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_sbeven_Era 3', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'White\'s Light!',
                    colour  = G.C.SUITS.EDITION,
                    x_chips = card.ability.extra.yellow_AceRepeats
                }                
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_yellow' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_yellow')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_yellow_ship", stickers = {"eternal"} }
            SMODS.add_card{ key = "c_sbeven_yellow_destabilizer", stickers = {"eternal"} }
            SMODS.add_card{ key = "j_sbeven_yellow_pearl" }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_yellow_ship')) do
            bm:start_dissolve()
        end
        for _, bm in ipairs(SMODS.find_card('c_sbeven_yellow_destabilizer')) do
            bm:start_dissolve()
        end
        for _, bm in ipairs(SMODS.find_card('j_sbeven_yellow_pearl')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ --- Yellow  Pearl
    key = 'yellow_pearl', --joker key
    loc_txt = { -- local text
        name = '{C:attention,E:1}Yellow Pearl{}', --name of joker
        text = {
          'Gains {C:white,X:mult}X#2#{} Mult when a card of',
          '{C:diamonds}Diamonds{} suit is scored.',
          '{C:inactive}Currently {C:white,X:mult}X#1#{} {C:inactive}Mult',
          '{C:diamonds,s:0.8}All rise for the luminous Yellow Diamond!',
          '{C:legendary,s:0.7,E:1}- From \"The Trial\"'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'DiamondShips', --atlas' key
    rarity = 'sbeven_Gem', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 18, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
          -- start at 0×, gain 1× per Diamond
          yellow_pearl_x_mult       = 1,
          yellow_pearl_diamond_gain = 1,
          slots = 1,
        }
    },

    loc_vars = function(self, info_queue, card)
        return { vars = {
            -- show current accumulated Mult
            card.ability.extra.yellow_pearl_x_mult or self.config.extra.yellow_pearl_x_mult,
            card.ability.extra.yellow_pearl_diamond_gain
        }}
    end,

    calculate = function(self, card, context)
        ----------------------------------------
        -- (A) Whenever any card scores from play, if it was Diamonds, increment us
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            if scored.base.suit == "Diamonds" then
                -- initialize if needed
                card.ability.extra.yellow_pearl_x_mult =
                  (card.ability.extra.yellow_pearl_x_mult or self.config.extra.yellow_pearl_x_mult)
                  + self.config.extra.yellow_pearl_diamond_gain

                -- show a little log popup
                return {
                  message = "Yes, my Diamond!", 
                  colour  = G.C.SUITS.Diamonds
                }
            end
        end
        if context.joker_main and card.ability.extra.yellow_pearl_x_mult ~= 1 then
            return {
                x_mult = card.ability.extra.yellow_pearl_x_mult
            }
        end
    end,


    -- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_yellow_pearl' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_yellow_pearl')) then
            card:start_dissolve()
        end
        --[[if not next(SMODS.find_card('j_sbeven_yellow')) then
            card:start_dissolve()
        end]]
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    remove_from_deck = function(self, card)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        G.E_MANAGER:add_event(Event({
            func = function()
                SMODS.add_card{ key = 'c_temperance' }
                return true
            end
        }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Pink Diamond
    key = 'pink', --joker key
    loc_txt = { -- local text
        name = '{C:hearts,s:1.25,E:1}Pink Diamond{}', --name of joker
        text = {
            '{C:dark_edition,E:1}Retrigger{} all {C:attention,E:1}played cards{} {C:red,E:1}#1#{} times.',
            'If {C:edition,E:1}A Single Pale Rose{} is present, {C:white,X:dark_edition,E:1}^#2#{} {C:white,X:dark_edition,E:1}Chips&Mult{}.', 
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:hearts,s:0.8,E:1}No one can ever find out we did this. I never want to look back.{}',
            '{C:hearts,s:0.8,E:1}So, for my last order to you as a Diamond, please, let\'s never speak of this again.{}',
            '{C:hearts,s:0.8,E:1}No one can know.{}',
            '{s:0.7,C:legendary,E:1}- From \"A Single Pale Rose\"{}'
        } 
         --[[unlock = {
                'Be {C:legendary}cool{}',
          }]]
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Diamond', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 100, --cost
    unlocked = true, --where it is unlocked or not: if true,
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 7, y = 1}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = {
        again_pearl = 3,
        card_limit = 5,
        pink_emultchips = 4 --configurable value
      }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.again_pearl,
            card.ability.extra.pink_emultchips
        }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
    calculate = function(self,card,context)
        if context.cardarea == G.play and context.repetition and not context.repetition_only then
            return {
                message = 'Again, Pearl!',
                repetitions = card.ability.extra.again_pearl,
                card = context.other_card
            }
        end
        if #SMODS.find_card('j_sbeven_pale_rose') > 0 then
			if context.cardarea == G.jokers and context.joker_main then
				return {
					message = 'Soon it will be just... Rose.',
					e_mult = card.ability.extra.pink_emultchips,
                    e_chips = card.ability.extra.pink_emultchips,
					colour = G.C.EDITION
				}, true
			end
		end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_pink_ship", stickers = {"eternal"} }
                SMODS.add_card{ key = "c_sbeven_bubbled", stickers = {"eternal"} }
                return true
                end
            }))
        end
        if context.joker_main then
            if context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_sbeven_Era 3', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'White\'s Light!',
                    colour  = G.C.SUITS.EDITION,
                    e_chips = 1.1
                }                
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_pink' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_pink')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            --SMODS.add_card{ key = "c_sbeven_steven_shield", stickers = {"eternal"} }
            SMODS.add_card{ key = "c_sbeven_pink_ship", stickers = {"eternal"} }
            SMODS.add_card{ key = "c_sbeven_bubbled", stickers = {"eternal"} }
            SMODS.add_card{ key = "j_sbeven_pearl" }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_pink_ship')) do
            bm:start_dissolve()
        end
        for _, bm in ipairs(SMODS.find_card('c_sbeven_bubbled')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Rose Quartz
    key = 'rose', --joker key
    loc_txt = {
        name = '{C:hearts,E:1}Rose Quartz{}',
        text = {
            'Playing cards of {C:diamonds,E:1}Diamonds{} suit',
            'each give {X:mult,C:white,E:1}X#1#{} Mult and {X:chips,C:white,E:1}X#2#{} Chips when scored.',
            '{C:attention,E:1}Leader of the Crystal Gems.{}',
            '{C:hearts,s:0.8,E:1}When a Gem is made, it\'s for a reason.{}',
            '{C:hearts,s:0.8,E:1}They burst out of the ground already knowing what they\'re supposed to be, and then...{}',
            '{C:hearts,s:0.8,E:1}That\'s what they are.{}',
            '{C:hearts,s:0.8,E:1}Forever. But you, you\'re supposed to change.{}',
            '{C:hearts,s:0.8,E:1}You\'re never the same even moment to moment.{}',
            '{C:hearts,s:0.8,E:1}You\'re allowed and expected to invent who you are.{}',
            '{C:hearts,s:0.8,E:1}What an incredible power, the ability to \"grow up.\"{}',
            '{C:legendary,s:0.7,E:1}- From \"Greg the Babysitter\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_CGem',
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 1, y = 2}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { extra = { rose_mult = 1.75, rose_chips = 1.25 }},
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.rose_mult,
            card.ability.extra.rose_chips,
        }}
    end,
    calculate = function(self, card, context)
        -- only run on individual card scoring passes
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Diamonds' then
                return {
                    x_mult  = card.ability.extra.rose_mult,
                    x_chips  = card.ability.extra.rose_chips,
                    message = 'We are the Crystal Gems!',
                    colour  = G.C.EDITION
                }
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_rose' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_rose')) then
            card:start_dissolve()
        end
    end,    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Steven Universe
    key = 'steven', --joker key
    loc_txt = {
        name = '{C:hearts,E:1}Steven Universe{}',
        text = {
            'Playing cards of {C:hearts,E:1}Hearts{} or {C:diamonds,E:1}Diamonds{} suit',
            'each give {X:mult,C:white,E:1}X#1#{} Mult when scored.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:hearts,s:0.8,E:1}Life and Death and Love and Birth,{}',
            '{C:hearts,s:0.8,E:1}and Peace and War on the planet Earth.{}',
            '{C:hearts,s:0.8,,E:1}Is there anything that\'s worth more than Peace and Love on the planet Earth?{}',
            '{C:legendary,s:0.7,E:1}- From \"It Could\'ve Been Great\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_CGem',
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 7, y = 2}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            card_limit = 2,
            steven_mult = 1.5
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.steven_mult
        }}
    end,
    calculate = function(self, card, context)
        -- only run on individual card scoring passes
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Diamonds' or suit == 'Hearts' then
                return {
                    x_mult  = card.ability.extra.steven_mult,
                    message = 'The Future!',
                    colour  = G.C.MULT
                }
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_steven_shield", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
	in_pool = function()
		return #SMODS.find_card('j_sbeven_stevonnie') <= 0
	end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_steven')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_steven_shield", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_steven_shield')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'c_star' }
            --SMODS.add_card{ key = 'c_hermit' }
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Connie Maheswaran
    key = 'connie', --joker key
    loc_txt = {
        name = '{C:legendary,E:1}Connie Maheswaran{}',
        text = {
            'Playing cards of {C:spades,E:1}Spades{} or {C:clubs,E:1}Clubs{} suit',
            'each give {X:chips,C:white,E:1}X#1#{} Chips when scored.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{s:0.8,C:enhanced,E:1}I want to,{} {s:0.8,C:hearts,E:1}Steven{}{C:enhanced,s:0.8,E:1}... I want to be a part of your universe.{}',
            '{C:legendary,s:0.7,E:1}- From \"Full Disclosure\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Human',
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 4, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            card_limit = 2,
            connie_chips = 1.75
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.connie_chips
        }}
    end,
    calculate = function(self, card, context)
        -- only run on individual card scoring passes
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Spades' or suit == 'Clubs' then
                return {
                    x_chips  = card.ability.extra.connie_chips,
                    message_card = card,
                    message = 'Do it for Him!',
                    colour  = G.C.CHIPS
                }
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_connie_sword", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
	in_pool = function()
		return #SMODS.find_card('j_sbeven_stevonnie') <= 0
	end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_connie')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_connie_sword", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_connie_sword')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'c_sun' }
            --SMODS.add_card{ key = 'c_hermit' }
            return true
        end }))
    end,
     
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ --- Lars
    key = 'lars', --joker key
    loc_txt = { -- local text
        name = '{C:money,E:1}Lars Barriga{}', --name of joker
        text = {
          '{C:attention}Upgrade level{} of played {C:attention}poker hand{}.',
          'Can be upgraded by {C:dark_edition,E:1}A Single Pale Rose{}.',
          '{C:money,s:0.8}Toughen UP,{} {C:hearts,s:0.8}Steven!{}',
          '{C:legendary,s:0.7,E:1}- From \"Coach Steven\"{}'

        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Lars', --atlas' key
    rarity = 'sbeven_Human', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 10, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    calculate = function(self, card, context)
        -- whenever we’re in the “before main evaluation” step, always level up
        if context.before and context.main_eval then
            return {
                level_up = true,
                message  = localize('k_level_up_ex'),
            }
        end
    end,-- Prevent more than one copy from spawning in shops
	in_pool = function()
		return #SMODS.find_card('j_sbeven_clars') <= 0
	end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_lars')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Jasper
    key = 'jasper',
    loc_txt = {
        name = '{C:diamonds,E:1}Jasper{}',
        text = {
            'When a played hand is a {C:attention,E:1}Pair{},',
            'create negative {C:tarot,E:1}Hanged Man{} and {C:planet,E:1}Pluto{} consumables.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:diamonds,s:0.8,E:1}Neither of you saw{} {C:hearts,s:0.8,E:1}Rose Quartz{}? {C:diamonds,s:0.8,E:1}What a shame.{}',
            '{C:diamonds,s:0.8,E:1}I hoped to meet{} {C:hearts,s:0.8,E:1}her{}.',
            '{C:diamonds,s:0.8,E:1}I was looking forward to beating{} {C:hearts,s:0.8,E:1}her{} {C:diamonds,s:0.8,E:1}into the ground.{}',
            '{C:legendary,s:0.7,E:1}- From \"The Return\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Gem',
    cost = 12,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 7, y = 0},
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            card_limit = 2 -- EXTRA CONSUMABLE SLOTS
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.card_limit}}
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            if context.scoring_name == 'Pair'
            or context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    for i=1,1 do 
                        SMODS.add_card{ key = 'c_hanged_man', edition = 'e_negative' } 
                        SMODS.add_card{ key = 'c_pluto', edition = 'e_negative' } 
                    end
                    return true 
                end}))
                return {
                    message = 'Earth... is a prison.',
                    x_mult = 1.1,
                }
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_helmet", stickers = {"eternal"} }
                return true
            end}))
        end   
    end,-- Prevent more than one copy from spawning in shops
	in_pool = function()
		return #SMODS.find_card('j_sbeven_malachite') <= 0
	end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_jasper')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            SMODS.add_card{ key = "c_sbeven_helmet", stickers = {"eternal"} }
            return true
        end}))
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit -- EXTRA CONSUMABLES
            return true end }))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_helmet')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true end }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

-- Joker: Pearl
SMODS.Joker{
    key = 'pearl',
    loc_txt = {
        name = '{C:red,E:1}Pearl{}',
        text = {
            'Playing cards {C:attention,E:1}permanently gain{} {X:mult,C:white,E:1}X#2#{} Mult when scored.{}',
            '{C:inactive,s:0.8,E:1}Everything I ever did, I did for{} {C:inactive,C:hearts,E:1,s:0.8}her.{}',
            '{C:inactive,s:0.8,E:1}Now{} {C:inactive,C:hearts,E:1,s:0.8}she\'s{} {C:inactive,s:0.8,E:1}gone, but I\'m still here.{}',
            '{C:inactive,s:0.8,E:1}Sometimes, I wonder if{} {C:inactive,C:hearts,E:1,s:0.8}she{} {C:inactive,s:0.8,E:1}can see me through your eyes.{}',
            '{C:inactive,s:0.8,E:1}What would{} {C:inactive,C:hearts,E:1,s:0.8}she{} {C:inactive,s:0.8,E:1}think of me now?{}',
            '{s:0.7,C:legendary,E:1}- From \"Rose\'s Scabbard\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_CGem', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 5, y = 1}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            pearl_perma_x_mult = 0.2,
            card_limit = 2
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.pearl_perma_x_mult
    }}
    end,
    -- This calculate runs once for each scoring card
    calculate = function(self, card, context)
        local cfg   = self.config.extra or {}
        local perma = cfg.perma_x_mult or 0.2
        if context.individual and context.cardarea == G.play then
          local scored = context.other_card
          -- 1) Permanent +0.75 on every scored card
          scored.ability.perma_x_mult = (scored.ability.perma_x_mult or 0) + perma
            return {
                -- Show the trigger message in the log
                extra = { message = 'Yes, My Diamond.', color = G.C.SUITS.Hearts }
            }
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_spear", stickers = {"eternal"} }
                return true
            end}))
        end
    end,
	in_pool = function()
		return #SMODS.find_card('j_sbeven_mega') <= 0
	end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_pearl')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            SMODS.add_card{ key = "c_sbeven_spear", stickers = {"eternal"} }
            return true
        end}))
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit -- EXTRA CONSUMABLES
            return true end }))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_spear')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Volleyball
    key = 'volleyball', --joker key
    loc_txt = {
        name = '{C:hearts,E:1,s:1}\"Volleyball\"{}',
        text = {
            'Playing cards {C:attention,E:1}permanently gain{} {X:chips,C:white,E:1}X#1#{} Chips when scored.{}',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:hearts,s:0.8,E:1}Oh, no. I know what a nickname is.{}',
            '{C:hearts,s:0.8,E:1}It\'s just that it reminds me so much of{} {C:hearts,s:0.8,E:1}Pink.{}',
            '{C:hearts,s:0.8,E:1}She{} {C:hearts,s:0.8,E:1}used to give silly little names to everything.{}',
            '{C:hearts,s:0.8,E:1}She{} {C:hearts,s:0.8,E:1}was so funny like that...{}',
            '{E:1,s:0.7,C:legendary}- From \"Volleyball\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Gem', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 10,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 1, y = 3}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            volley_perma_x_chips = 0.3, --configurable value
            card_limit = 2,
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.volley_perma_x_chips,
            card.ability.extra.card_limit
        }}
    end,
    calculate = function(self, card, context)
        local cfg   = self.config.extra or {}
        local perma = cfg.perma_x_chips or 0.3
        if context.individual and context.cardarea == G.play then
          local scored = context.other_card
          -- 1) Permanent +0.75 on every scored card
          scored.ability.perma_x_chips = (scored.ability.perma_x_chips or 0) + perma
            return { 
                extra = { message = 'I am fine.', color = G.C.SUITS.Hearts }
            }
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_ribbon_wand", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
	in_pool = function()
		return #SMODS.find_card('j_sbeven_mega') <= 0
	end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_volleyball')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_ribbon_wand", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_ribbon_wand')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- pale rose
    key = 'pale_rose',
    loc_txt = {
        name = '{C:hearts,E:1}A Single Pale Rose{}',
        text = {
            '{X:dark_edition,C:white,E:1}^#1#{} Mult and gain {X:gold,C:white}$#2#{} at {C:attention}end of round{}.',
            '{C:dark_edition,s:1.1,E:1}This joker can heal or upgrade certain Jokers.{}',
            'If played hand is a {C:attention,E:1}Five of a Kind{} or a {C:attention,E:1}Flush Five{},',
            'create a {C:dark_edition,E:1}negative{} {C:edition,E:1}Soul Card{}.',
            'If played hand contains a {C:attention,E:1}High Card{},',
            'create a {C:dark_edition,E:1}negative{} {C:attention,E:1}Black Hole{}.',
            '{C:enhanced,s:0.8,E:1}I always thought I might be bad,{}',
            '{C:enhanced,s:0.8,E:1}Now I\'m sure that it\'s true.{}',
            '{C:enhanced,s:0.8,E:1}Cause I think you\'re so good, and I\'m nothing like you.{}',
            '{s:0.7,C:legendary,E:1}- From \"Love Like You\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Unique',
    cost = 12,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = { x = 4, y = 1 },
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            pale_e_mult = 1.2,
            pale_money = 15
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.pale_e_mult,
            card.ability.extra.pale_money
        }}
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            -- 1️⃣ Five of a Kind / Flush Five → Soul Card
            if context.scoring_name == 'Five of a Kind'
            or context.scoring_name == 'Flush Five'
            then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_soul', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'Do it for her.',
                    colour  = G.C.SUITS.Hearts,
                    e_mult  = card.ability.extra.pale_e_mult
                }
            end

            -- 2️⃣ High Card → Black Hole
            if context.scoring_name == 'High Card'
            or context.scoring_name == 'Pair' 
            or context.scoring_name == 'Three of a Kind' 
            or context.scoring_name == 'Two Pair'
            or context.scoring_name == 'Four of a Kind'
            or context.scoring_name == 'Flush'
            or context.scoring_name == 'Full House'
            or context.scoring_name == 'Straight'
            or context.scoring_name == 'Straight Flush' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_black_hole', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'Do it for her.',
                    colour  = G.C.SUITS.Hearts,
                    e_mult = card.ability.extra.pale_e_mult
                }
            end
            if context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_sbeven_Era 3', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'Do it for him.',
                    colour  = G.C.SUITS.EDITION,
                    e_mult = card.ability.extra.pale_e_mult
                }
            end
        end
    end,

    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(G.jokers.cards) do
            if owned.key == self.key then
                return false
            end
        end
        return true
    end,
    calc_dollar_bonus = function(self,card)
        return card.ability.extra.pale_money
    end,
        -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_pale_rose')) then
            card:start_dissolve()
        end
    end,
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({
            func = function()
                SMODS.add_card{ key = 'c_sun' }
                return true
            end
        }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}


SMODS.Joker{ -- Corrupter Steven
    key = 'corruption', --joker key
    loc_txt = {
        name = '{C:legendary,E:1,s:1.15}Corruption{}',
        text = {
            '{X:dark_edition,E:1,C:white}^#1#{} Chips and gain {X:gold,C:white,E:1}$#2#{} at {C:attention,E:1}end of round{}.',
            '{C:dark_edition,s:1.1,E:1}This joker can corrupt certain Jokers.{}',
            'If played hand is a {C:attention,E:1}Five of a Kind{} or a {C:attention,E:1}Flush Five{},',
            'create a {C:dark_edition,E:1}negative{} {C:edition,E:1}Soul Card{}.',
            'If played hand contains a {C:attention,E:1}High Card{},',
            'create a {C:dark_edition,E:1}negative{} {C:attention,E:1}Black Hole{}.',
            '{C:enhanced,s:0.8,E:1}Look at you go. I just adore you,{}',
            '{C:enhanced,s:0.8,E:1}I wish that I knew,{}',
            '{C:enhanced,s:0.8,E:1}What makes you think I\'m so special.{}',
            '{s:0.7,C:legendary,E:1}- From \"Love Like You\"{}'
        }
    },
    atlas = 'Consumables', --atlas' key
    rarity = 'sbeven_Unique', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 12,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    config = {
        extra = {
            corrupted_e_chips = 1.2,
            corrupted_money = 15
        }
    },
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.corrupted_e_chips,
            card.ability.extra.corrupted_money
        }}
    end,

    calculate = function(self, card, context)
        if context.joker_main then
            -- 1️⃣ Five of a Kind / Flush Five → Soul Card
            if context.scoring_name == 'Five of a Kind'
            or context.scoring_name == 'Flush Five'
            then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_soul', edition = 'e_negative' }
                    SMODS.add_card{ key = 'c_black_hole', edition = 'e_negative'}
                    return true
                end }))
                return {
                    message = 'Fate worse than death...',
                    colour  = G.C.SUITS.Hearts,
                    e_chips = card.ability.extra.corrupted_e_chips
                }
            end

            -- 2️⃣ High Card → Black Hole
            if context.scoring_name == 'High Card'
            or context.scoring_name == 'Pair' 
            or context.scoring_name == 'Three of a Kind' 
            or context.scoring_name == 'Two Pair'
            or context.scoring_name == 'Four of a Kind'
            or context.scoring_name == 'Flush'
            or context.scoring_name == 'Full House'
            or context.scoring_name == 'Straight'
            or context.scoring_name == 'Straight Flush'
            or context.scoring_name == 'Flush House' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_black_hole', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'The Diamonds...',
                    colour  = G.C.SUITS.Hearts,
                    e_chips = card.ability.extra.corrupted_e_chips
                }
            end
            if context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_sbeven_Era 3', edition = 'e_negative' }
                    return true
                end }))
                return {
                    message = 'The Diamond Authority...',
                    colour  = G.C.SUITS.EDITION,
                    e_chips = card.ability.extra.corrupted_e_chips
                }
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_corruption' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_corruption')) then
            card:start_dissolve()
        end
    end,
    
    calc_dollar_bonus = function(self,card)
        return card.ability.extra.corrupted_money
    end,
        -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_corruption')) then
            card:start_dissolve()
        end
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Joker{ -- Cracked Lapis Lazuli
    key = 'cracked_lapis', --joker key
    loc_txt = { -- local text
        name = '{C:enhanced,E:1}Cracked Lapis Lazuli{}', -- name of joker
        text = {
          'When playing a {C:attention,E:1}Pair{},',
          'both cards turn into {C:attention,E:1}7s{}',
          '{C:attention}after scoring{}.',
          '{C:inactive,s:0.8,E:1}I\'m{} {C:inactive,C:blue,E:1,s:0.81}Lapis Lazuli,{}',
          '{C:inactive,s:0.8,E:1}and you can\'t keep me trapped here anymore!{}',
          '{s:0.7,C:legendary,E:1}- From \"Mirror Gem\"{}'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Gem', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 8, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 5, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    config = { 
      extra = {
        white = 7, --configurable value
		black = 7
      }
    },
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
    calculate = function(self, card, context)
        -- only run once per hand, after the Joker triggers
        if context.joker_main and (
            context.scoring_name == 'Pair'
            or context.scoring_name == 'sbeven_The Authority'
        ) then
            -- pick your “7” rank (you only need one entry in the array)
            local rank_7 = pseudorandom_element({'7'}, pseudoseed('yin'))
            -- convert each card in the scoring hand
            for _, c in ipairs(context.scoring_hand) do
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local prefix = string.sub(c.base.suit,1,1) .. '_'
                        c:set_base(G.P_CARDS[prefix .. rank_7])
                        -- little juice
                        c:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            return {
                message = 'Homeworld...',
                colour  = G.C.DARK_EDITION
            }
        end
    end,

        -- Prevent more than one copy from spawning in shops
	in_pool = function()
		return #SMODS.find_card('j_sbeven_lapis') <= 0
	end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_cracked_lapis')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Lapis Lazuli
    key = 'lapis', -- joker key
    loc_txt = {
        name = '{C:blue,E:1}Lapis Lazuli{}', -- name of joker
        text = {
            "{C:white,X:dark_edition,E:1}^#1#{} {C:white,E:1,X:dark_edition}Mult{} and gain {X:gold,C:white,E:1}$#2#{} at {C:attention,E:1}end of round{}.",
            '{C:green,s:0.8,E:1}Peridot{}{C:blue,s:0.8,E:1}... are you okay?{}',
            '{s:0.7,C:legendary,E:1}- From \"Barn Mates\"{}'
        }
   },
    config = {
        extra = {
            lapis_e_mult = 1.5,
            lapis_money = 25 --configurable value
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.lapis_e_mult,
            card.ability.extra.lapis_money

        }} --#1# is replaced with card.ability.extra.Xmult
    end,
    rarity = 'sbeven_Hidden', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    atlas = 'Lapis', -- atlas' key
    pos = { x = 0, y = 0 },
    cost = 50,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },

    calculate = function(self, card, context)
        if context.joker_main then
            return {
               e_mult = card.ability.extra.lapis_e_mult,
               message = 'Peridot...',
           }
        end
    end,
        -- Prevent more than one copy from spawning in shops
	in_pool = function()
        local hasFusion = #SMODS.find_card('j_sbeven_malachite') <= 0
        local hasFusion2 = #SMODS.find_card('j_sbeven_aventurine') <= 0
        if hasFusion or hasFusion2 then
            return true, {allow_duplicates = false}
        else
		    return false, {allow_duplicates = false}
        end
	end,

    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_lapis')) then
            card:start_dissolve()
        end
    end,

    calc_dollar_bonus = function(self, card)
        return card.ability.extra.lapis_money
    end,   
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker {
	key = 'peridot', -- joker key
	loc_txt = {
		name = '{C:green,E:1}Peridot{}', -- name of joker
		text = {
			"If {C:attention,E:1}played hand{} contains at least {C:attention,E:1}2{} scoring {C:attention,E:1}7s{},",
			"create {C:attention,E:1}3 random{} {C:dark_edition,E:1}negative{} Consumables",
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            "{C:green,s:0.8,E:1}I think you\'re all insane!{}",
            "{C:green,s:0.8,E:1}But I guess I am too.{}",
            "{C:green,s:0.8,E:1}Anybody would be{}",
            "{C:green,s:0.8,E:1}If they were stuck on Earth with you!{}",
            '{s:0.7,C:legendary,E:1}- From \"It Could\'ve Been Great\"{}'

		}
	},
	loc_vars = function(self, info_queue, card)
		info_queue[#info_queue + 1] = G.P_CENTERS.e_negative
        return {vars = {card.ability.extra.card_limit}}
    end,
	rarity = 'sbeven_CGem', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
	atlas = 'Jokers', -- atlas' key
	pos = { x = 6, y = 1 },
	cost = 8,
	unlocked = true,
	discovered = true,
	blueprint_compat = true,
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            card_limit = 2 -- EXTRA CONSUMABLE SLOTS
        }
    },
	calculate = function(self, card, context)
		if context.joker_main then
			local seven_count = 0
			for i = 1, #context.scoring_hand do
				if context.scoring_hand[i]:get_id() == 7 then
					seven_count = seven_count + 1
				end
			end
			if seven_count >= 2 then
				G.E_MANAGER:add_event(Event({
					func = function()
						for i = 1, 3 do
							local card
							local typeConsumable = pseudorandom(pseudoseed('slot_machine'), 1, 3)
							if (typeConsumable == 1) then
								card = create_card('Tarot', G.consumables, nil, nil, nil, true)
							end
							if (typeConsumable == 2) then
								card = create_card('Planet', G.consumables, nil, nil, nil, true)
							end
							if (typeConsumable == 3) then
								card = create_card('Spectral', G.consumables, nil, nil, nil, true)
							end
							card:set_edition('e_negative', true)
							card:add_to_deck()
							G.consumeables:emplace(card)
						end
						return true
					end
				}))
				return {
					message = "CLOD!"
				}
			end
		end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_tablet", stickers = {"eternal"} }
                return true
            end}))
        end
	end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_peridot' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_peridot')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            SMODS.add_card{ key = "c_sbeven_tablet", stickers = {"eternal"} }
            return true
        end}))
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit -- EXTRA CONSUMABLES
            return true end }))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_tablet')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Spinel
    key = 'spinel', --joker key
    loc_txt = { -- local text
        name = '{C:red,E:1}Spinel{}', -- name of jonkler
        text = {
            '{C:white,X:chips,E:1}X#2#{} Chips and {X:dark_edition,E:1,C:white}^#2#{} Chips.',
            'Grants the ability to {C:dark_edition}rejuvenate{} a selected {C:attention}Joker{}.',
            '{C:inactive,s:0.8,E:1}YOUR NEW BEST FRIEND{} {C:red,s:0.8,E:1}SPINEL{} {C:inactive,s:0.8,E:1}IS HERE!{}',
            '{s:0.7,C:legendary,E:1}- From \"Steven Universe: The Movie\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Gem', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 7, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 6, y = 2}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = {
        spinel_x_and_e_chips = 1.2,
        card_limit = 2 --configurable value
      }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.spinel_x_and_e_chips
        }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then --not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) --unlocks the card if it isnt unlocked
    end,
    calculate = function(self, card, context)
        if context.joker_main then
			return {
				x_chips = card.ability.extra.spinel_x_and_e_chips,
				card = card,
				message = 'New Best Friend!', 
				colour = G.C.CHIPS,
                e_chips = card.ability.extra.spinel_x_and_e_chips,
				}
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_rejuvenator", stickers = {"eternal"} }
                return true
            end}))
        end  
        if context.selling_self  then
                return {
                    func = function()
            G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_sbeven_seppy_tag")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                    return true
                end,
                    message = "See ya..."
                }
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_spinel' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_spinel')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_rejuvenator", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_rejuvenator')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true end }))
    end,

    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Ruby
    key = 'ruby', -- joker key
    center_key = 'ruby', -- center key
    loc_txt = {
        name = '{C:rare,E:1}Ruby{}', -- name of joker
        text = {
            'Each played card gives {C:white,X:mult,E:1}X#1#{} Mult and {X:dark_edition,C:white,E:1}^#2#{} Mult when {C:attention,E:1}scored{},', 
            'if played hand is a {C:attention,E:1}Pair{}.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:mult,s:0.8,E:1}I... I\'ve never had a third eye before.{}',
            '{s:0.7,C:legendary,E:1}- From \"The Answer\"{}'
        }
   },
    config = {
        extra = {
            ruby_x_mult = 2,
            ruby_e_mult = 1.1,
            card_limit = 2 --configurable value
        }
    },
    rarity = 'sbeven_CGem', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    atlas = 'Ruby', -- atlas' key
    pos = { x = 0, y = 0 },
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.ruby_x_mult,
            card.ability.extra.ruby_e_mult
        }}
    end,
    calculate = function(self, card, context)
        if context.individual
        and context.cardarea == G.play then
            if context.scoring_name == 'Pair'
            or context.scoring_name == 'sbeven_The Authority' then
                return {
                    x_mult = card.ability.extra.ruby_x_mult,
                    message = 'I\'m an eternal flame, baby!',
                    e_mult = card.ability.extra.ruby_e_mult,
                }
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_arm", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_ruby' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_ruby')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_arm", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_arm')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'c_star' }
            --SMODS.add_card{ key = 'c_hermit' }
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Sapphire
    key = 'sapphire',
    center_key = 'sapphire',
    loc_txt = {
        name = '{C:planet,E:1}Sapphire{}',
        text = {
            'Each played card gives {X:chips,C:white,E:1}X#1#{} Chips and {X:dark_edition,C:white,E:1}^#2#{} Chips when scored,',
            'if played hand is a {C:attention,E:1}Pair{}.',
            '{C:planet,s:0.8,E:1}I\'ve never had more than one!{}',
            '{C:planet,s:0.8,E:1}It was nice.{}',
            '{s:0.7,C:legendary,E:1}- From \"The Answer\"{}'
        }
    },
    atlas = 'Jokers', -- atlas' key
    rarity = 'sbeven_CGem',
    cost = 8,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 3, y = 2},
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { extra = { 
        sapphy_x_chips = 2, 
        sapphy_e_chips = 1.1
    } },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.sapphy_x_chips,
            card.ability.extra.sapphy_e_chips
        }}
    end,
    calculate = function(self, card, context)
        if context.individual 
        and context.cardarea == G.play then
            if context.scoring_name == 'Pair'
            or context.scoring_name == 'sbeven_The Authority' then
                return {
                    x_chips = card.ability.extra.sapphy_x_chips,
                    e_chips = card.ability.extra.sapphy_e_chips,
                    message = 'Such is fate.',
                    colour = G.C.CHIPS
                }
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_sapphire' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_sapphire')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Amethyst
    key = 'amethyst', -- joker key
    loc_txt = { -- local text
        name = '{C:purple,E:1}Amethyst{}', -- name of joker
        text = {
            'Played {C:attention,E:1}cards{} each give {X:chips,C:white,E:1}X#2#{} Chips',
            'when {C:attention,E:1}scored{}.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:purple,s:0.8,E:1}NOOOOO! MI TORTA!{}',
            '{s:0.7,C:legendary,E:1}- From \"Monster Buddies\"{}'
        }
    },
    atlas = 'Jokers', -- atlas' key
    rarity = 'sbeven_CGem', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 6, -- cost in chips
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    pos = {x = 1, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    config = {
        extra = {
            ame_x_chips = 1.25,
            card_limit = 2 -- configurable value
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.ame_x_chips
        }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then -- not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) -- unlocks the card if it isn't unlocked
    end,
    calculate = function(self, card, context)
        if context.individual
        and context.cardarea == G.play then
            return {
                x_chips = card.ability.extra.ame_x_chips, -- apply multiplier
                card = context.other_card, -- target each scored card
                message = 'Shorty Squad Out!', -- display on trigger
                colour = G.C.CHIPS, -- multiplier colour
                func = function() context.other_card:juice_up(0.5, 0.5) end -- visual flourish
            }
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_whip", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_amethyst' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_amethyst')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_whip", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_whip')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'c_star' }
            --SMODS.add_card{ key = 'c_hermit' }
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Orange Spodumene (Coochie Gem)
    key = 'coochie_gem',
    loc_txt = {
        name = '{C:diamonds,E:1}Orange Spodumene{}', -- name of joker
        text = {
            'Each scored card of {C:diamonds,E:1}Diamonds{} suit gives {C:money}$#1#{}.',
            '{C:diamonds,s:0.8,E:1}she kinda bad tho',
            '{C:legendary,s:0.8,E:1}- From \"Pink Focalors\' Thoughts\"{}',
        },
    },
    atlas = 'Orange',
    rarity = 'sbeven_Gem', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 11,
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    pos = {x = 0, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right 
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { extra = { orange_money = 3 } }, -- configurable value
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.orange_money
        }}
    end,
    calculate = function(self, card, context)
        if context.individual 
        and context.cardarea == G.play 
        and context.other_card:is_suit("Diamonds") then
            G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0) + card.ability.extra.orange_money
            return {
                dollars = card.ability.extra.orange_money, -- apply multiplier
                func = function ()
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            G.GAME.dollar_buffer = 0
                            return true
                        end,
                    }))
                end
            }
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_coochie_gem' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,    
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_coochie_gem')) then
            card:start_dissolve()
        end
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Aquamarine
    key = 'aqua', -- joker key
    loc_txt = { -- local text
        name = '{C:planet,E:1}Aquamarine{}', -- name of joker
        text = {
            'Playing cards of {C:clubs,E:1}Clubs{} suit',
            'each give {X:chips,C:white,E:1}X#2#{} Chips when scored.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:planet,s:0.8,E:1}Oh no. Is {C:hearts,s:0.8,E:1}Rosie{} {C:planet,s:0.8,E:1}upset because her widdle deal didn\'t work?{}',
            '{C:planet,s:0.8,E:1} Look, I\'m so moved, I\'m crying. Just kidding. That\'s my gem!{}',
            '{s:0.7,C:legendary,E:1}- From \"Stuck Together\"{}'
        }
    },
    atlas = 'Aquamarine', -- atlas' key
    rarity = 'sbeven_Gem', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 10, -- cost in chips
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    pos = {x = 0, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    config = {
        extra = {
            aqua_x_chips = 2,
            card_limit = 2 -- configurable value
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit, -- #1#
            card.ability.extra.aqua_x_chips -- #2#
        }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then -- not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) -- unlocks the card if it isn't unlocked
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Clubs' then
            return {
                x_chips = card.ability.extra.aqua_x_chips, -- apply multiplier
                card = context.other_card, -- target each scored card
                message = 'The Rose Quartz...', -- display on trigger
                colour = G.C.CHIPS, -- multiplier colour
                func = function() context.other_card:juice_up(0.5, 0.5) end -- visual flourish
            }
        end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_wand", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_aqua' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_aqua')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_wand", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_wand')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'c_star' }
            --SMODS.add_card{ key = 'c_hermit' }
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ --- Padparadscha with Brainstorm overlay
    key                   = 'pad',
    atlas                 = 'Padparadscha',
    rarity                = 'sbeven_Off',
    cost                  = 25,
    unlocked              = true,
    discovered            = true,
    blueprint_compat      = true,
    eternal_compat        = true,
    perishable_compat     = true,
    pos                   = { x = 0, y = 0 },
    credit = {
      art     = "Crewniverse",
      code    = "Pink Focalors",
      concept = "Pink Focalors"
    },

    -- ─── localization & dynamic UI overlay ────────────────────────
    loc_txt = {
      name = '{C:money,E:1}Padparadscha{}',
      text = {
        'Retrigger all scored {C:attention}6s{}, {C:attention}7s{},',
        '{C:attention}8s{}, {C:attention}9s{}, and {C:attention}10s{}.',
        'Also, {C:attention}copies{} the ability of the {C:attention}leftmost{} Joker.',
        '{C:money,s:0.8}I predict Lars will change in hue.{}',
        '{C:legendary,s:0.7,E:1}- From \"Lars\' Head\"{}'
      }
    },
    loc_vars = function(self, info_queue, card)
      return { vars = {
        card.ability.extra.pad_repeats
      }}
    end,

    -- This puts the “compatible/incompatible blueprint” pill on the right
    main_end = function(self, card)
      if card.area ~= G.jokers then return nil end
      local other = G.jokers.cards[1]  -- the “center” card in the row
      if not other or other == card then return nil end

      local compat = other.config.center
                  and other.config.center.blueprint_compat
      local color = compat
        and mix_colours(G.C.GREEN, G.C.JOKER_GREY, 0.8)
        or mix_colours(G.C.RED, G.C.JOKER_GREY, 0.8)

      return {{
        n = G.UIT.C, config = { align="bm", minh=0.4 }, nodes = {{
          n = G.UIT.C, config = {
            ref_table = card,
            align     = "m",
            colour    = color,
            r         = 0.05,
            padding   = 0.06
          }, nodes = {{
            n      = G.UIT.T,
            config = {
              text   = ' ' .. localize('k_' .. (compat and 'compatible' or 'incompatible')) .. ' ',
              colour = G.C.UI.TEXT_LIGHT,
              scale  = 0.32 * 0.8
            }
          }}
        }}
      }}  
    end,

    -- ─── repeat‐6‐to‐10 ability ────────────────────────────────────
    config = {
      extra = {
        slots       = 2,
        pad_repeats = 1
      }
    },
    calculate = function(self, card, context)
      -- (1) Brainstorm blueprint pass:
      local bp = SMODS.blueprint_effect(card, G.jokers.cards[1], context)
      if bp then
        bp.colour = G.C.RED
        return bp
      end

      -- (2) Padparadscha’s retrigger‐6‐to‐10 pass:
      if context.repetition and context.cardarea == G.play then
        local v = context.other_card:get_id()
        if v >= 6 and v <= 10 then
          return {
            repetitions = card.ability.extra.pad_repeats
          }
        end
      end
    end,
    -- ─── deck‐limit, badge, etc. ───────────────────────────────────
    in_pool = function(self, current_shop_jokers, shop_level)
      for _, owned in ipairs(current_shop_jokers or {}) do
        if owned.key == 'j_sbeven_pad' then
          return false, { allow_duplicates = false }
        end
      end
      return true, { allow_duplicates = false }
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff and next(SMODS.find_card('j_sbeven_pad')) then
        card:start_dissolve()
      end
      G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    remove_from_deck = function(self, card)
      G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
      G.E_MANAGER:add_event(Event({ func = function()
        SMODS.add_card{ key = 'c_temperance' }
        return true
      end }))
    end,
    set_badges = function(self, card, badges)
      badges[#badges+1] = create_badge(
        "Steven Universe", G.C.PURPLE, G.C.EDITION, 1
      )
    end,
}

SMODS.Joker{ --- Rutile
    key = 'rutile', --joker key
    loc_txt = { -- local text
        name = '{C:hearts,E:1}Rutile{} {C:red,E:2}Twins{}', --name of joker
        text = {
          'Played {C:attention}6s{}, {C:attention}7s{}, {C:attention}8s{}, {C:attention}9s{}, and {C:attention}10s{}',
          'each give {C:white,X:mult}X#2#{} Mult & {C:white,X:chips}X#2#{} Chips when scored.',
          '{C:hearts,s:0.8}Captain Lars has taken so many risks on our behalf. We need him!{}.',
          '{C:legendary,s:0.7,E:1}- From \"Lars of the Stars\"'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Rutile', --atlas' key
    rarity = 'sbeven_Off', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 25, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
          slots = 2,
          rutile_x_mult_and_chips = 1.25
        }
    },
    loc_vars = function (self, info_queue, card)
        return {
            vars = {
                card.ability.extra.slots,
                card.ability.extra.rutile_x_mult_and_chips
            },
        }
    end,
    calculate = function(self, card, context)
        -- only when an individual card is being scored
        if context.individual and context.cardarea == G.play then
          local scored = context.other_card
          local num    = tonumber(scored.base.value)  -- "6" → 6, ..., "10" → 10
      
          if num and num >= 6 and num <= 10 then
            return {
              message = 'Captain!',
              x_mult  = card.ability.extra.rutile_x_mult_and_chips,    -- must match {X:mult} in text
              x_chips = card.ability.extra.rutile_x_mult_and_chips,    -- must match {X:chips} in text
              card    = scored,  -- apply to the scored card
              colour  = G.C.EDITION -- optional: highlight color
            }
            end
        end
    end,
      
    -- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_rutile' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_rutile')) then
            card:start_dissolve()
        end
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    remove_from_deck = function(self, card)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        G.E_MANAGER:add_event(Event({
            func = function()
                SMODS.add_card{ key = 'c_hermit' }
                return true
            end
        }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ --- Fluorite
    key = 'fluorite', --joker key
    loc_txt = { -- local text
        name = '{C:enhanced,E:1}Fluorite{}', --name of joker
        text = {
          'Played {C:attention}6s{}, {C:attention}7s{}, {C:attention}8s{}, {C:attention}9s{}, and {C:attention}10s{}',
          'become {C:gold}polychrome{} cards when {C:attention}scored{}.',
          '{C:enhanced,s:0.8}We won\'t do it. Not if it means leaving you behind.{}',
          '{C:legendary,s:0.7,E:1}- From \"Lars\' Head\"'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Fluorite', --atlas' key
    rarity = 'sbeven_Off', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 25, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = false, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
          slots = 2 -- gives +5 Joker slots
        }
    },
    calculate = function(self, card, context)
        if context.before 
        and context.main_eval 
        and not context.blueprint 
        then
            local got_any = false
    
            for _, scored_card in ipairs(context.scoring_hand) do
                -- base.value is a string ("6", "7", … "J", "Q", etc.)
                local raw = scored_card.base.value
                -- turn it into a number (non-numeric ranks yield nil)
                local v = tonumber(raw)
    
                -- only if it really was 6..10
                if v and v >= 6 and v <= 10 then
                    got_any = true
    
                    -- Give the card the negative edition
                    scored_card:set_edition("e_polychrome", true)
    
                    -- Optional visual juice
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            scored_card:juice_up(0.2, 0.2)
                            return true
                        end
                    }))
                end
            end
    
            if got_any then
                return {
                    message = "Cap..tain.. Lars...!",   -- or a new key if you prefer
                    colour  = G.C.DARK_EDITION
                }
            end
        end
    end,
    -- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_fluorite' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_fluorite')) then
            card:start_dissolve()
        end
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    remove_from_deck = function(self, card)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        G.E_MANAGER:add_event(Event({
            func = function()
                SMODS.add_card{ key = 'c_judgement' }
                return true
            end
        }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


-------This Segment is for all the Fusion Jokers-----------
-- Stevonnie
-- Malachite
-- Opal
-- Garnet
-- Rhodonite
-- Aventurine
-------Fusions to add-------
-- Rainbow Quartz
-- Rainbow 2.0
-- Smokey Quartz
-- Sunstone
-- Sardonyx
-- Sugilite
-- Alexandrite
-- Obsidian
-- Zebra Jasper
-- Corrupted Steven

SMODS.Joker{ --- Moonstone
    key = 'moon', --joker key
    loc_txt = { -- local text
    name = '{C:planet,s:1.2,E:1}M{C:inactive,s:1.2,E:1}o{C:planet,s:1.2,E:1}o{C:inactive,s:1.2,E:1}n{C:planet,s:1.2,E:1}s{C:inactive,s:1.2,E:1}t{C:planet,s:1.2,E:1}o{C:inactive,s:1.2,E:1}n{C:planet,s:1.2,E:1}e{}',    --name of joker
        text = {
          '{C:dark_edition}+5{} Joker slots and {C:white,X:dark_edition}^#1#{} {C:white,X:dark_edition}Chips&Mult{}.',
          'All {C:attention,E:1}playing cards{} and {C:attention,E:1}Jokers{}',
          'are now {C:attention,E:2}immune{} to debuffs.',
          '{C:planet,s:0.8,E:1}The whole time, we thought we were following{} {C:red,s:0.8,E:1}her{}, {C:planet,s:0.8,E:1}but{} {C:red,s:0.8,E:2}she{} {C:planet,s:0.8,E:2}was following us.{}',
          '{C:planet,s:0.8,E:1}How could{} {C:hearts,s:0.8,E:1}she{} {C:planet,s:0.8,E:1}not after {C:inactive,s:0.8,E:2}you{} {C:planet,s:0.8,E:1}swept{} {C:red,s:0.8,E:2}her{} {C:planet,s:0.8,E:2}off{} {C:red,s:0.8,E:2}her{} {C:planet,s:0.8,E:2}feet?{}',
          '{C:inactive,s:0.8,E:1}W-What? Me?{}',
          '{C:hearts,s:0.8,E:1}Are{} {C:inactive,s:0.8,E:2}you{} {C:hearts,s:0.8,E:1}kidding?{} {C:inactive,s:0.8,E:2}You{} {C:hearts,s:0.8,E:2}took{} {C:red,s:0.8,E:1}her{} {C:hearts,s:0.8,E:1}on this whirlwind tour of Earth{}',
          '{C:hearts,s:0.8,E:1}and then{} {C:red,s:0.8,E:1}she{} {C:hearts,s:0.8,E:1}wanted to live here with{} {C:inactive,s:0.8,E:2}you{} {C:hearts,s:0.8,E:2}forever!{}',
          '{C:inactive,s:0.7,E:2}art by @pitisho on TikTok',
          '{C:legendary,s:0.7,E:1}- From \"Now We\'re Only Falling Apart\"{}'

        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'moon', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 250, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = '@pitisho',
        code = 'Pink Focalors',
        concept = '@pitisho'

    },
    config = {
        extra = {
          slots = 5,
          moon_e_mult_e_chips = 1.11 -- gives +5 Joker slots
        }
    }, 
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.moon_e_mult_e_chips
        }}
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            G.E_MANAGER:add_event(Event({
                func = function()
                    G.GAME.dollars = G.GAME.dollars + 10
                    play_sound('chips1', 0.9 + math.random()*0.1, 0.7)
                    return true
                end
            }))  
            return {
                e_mult = card.ability.extra.moon_e_mult_e_chips,
                e_chips = card.ability.extra.moon_e_mult_e_chips,
                message = 'Fated to be...',
                colour = G.C.EDITION
            }
        end
    end,    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_moon')) then
            card:start_dissolve()
        end
        -- Grant +5 Joker slots
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    
    remove_from_deck = function(self, card)
        -- Only spawn the other jokers if not debuffed/destroyed (i.e., sold manually)
        if not card.debuffed and not card.destroyed then
            G.E_MANAGER:add_event(Event({ func = function()
                --SMODS.add_card{ key = 'j_sbeven_pearl' }
                --SMODS.add_card{ key = 'j_sbeven_sapphire' }
            return true
        end
        }))
        end
        -- Always subtract the joker slots if ability exists
        if card.ability and card.ability.extra and card.ability.extra.slots then
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_moon' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,           
}    

local csdr = Card.set_debuff
function Card:set_debuff(should_debuff)
	if #SMODS.find_card('j_sbeven_moon') > 0 then
		return false
	elseif (((self.config or {}).center or {}).debuff_immune or (((self.config or {}).center or {}).rarity or 1) == 6) and should_debuff == true then
		card_status_text(self, 'Immune', nil, 0.05*self.T.h, G.C.RED, nil, 0.6, nil, nil, 'bm', 'cancel', 1, 0.9)
		return false
	else
		csdr(self, should_debuff)
	end
end


SMODS.Joker{ --- Bloodstone
    key = 'blood',
    loc_txt = {
        name = '{C:tarot,s:1.2}B{C:green,s:1.2}l{C:tarot,s:1.2}o{C:green,s:1.2}o{C:tarot,s:1.2}d{C:green,s:1.2}s{C:tarot,s:1.2}t{C:green,s:1.2}o{C:tarot,s:1.2}n{C:green,s:1.2}e{}',
        text = {
            '{C:white,X:dark_edition,E:1}^#2#{} {C:white,X:dark_edition,E:1}Chips&Mult{}',
            'Grants the ability to {C:attention,E:1}sell selected playing cards{}.',
            '{C:tarot,s:0.8}If{} {C:green,s:0.8,E:1}you{} {C:tarot,s:0.8,E:1}really want to understand fusion, I can help you.{}',
            '{C:green,s:0.8,E:1}What do you mean?',
            '{C:tarot,s:0.8,E:1}Let\'s fuse.',
            '{C:green,s:0.8,E:1}Oh my stars!',
            '{C:inactive,s:0.7,E:2}art by @yellowpinks on TikTok',
            '{C:legendary,s:0.7,E:1}- From \"Log Date 7 15 2\"'
        },
    },
    atlas = 'blood',
    rarity = 'sbeven_Fusion',
    cost = 250,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = { x = 0, y = 0 },
    credit = {
        art     = '@yellowpinks',
        code    = 'Pink Focalors',
        concept = '@yellowpinks',
    },
    config = {
        extra = {
            card_limit = 2,
            blood_e_chips_e_mult = 2
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.blood_e_chips_e_mult
        }}
    end,
    calculate = function(self, card, context)
        -- only run on individual card scoring passes
        if context.joker_main then
            return {
                message = 'Blood Money...',
                colour  = G.C.EDITION,
                e_mult  = card.ability.extra.blood_e_chips_e_mult,
                e_chips = card.ability.extra.blood_e_chips_e_mult,
            }
        end
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_blood')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_blood_money", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_blood_money')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'j_sbeven_garnet' }
            --SMODS.add_card{ key = 'j_sbeven_peridot' }
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_blood' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Joker{ -- Stevonnie
    key = 'stevonnie', --joker key
    loc_txt = {
        name = '{C:legendary,E:1}S{C:hearts}t{C:legendary}e{C:hearts}v{C:legendary}o{C:hearts}n{C:legendary}n{C:hearts}i{C:legendary}e{}',
        text = {
            'Playing cards of {C:attention,E:1}any suit{} each give',
            '{X:mult,C:white,E:1}X#2#{} Mult and {X:chips,C:white,E:1}X#2#{} Chips when scored.',
            'If played hand is a {C:attention,E:1}Five of a Kind{} or a {C:attention,E:1}Flush Five{},',
            'create {C:edition,E:1}A Single Pale Rose{}.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:enhanced,s:0.8,E:1}Take a moment to think of just{}',
            '{C:enhanced,s:0.8,E:1}Flexibility, love, and trust.{}',
            '{C:legendary,s:0.7,E:1}- From \"Mindful Education\"{}'
        }
    },
    atlas = 'Stevonnie', --atlas' key
    rarity = 'sbeven_PFusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 250,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            card_limit = 2,
            stevonnie_x_chips_x_mult = 7 -- EXTRA CONSUMABLE SLOTS
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.stevonnie_x_chips_x_mult
        }}
    end,
    calculate = function(self, card, context)
        -- only run on individual card scoring passes
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Diamonds' 
            or suit == 'Spades' 
            or suit == 'Hearts' 
            or suit == 'Clubs' then
                return {
                    x_mult  = card.ability.extra.stevonnie_x_chips_x_mult,
                    x_chips  = card.ability.extra.stevonnie_x_chips_x_mult,
                    message = 'Pretty cool, right?',
                    colour  = G.C.EDITION
                }
            end
        end
        if context.joker_main then
            if context.scoring_name == 'Five of a Kind' 
            or context.scoring_name == 'sbeven_The Authority'
            or context.scoring_name == 'Flush Five' then
                G.E_MANAGER:add_event(Event({ func = function()
                        SMODS.add_card{ key = 'j_sbeven_pale_rose', edition = 'e_negative' } 
                    return true 
                end}))
                return {
                    message = 'Alone Together.',
                    colour = G.C.EDITION,
                }
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = "c_sbeven_stevonnie_weapons", stickers = {"eternal"} } 
                return true 
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_stevonnie')) then
            card:start_dissolve()
        end
            G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            SMODS.add_card{ key = "c_sbeven_stevonnie_weapons", stickers = {"eternal"} }
            return true
        end}))
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit -- EXTRA CONSUMABLES
            return true end }))
    end,
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_steven' }
            --SMODS.add_card{ key = 'j_sbeven_connie' }
            return true
        end }))
        for _, bm in ipairs(SMODS.find_card('c_sbeven_stevonnie_weapons')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_stevonnie' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Malachite Fusion
    key = 'malachite', --joker key
    loc_txt = {
        name = '{C:diamonds,s:1.3}M{C:blue,s:1.3}a{C:diamonds,s:1.3}l{C:blue,s:1.3}a{C:diamonds,s:1.3}c{C:blue,s:1.3}h{C:diamonds,s:1.3}i{C:blue,s:1.3}t{C:diamonds,s:1.3}e{}',
        text = {
            '{X:dark_edition,C:white,E:1}^#1#{} {C:white,E:1,X:dark_edition}Mult{} and {X:gold,C:white,E:1}$#2#{} when {C:attention}ability is triggered{}.',
            'If played hand is a {C:attention,E:2}Pair{},',
            'create {C:dark_edition,E:1}negative{} {C:attention,E:2}Hanged Man{}, {C:attention,E:2}Mercury{},',
            '{C:attention,E:2}Deja Vu{}, and {C:attention,E:2}Cryptid{} consumables.',
            'If played hand is a {C:attention,E:2}Five of a Kind{} or a {C:attention,E:2}Flush Five{},',
            'create {C:edition,E:1}A Single Pale Rose{}.',
            '{C:green,s:0.8,E:1}You think you can hold me down?! Nobody can! Not anymore.{}',
            '{s:0.7,C:legendary,E:1}- From \"Super Watermelon Island\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_UFusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 300,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 9, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = {
        malachite_e_mult = 2.5,
        malachite_money = 50 --configurable value
      }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.malachite_e_mult,
            card.ability.extra.malachite_money
        }}
    end,
    calculate = function(self, card, context)
        -- Spawn consumables if scoring hand matches...
        if context.joker_main then
            if context.scoring_name == 'Pair'
            or context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.dollars = G.GAME.dollars + card.ability.extra.malachite_money
                        play_sound('chips1', 0.9 + math.random()*0.1, 0.7)
                        return true
                    end
                }))  
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_hanged_man', edition = 'e_negative' }
                    SMODS.add_card{ key = 'c_mercury',    edition = 'e_negative' }
                    SMODS.add_card{ key = 'c_deja_vu',    edition = 'e_negative' }
                    SMODS.add_card{ key = 'c_cryptid',    edition = 'e_negative' }
                    return true
                end }))
                return { message = 'We are Malachite!', colour = G.C.EDITION, e_mult = card.ability.extra.malachite_e_mult }
            end
        end
    
        if context.joker_main then
            if context.scoring_name == 'Five of a Kind' 
            or context.scoring_name == 'Flush Five'
            or context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.dollars = G.GAME.dollars + card.ability.extra.malachite_money
                        play_sound('chips1', 0.9 + math.random()*0.1, 0.7)
                        return true
                    end
                }))  
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'j_sbeven_pale_rose', edition = 'e_negative' }
                    return true
                end }))
                return { message = 'We are Malachite!', colour = G.C.EDITION, e_mult = card.ability.extra.malachite_e_mult }
            end
        end
    end,
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_lapis' }
            --SMODS.add_card{ key = 'j_sbeven_jasper' }
            return true
        end }))
    end,
    -- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_malachite' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_malachite')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- For Opal
    key = 'opal', --joker key
    loc_txt = {
        name = '{C:dark_edition,E:1}Opal{}',
        text = {
            'Played cards {C:attention,E:2}permanently gain{} {X:mult,C:white,E:1}X#3#{} Mult and give {X:chips,C:white,E:1}X#2#{} Chips when scored,',
            'if played hand is a {C:attention,E:2}Pair{}.',
            'If played hand is a {C:attention,E:2}Five of a Kind{} or a {C:attention,E:2}Flush Five{},',
            'create {C:edition,E:1}A Single Pale Rose{}.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:dark_edition,s:0.8,E:1}All{} {C:hearts,s:0.8,E:1}you{} {C:dark_edition,s:0.8}wanna do, is see me turn into...{}',
            '{C:hearts,s:0.8,E:1}A Giant Woman.{}',
            '{C:legendary,s:0.7,E:1}- From \"Giant Woman\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 125,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 3, y = 1}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            opal_x_chips = 1.75,      -- Enhanced chips multiplier (Amethyst base ~1.25)
            opal_perma_x_mult = 0.5,  -- Enhanced permanent mult (Pearl base ~0.2)
            card_limit = 2
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.opal_x_chips,
            card.ability.extra.opal_perma_x_mult
        }}
    end,
    calculate = function(self, card, context)
        if context.individual 
        and context.cardarea == G.play 
        and context.scoring_name == 'Pair' then
            local oc = context.other_card
            -- Apply Amethyst-like chip bonus
            local result = {
                x_chips = card.ability.extra.opal_x_chips,
                card = oc,
                colour = G.C.CHIPS,
                message = 'Independent Together.',
                func = function() oc:juice_up(0.5, 0.5) end
            }

            -- Apply Pearl-like permanent multiplier
            oc.ability.opal_perma_x_mult = (oc.ability.opal_perma_x_mult or 0) + card.ability.extra.opal_perma_x_mult

            return result
        end
        if context.joker_main then
            if context.scoring_name == 'Five of a Kind' 
            or context.scoring_name == 'Flush Five'
            or context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                        SMODS.add_card{ key = 'j_sbeven_pale_rose', edition = 'e_negative' } 
                    return true 
                end}))
                return {
                    message = 'A Giant Woman.',
                    colour = G.C.EDITION,
                    e_mult = 2,
                }
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_bow", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_pearl' }
            --SMODS.add_card{ key = 'j_sbeven_amethyst' }
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_opal' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_opal')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_bow", stickers = {"eternal"} }
            return true
        end}))
    end,
    
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_bow')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'j_sbeven_ruby' }
            --SMODS.add_card{ key = 'j_sbeven_sapphire' }
            return true
        end }))
    end,
    -- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_opal' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{
    key = 'garnet', -- joker key
    center_key = 'garnet', -- center key
    loc_txt = { -- localization text
        name = '{C:tarot,E:1}Garnet{}',
        text = {
            'Each card played in a {C:attention,E:2}Pair{}', 
            'gives {X:mult,C:white,E:1}X#2#{} Mult, {X:chips,C:white,E:1}X#2#{} Chips,',
            'and {C:white,X:dark_edition,E:1}^#3#{} {C:white,X:dark_edition,E:1}Chips&Mult{} when {C:attention,E:2}scored{}.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:inactive,s:0.8,E:1}This is{} {C:tarot,E:1,s:0.8}Garnet{}. {C:inactive,s:0.8,E:1}Back together.{}',
            '{C:inactive,s:0.8,E1}And{} {C:tarot,s:0.8,E1}I\'m{} {C:inactive,s:0.8,E1}never going down at the hands of the likes of{} {C:diamonds,s:0.8,E1}you{}',
            '{C:inactive,s:0.8,E1}\'Cause{} {C:tarot,s:0.8,E1}I\'m{} {C:inactive,s:0.8,E1}so much better. And every part of{} {C:tarot,s:0.8,E1}me{} {C:inactive,s:0.8,E1}is saying go get{} {C:diamonds,s:0.8,E1}her.{}',
            '{s:0.7,C:legendary,E:1}- From \"Jailbreak\"{}'
        }
    },
    atlas = 'Jokers', -- atlas key
    rarity = 'sbeven_PFusion', -- Legendary
    cost = 300, -- cost in chips
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 6, y = 0}, -- position in atlas
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { extra = { garnet_multchips = 8, garned_emult_echips = 1.5, repetitions = 1, card_limit = 2 } 
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.garnet_multchips, --#2#
            card.ability.extra.garned_emult_echips --#3#
        }}
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if context.scoring_name == 'Pair'
            or context.scoring_name == 'sbeven_The Authority' then
                return {
                    x_mult = card.ability.extra.garnet_multchips,
                    x_chips = card.ability.extra.garnet_multchips,
                    e_mult = card.ability.extra.garned_emult_echips,
                    e_chips = card.ability.extra.garned_emult_echips,
                    message = 'Stronger Than You.',
                    colour = G.C.EDITION
                }
            end  
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_gaunt", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_gaunt')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'j_sbeven_ruby' }
            --SMODS.add_card{ key = 'j_sbeven_sapphire' }
            return true
        end }))
    end,
    -- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_garnet' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_garnet')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_gaunt", stickers = {"eternal"} }
            return true
        end}))
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Bluebird
    key = 'bluebird', -- joker key
    loc_txt = { -- local text
        name = '{C:planet,E:1}B{C:mult,E:1}l{C:planet,E:1}u{C:mult,E:1}e{C:planet,E:1}b{C:mult,E:1}i{C:planet,E:1}r{C:mult,E:1}d {C:planet,E:1}A{C:mult,E:1}z{C:planet,E:1}u{C:mult,E:1}r{C:planet,E:1}i{C:mult,E:1}t{C:planet,E:1}e{}', -- name of joker
        text = {
            'Playing cards of {C:clubs,E:1}Clubs{} suit',
            'each give {X:chips,C:white,E:1}X#2#{} Chips when scored.',
            'Playing cards of {C:hearts,E:1}Hearts{} suit',
            'each give {X:mult,C:white,E:1}X#2#{} Mult when scored.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:planet,E:1,s:0.8}Blue{C:mult,E:1,s:0.8}bird {C:planet,E:1,s:0.8}Azu{C:mult,E:1,s:0.8}rite{}, {C:planet,s:0.8,E:1}at your service!{}',
            '{C:planet,s:0.8,E:1}All right, give {C:mult,s:0.8,E:1}u{C:planet,s:0.8,E:1}s{} {C:planet,s:0.8,E:1}a hug then!{}',
            '{s:0.7,C:legendary,E:1}- From \"Bluebird\"{}'
        }
    },
    atlas = 'Bluebird', -- atlas' key
    rarity = 'sbeven_UFusion', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 120, -- cost in chips
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    pos = {x = 0, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    config = {
        extra = {
            bluebird_multchips = 3,
            card_limit = 2 -- configurable value
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.card_limit,
            card.ability.extra.bluebird_multchips
    }}
    end,
    check_for_unlock = function(self, args)
        if args.type == 'derek_loves_you' then -- not a real type, just a joke
            unlock_card(self)
        end
        unlock_card(self) -- unlocks the card if it isn't unlocked
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Clubs' then
                return {
                    x_chips = card.ability.extra.bluebird_multchips, -- apply multiplier
                    card = context.other_card, -- target each scored card
                    message = 'En Garde!', -- display on trigger
                    colour = G.C.CHIPS, -- multiplier colour
                    func = function() context.other_card:juice_up(0.5, 0.5) end -- visual flourish
                }
            end
        end
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Hearts' then
                return {
                    x_mult = card.ability.extra.bluebird_multchips, -- apply multiplier
                    card = context.other_card, -- target each scored card
                    message = 'DIE! DIE! DIE! DIE! DIE! DIE!', -- display on trigger
                    colour = G.C.MULT, -- multiplier colour
                    func = function() context.other_card:juice_up(0.5, 0.5) end -- visual flourish
                }
            end
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_ice", stickers = {"eternal"} }
                return true
            end}))
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_bluebird' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_bluebird')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_ice", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_ice')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            --SMODS.add_card{ key = 'c_star' }
            --SMODS.add_card{ key = 'c_hermit' }
            return true
        end }))
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ --- Captain Lars
    key = 'clars', --joker key
    loc_txt = { -- local text
        name = '{C:hearts,E:1}Lars of the Stars{}', --name of joker
        text = {
          '{C:attention}Level up{} played hand.',
          'When {C:attention}boss blind{} is defeated, {C:attention}summons{} a member of the {C:dark_edition}Off-Colors Crew{}.',
          '{C:attention}Astronomically{} low {C:green}chance{} of summoning {C:dark_edition,E:1}The Wasteland Queen{}',
          'when {C:attention}selecting any blind{}.',
          '{C:inactive,s:0.8}I\'d never surrender to you! Blow us into stardust like you\'ve always dreamed of.',
          '{C:legendary,s:0.7,E:1}- From \"Lars of the Stars\"{}'
        },
    },
    atlas = 'CLars',
    rarity = 'sbeven_Off',
    cost = 77,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0},
    credit = {
        art     = "Crewniverse",
        code    = "Pink Focalors",
        concept = "Pink Focalors"
    },

    calculate = function(self, card, context)
        -- always level up before main evaluation
        if context.before and context.main_eval then
            return {
                level_up = true,
                message  = localize('k_level_up_ex'),
            }
        end

        -- end-of-round boss summon with weighted rarity
        if context.end_of_round
        and not context.repetition
        and not context.individual
        and not context.game_over then

            local blind = G.GAME.blind
            if blind.boss then

                -- define your choices and weights
                local choices = {
                    { key = 'j_sbeven_pad',           weight = 1    },
                    { key = 'j_sbeven_rutile',        weight = 1    },
                    { key = 'j_sbeven_fluorite',      weight = 1    },
                    { key = 'j_sbeven_rhodonite_off', weight = 1    },
                    { key = 'j_sbeven_black',         weight = 0.0001 }  -- 0.01% chance
                }

                -- compute total weight
                local total = 0
                for _, choice in ipairs(choices) do
                    total = total + choice.weight
                end

                -- pick a random point in [0, total)
                local r = love.math.random() * total

                -- find which choice it lands on
                local cum = 0
                local pick_key = choices[1].key
                for _, choice in ipairs(choices) do
                    cum = cum + choice.weight
                    if r < cum then
                        pick_key = choice.key
                        break
                    end
                end

                -- summon the selected joker
                SMODS.add_card{ key = pick_key }
                return { message = "Let's go, Crew!", colour = G.C.EDITION }
            end
        end
        if context.setting_blind and not context.blueprint_card then
            -- set your chance here (0.0001 = 0.01%)
            local carbonadoChance = 0.0001

            if love.math.random() < carbonadoChance then
                -- summon Carbonado
                SMODS.add_card{ key = 'j_sbeven_black' }
                return { message = "The Queen has arrived...", colour = G.C.EDITION }
            else
                -- otherwise give the player $1
                -- replace `add_money` with whatever your game API uses
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.dollars = G.GAME.dollars + 10
                        return true
                    end
                }))
                return { message = "No dice!", colour = G.C.EDITION }
            end
        end
    end,

    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_clars' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,

    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_clars')) then
            card:start_dissolve()
        end
    end,

    remove_from_deck = function(self, card)
        local spawnedKeys = {
          'j_sbeven_pad',
          'j_sbeven_rutile',
          'j_sbeven_fluorite',
          'j_sbeven_rhodonite_off',
          'j_sbeven_black',
        }
        for _, key in ipairs(spawnedKeys) do
            for _, offColor in ipairs(SMODS.find_card(key)) do
                offColor:start_dissolve()
            end
        end
    end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}



SMODS.Joker{ --- Rhodonite
    key = 'rhodonite_off', --joker key
    loc_txt = { -- local text
        name = '{C:tarot,E:1}Rhodonite{}', --name of joker
        text = {
          'Each {C:attention,E:2}played card{} gives {X:mult,C:white,E:1}X#1#{} Mult when scored,',
          'and also {C:attention,E:2}permanently gains{} {X:mult,C:white,E:1}X#2#{} Mult,',
          'if played hand is a {C:attention,E:2}Pair{}.',
          '{s:0.8,C:tarot,E:1}Welp... We\'re cracked.{}',
          '{s:0.7,C:legendary,E:1}- From \"Change Your Mind\"{}'
        },
        --[[unlock = {
            'Be {C:legendary}cool{}',
        }]]
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Off', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 111, --cost
    unlocked = true, --where it is unlocked or not: if true, 
    discovered = true, --whether or not it starts discovered
    blueprint_compat = true, --can it be blueprinted/brainstormed/other
    eternal_compat = true, --can it be eternal
    perishable_compat = true, --can it be perishable
    pos = {x = 0, y = 2}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            rhodonite_x_mult = 3,            -- temporary mult on scored card (Ruby's effect)
            rhodonite_perma_x_mult = 0.25,   -- permanent mult gain (Pearl's effect)
            slots = 2
        }
    },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.extra.rhodonite_x_mult,
                card.ability.extra.rhodonite_perma_x_mult
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual 
        and context.cardarea == G.play then
            if context.scoring_name == 'Pair'
            or context.scoring_name == 'sbeven_The Authority' then
                local oc = context.other_card
                -- Ruby-like temp mult boost
                local result = {
                    x_mult = rhodonite_x_mult,
                    message = 'Captain Lars?!',
                    card = oc,
                    colour = G.C.MULT,
                    func = function() oc:juice_up(0.6, 0.6) end
                }
                -- Pearl-like permanent mult boost
                oc.ability.rhodonite_perma_x_mult = (oc.ability.rhodonite_perma_x_mult or 0) + card.ability.extra.rhodonite_perma_x_mult
                return result
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_ruby' }
            --SMODS.add_card{ key = 'j_sbeven_pearl' }
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_rhodonite_off' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_rhodonite_off')) then
            card:start_dissolve()
        end
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Aventurine/Emerald (Fusion of Lapis + Peridot) [ has  bucnh of other names too]
    key = 'aventurine',
    loc_txt = {
        name = '{C:blue,E:1,s:1.15}T{C:green,E:1,s:1.15}u{C:blue,E:1,s:1.15}r{C:green,E:1,s:1.15}q{C:blue,E:1,s:1.15}u{C:green,E:1,s:1.15}o{C:blue,E:1,s:1.15}i{C:green,E:1,s:1.15}s{C:blue,E:1,s:1.15}e{}',
        text = {
            '{X:dark_edition,C:white,E:1}^#1#{} {C:white,E:1,X:dark_edition}Mult{} and {X:gold,C:white,E:1}$#2#{} when {C:attention}ability is triggered{}.',
            'If {C:attention}played hand{} contains at least {C:attention}1{} scoring {C:attention}7{},',
            'creates {C:attention,E:1}3{} random {C:dark_edition,E:2}negative{T:edition_negative}{} consumables of {C:attention}each type{},',
            'and {C:attention,E:1}3{} {C:dark_edition,E:1}negative{} {C:spectral,E:1}Black Holes{}.',
            '{C:hearts,s:0.8}Guys, that\'s art!{}',
            '{C:green,s:0.8}\"Art\"? That sounds ridiculous!{}',
            '{C:blue,s:0.8}I\'ve been calling it{} {C:blue,s:0.8,E:1}\"meep-morp\".{}',
            '{C:dark_edition,s:0.75,E:1}(also known as Aventurine){}',
            '{E:1,s:0.7,C:legendary}- From \"Beta\"{}'
        }
    },
    atlas = 'Lapis&Peridot',
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 275,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0},
    credit = {
        art = "artifiziell",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = {
        aventurine_e_mult = 2,
        aventurine_money = 50 --configurable value
      }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.aventurine_e_mult,
            card.ability.extra.aventurine_money
        }}
    end,
	calculate = function(self, card, context)
		if context.joker_main then
			local seven_count = 0
			for i = 1, #context.scoring_hand do
				if context.scoring_hand[i]:get_id() == 7 then
					seven_count = seven_count + 1
				end
			end
			if seven_count >= 1 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.dollars = G.GAME.dollars + card.ability.extra.aventurine_money
                        play_sound('chips1', 0.9 + math.random()*0.1, 0.7)
                        return true
                    end
                }))  
				G.E_MANAGER:add_event(Event({
					func = function()
						for i = 1, 3 do
							SMODS.add_card { key = 'c_black_hole', edition = 'e_negative' }
                            SMODS.add_card { set = 'Tarot', edition = 'e_negative' }
                            SMODS.add_card { set = 'Planet', edition = 'e_negative' }
                            SMODS.add_card { set = 'Spectral', edition = 'e_negative' }
                        end
						return true
					end
				}))
				return {
					message = "Steven! :)",
                    colour = G.C.EDITION,
                    e_mult = card.ability.extra.aventurine_e_mult,
				}
			end
		end
	end,-- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_lapis' }
            --SMODS.add_card{ key = 'j_sbeven_peridot' }
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_aventurine' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_aventurine')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Rainbow Quartz
    key = 'rainbow',
    loc_txt = {
        name = '{C:diamonds,s:1.15}R{C:hearts,s:1.15}a{C:diamonds,s:1.15}i{C:hearts,s:1.15}n' ..
               '{C:diamonds,s:1.15}b{C:hearts,s:1.15}o{C:diamonds,s:1.15}w ' ..
               '{C:diamonds,s:1.15}Q{C:hearts,s:1.15}u{C:diamonds,s:1.15}a' ..
               '{C:hearts,s:1.15}r{C:diamonds,s:1.15}t{C:hearts,s:1.15}z{}',
        text = {
            'Playing cards of {C:diamonds,E:2}Diamonds{} suit',
            'each give {X:mult,C:white,E:1}X#1#{} Mult, {C:white,X:dark_edition,E:1}^#3#{} Mult',
            'and {X:gold,C:white,E:1}$#4#{} when scored.',
            'All playing cards {C:attention,E:1}permanently gain{}',
            '{X:mult,C:white,E:1}X#2#{} Mult when scored.',
            'Creates a {C:dark_edition,E:1}negative{} {C:attention,E:2}The Star{},',
            'if played hand contains a {C:attention,E:2}Flush{}.',
            '{C:purple,s:0.8,E:1}What can I do for you?{}',
            '{C:purple,s:0.8,E:1}What can I that no one else can do?{}',
            '{E:1,s:0.7,C:legendary}- From "We Need to Talk"{}',
        },
    },
    atlas = 'Jokers',
    rarity = 'sbeven_Fusion',
    cost = 400,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = { x = 8, y = 1 },
    credit = {
        art     = "Crewniverse",
        code    = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            rainbow_x_mult       = 7,    -- temporary Ruby‐style boost
            rainbow_perma_mult   = 0.75,  -- Pearl‐style perma gain
            rainbow_e_mult       = 1.3,
            rainbow_money        = 8
        }
    },
    loc_vars = function(self, info_queue, card)
        return { vars = {
            card.ability.extra.rainbow_x_mult,
            card.ability.extra.rainbow_perma_mult,
            card.ability.extra.rainbow_e_mult,
            card.ability.extra.rainbow_money
        } }
    end,

    calculate = function(self, card, context)
        local cfg   = self.config.extra or {}
        local perma = cfg.perma_x_mult or 0.75
        ----------------------------------------
        -- (A) Flush‐triggered star & cash
        if context.joker_main
        and (context.scoring_name == 'Flush'
            or context.scoring_name == 'Straight Flush'
            or context.scoring_name == 'Flush House'
            or context.scoring_name == 'sbeven_The Authority'
            or context.scoring_name == 'Flush Five') then
            G.E_MANAGER:add_event(Event({ func = function()
                G.GAME.dollars = G.GAME.dollars + self.config.extra.rainbow_money
                play_sound('chips1', 0.9 + math.random()*0.1, 0.7)
                return true
            end }))
            G.E_MANAGER:add_event(Event({ func = function()
                SMODS.add_card{ key = 'c_star', edition = 'e_negative' }
                return true
            end }))
        end
        if context.individual and context.cardarea == G.play then
          local scored = context.other_card
      
          -- 1) Permanent +0.75 on every scored card
          scored.ability.perma_x_mult = (scored.ability.perma_x_mult or 0) + perma
          
        if context.individual and context.cardarea == G.play then
            if scored.base.suit == 'Diamonds' then
                G.E_MANAGER:add_event(Event({ func = function()
                    G.GAME.dollars = G.GAME.dollars + self.config.extra.rainbow_money
                    play_sound('chips1', 0.9 + math.random()*0.1, 0.7)
                    return true
                end }))
                return {
                    x_mult  = self.config.extra.rainbow_x_mult,
                    e_mult  = self.config.extra.rainbow_e_mult,
                    message = 'Glamour!',
                    colour  = G.C.MULT,
                    func    = function() scored:juice_up(0.5, 0.5) end
                }
            end
        end
    end
    end,

    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_rainbow' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,

    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_rainbow')) then
            card:start_dissolve()
        end
    end,

    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}



SMODS.Joker{ -- Rainbow 2.0
    key = 'rainbow2', --joker key
    loc_txt = {
        name = '{C:diamonds,s:1.13}R{C:hearts,s:1.13}a{C:diamonds,s:1.13}i{C:hearts,s:1.13}n{C:diamonds,s:1.13}b{C:hearts,s:1.13}o{C:diamonds,s:1.13}w{C:hearts,s:1.13} {C:diamonds,s:1.13}2{C:hearts,s:1.13}.{C:diamonds,s:1.13}0{}',
        text = {
            'Playing cards of {C:diamonds,E:2}Diamonds{} and {C:hearts,E:2}Hearts{} suits',
            'each give {X:mult,C:white,E:1}X3{} Mult when scored.',
            'All playing cards also {C:attention,E:1}permanently gain{}',
            '{X:mult,C:white,E:1}X0.5{} Mult when scored.',
            'Creates a {C:dark_edition,E:1}negative{} {C:attention,E:2}The Star{} and {C:attention,E:2}The Sun{},',
            'if played hand contains a {C:attention,E:2}Flush{}.',
            '{C:mult,s:0.8,E:1}Well, what do you know? It\'s Rainbow 2.0!{}',
            '{E:1,s:0.7,C:legendary}- From \"Change Your Mind\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 401,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 9, y = 1}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    calculate = function(self, card, context)
        local cfg   = self.config.extra or {}
        local perma = cfg.perma_x_mult or 0.5     -- 0.75
        local tmp   = cfg.Xmult        or 3     -- 5
      
        ----------------------------------------
        -- MAIN HAND PASS: spawn negative Star on any Flush
        if context.joker_main
           and (context.scoring_name == 'Flush'
                or context.scoring_name == 'Straight Flush'
                or context.scoring_name == 'Flush House'
                or context.scoring_name == 'sbeven_The Authority'
                or context.scoring_name == 'Flush Five')
        then
          G.E_MANAGER:add_event(Event({
            func = function()
              SMODS.add_card{ key = 'c_star', edition = 'e_negative' }
              SMODS.add_card{ key = 'c_sun', edition = 'e_negative' }
              return true
            end
          }))
          -- **no return** here so we fall through to individual logic
        end
      
        ----------------------------------------
        -- PER‐CARD PASS: apply permanent bonus + Diamonds check
        if context.individual and context.cardarea == G.play then
          local scored = context.other_card
      
          -- 1) Permanent +0.75 on every scored card
          scored.ability.perma_x_mult = (scored.ability.perma_x_mult or 0) + perma
      
          -- 2) If that card is Diamonds suit, give temporary +5 Mult
          if scored.base.suit == 'Diamonds' or scored.base.suit == 'Hearts' then
            return {
              x_mult  = tmp,
              message = 'That won\'t do!',
              colour  = G.C.MULT,
              func    = function() scored:juice_up(0.5, 0.5) end
            }
          end
      
          -- 3) Otherwise, no return = silent perma only
        end
      end,
        -- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_pearl' }
            --SMODS.add_card{ key = 'j_sbeven_steven' }
            return true
        end }))
    end,    
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_rainbow2' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,

    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_rainbow2')) then
            card:start_dissolve()
        end
    end,

    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Smokey Quartz
    key = 'smokey', --joker key
    loc_txt = {
        name = '{C:default,s:1.4}S{C:inactive,s:1.4}m{C:default,s:1.4}o{C:inactive,s:1.4}k{C:default,s:1.4}y{C:inactive,s:1.4} {C:default,s:1.4}Q{C:inactive,s:1.4}u{C:default,s:1.4}a{C:inactive,s:1.4}r{C:default,s:1.4}t{C:inactive,s:1.4}z{}',
        text = {
            'Playing cards of {C:hearts,E:1}Hearts{} and {C:diamonds,E:1}Diamonds{} suits',
            'each give {X:mult,C:white,E:1}X#1#{} Mult and {X:chips,C:white,E:1}X#1#{} Chips when scored.',
            'If played hand is a {C:attention,E:2}Five of a Kind{} or a {C:attention,E:2}Flush Five{},',
            'create {C:edition,E:1}A Single Pale Rose{}.',
            '{C:enhanced,s:0.8,E:1}I think a Rose Quartz and an Amethyst make a... Smoky Quartz!{}',
            '{C:legendary,s:0.7,E:1}- From \"Earthlings\"{}'

        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 120,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 5, y = 2}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            smokey_x_mult_x_chips = 4
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.smokey_x_mult_x_chips,
        }}
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit   = scored.base.suit
            if suit == 'Diamonds' or suit == 'Hearts' then
                return {
                    x_mult  = card.ability.extra.smokey_x_mult_x_chips,
                    x_chips = card.ability.extra.smokey_x_mult_x_chips,
                    message = 'What a BEAU-TI-FUL day!',
                    colour  = G.C.EDITION,
                    func    = function() scored:juice_up(0.5, 0.5) end,
                }
            end
        end
        if context.joker_main and (context.scoring_name == 'Five of a Kind' 
        or context.scoring_name == 'Flush Five'
        or context.scoring_name == 'sbeven_The Authority') then
            G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'j_sbeven_pale_rose', edition = 'e_negative' } 
                return true 
            end}))
            return {
                message = 'Nice to meet ya.',
                colour = G.C.EDITION,
            }
        end
    end,-- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_steven' }
            --SMODS.add_card{ key = 'j_sbeven_amethyst' }
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_smokey' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_smokey')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Sunstone
    key = 'sunstone', --joker key
    loc_txt = {
        name = '{C:hearts}S{C:diamonds}u{C:hearts}n{C:diamonds}s{C:hearts}t{C:diamonds}o{C:hearts}n{C:diamonds}e{}',
        text = {
            'Played cards of {C:diamonds,E:2}Diamonds{} and {C:hearts,E:2}Hearts{} suits',
            'each give {X:mult,C:white,E:1}X#1#{} Mult and {X:chips,C:white,E:1}X#1#{} Chips when scored.',
            'Creates a {C:dark_edition,E:1}negative{} {C:attention,E:2}The Star{} and {C:attention,E:2}The Sun{},',
            'if played hand contains a {C:attention,E:2}Flush{}.',
            '{C:diamonds,s:0.8,E:1}Chillax, my dudes. Your rockin\' pal{} {C:diamonds,s:0.8,E:1}Sunstone{} {C:diamonds,s:0.8,E:1}is holdin\' it down.{}',
            '{C:legendary,s:0.7,E:1}- From \"Change Your Mind\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 200,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 3}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
          sun_x_mult_x_chips = 10,
        }
      },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.sun_x_mult_x_chips
        }}
    end,
    calculate = function(self, card, context) 
        ------------------------------------------------
        -- 1) Main‐hand pass: spawn tarot on any Flush
        if context.joker_main
        and (context.scoring_name == 'Flush'
            or context.scoring_name == 'Flush House'
            or context.scoring_name == 'sbeven_The Authority'
            or context.scoring_name == 'Flush Five') then
                G.E_MANAGER:add_event(Event({
                func = function()
                SMODS.add_card{ key = 'c_sun',   edition = 'e_negative' }
                SMODS.add_card{ key = 'c_star',  edition = 'e_negative' }
                return true
            end
            }))
        end
    
        ------------------------------------------------
        -- 2) Per‐card pass: give X10/X10 on Diamonds or Hearts
        if context.individual and context.cardarea == G.play then
          local scored = context.other_card
          local suit   = scored.base.suit
    
          if suit == 'Diamonds' or suit == 'Hearts' then
            return {
              x_mult  = card.ability.extra.sun_x_mult_x_chips,
              x_chips = card.ability.extra.sun_x_mult_x_chips,
              message = 'Bungacowa!',
              colour  = G.C.EDITION,
              func    = function() scored:juice_up(0.5, 0.5) end
            }
          end
        end
    end,-- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_steven' }
           -- SMODS.add_card{ key = 'j_sbeven_garnet' }
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_sunstone' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_sunstone')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Sardonyx
    key = 'sardonyx', --joker key
    loc_txt = {
        name = '{C:gold,s:1.4}S{C:diamonds,s:1.4}a{C:gold,s:1.4}r{C:diamonds,s:1.4}d{C:gold,s:1.4}o{C:diamonds,s:1.4}n{C:gold,s:1.4}y{C:diamonds,s:1.4}x{}',
        text = {
            'Playing cards each give {X:mult,C:white,E:1}X#1#{} Mult and {X:chips,C:white,E:1}X#1#{} Chips when scored,',
            'if played hand contains a {C:attention,E:2}Three of a Kind{}.',
            'Playing cards also {C:attention,E:2}permanently gain{} {X:mult,C:white,E:1}X#3#{} Mult when scored.',
            'If played hand is a {C:attention,E:2}Five of a Kind{} or a {C:attention,E:2}Flush Five{},',
            'create {C:edition,E:1}A Single Pale Rose{} and gives {C:white,X:dark_edition}^#2#{} Mult.',
            '{C:diamonds,s:0.8,E:1}Good evening, everybody! This is the lovely Sardonyx,{}',
            '{C:diamonds,s:0.8,E:1}coming to you a-live from the soon-to-be former Communication Hub!{}',
            '{C:diamonds,s:0.8,E:1}How are y\'all doin\' tonight?{}',
            '{C:legendary,s:0.7,E:1}- From \"Cry for Help\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 275,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 4, y = 2}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            sardonyx_x_multchips = 12,
            sardonyx_e_mult = 3,
            perma_x_mult = 0.75
        }
    },

    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.extra.sardonyx_x_multchips,
                card.ability.extra.sardonyx_e_mult,
                card.ability.extra.perma_x_mult,
            }
        }
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local oc = context.other_card
            oc.ability.perma_x_mult = (oc.ability.perma_x_mult or 0) + card.ability.extra.perma_x_mult

            if context.scoring_name == 'Three of a Kind'
            or context.scoring_name == 'Four of a Kind' 
            or context.scoring_name == 'Five of a Kind' 
            or context.scoring_name == 'Flush Five'
            or context.scoring_name == 'Full House' 
            or context.scoring_name == 'sbeven_The Authority'
            or context.scoring_name == 'Flush House' then
                return {
                x_mult = card.ability.extra.sardonyx_x_multchips,
                x_chips = card.ability.extra.sardonyx_x_multchips,
                card = oc,
                colour = G.C.EDITION,
                message = 'Was I worth the wait?',
                func = function() oc:juice_up(0.5, 0.5) end,
            }
        end
    end
    if context.joker_main 
    and (context.scoring_name == 'Five of a Kind' 
    or context.scoring_name == 'Flush Five'
    or context.scoring_name == 'sbeven_The Authority') then
        G.E_MANAGER:add_event(Event({ func = function()
                SMODS.add_card{ key = 'j_sbeven_pale_rose', edition = 'e_negative' } 
            return true 
        end}))
        return {
            message = 'Sardonyx Tonight!',
            colour = G.C.EDITION,
            e_mult = card.ability.extra.sardonyx_e_mult,
        }
    end
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_sardonyx' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_garnet' }
            --SMODS.add_card{ key = 'j_sbeven_pearl' }
            return true
        end }))
    end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_sardonyx')) then
            card:start_dissolve()
        end
    end
    
}


SMODS.Joker{ -- Sugilite
    key = 'sugilite', --joker key
    loc_txt = {
        name = '{C:purple,s:1.4}S{C:tarot,s:1.4}u{C:purple,s:1.4}g{C:tarot,s:1.4}i{C:purple,s:1.4}l{C:tarot,s:1.4}i{C:purple,s:1.4}t{C:tarot,s:1.4}e{}',
        text = {
            'Each played cards give {X:mult,C:white,E:1}X#1#{} Mult and {X:chips,C:white,E:1}X#1#{} Chips when scored,',
            'if played hand contains a {C:attention,E:2}Three of a Kind{}.',
            'Each played cards also {C:attention,E:2}permanently gains{} {X:chips,C:white,E:1}X#3#{} Chips when scored.',
            'If played hand is a {C:attention,E:2}Five of a Kind{} or a {C:attention,E:2}Flush Five{},',
            'create {C:edition,E:1}A Single Pale Rose{} and gives {C:white,X:dark_edition}^#2#{} Mult.',
            '{C:tarot,s:0.8,E:1}You think you\'re something?{}',
            '{C:tarot,s:0.8,E:1}You ain\'t nothing!{}',
            '{C:legendary,s:0.7,E:1}- From \"Coach Steven\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_UFusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 300,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 9, y = 2}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            sugilite_x_chipsmult = 15,
            sugilite_e_mult = 4,
            perma_x_chips = 0.75
        }
    },

    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.extra.sugilite_x_chipsmult,
                card.ability.extra.sugilite_e_mult,
                card.ability.extra.perma_x_chips,
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local oc = context.other_card
    
            -- Apply permanent bonus always
            oc.ability.perma_x_chips = (oc.ability.perma_x_chips or 0) + card.ability.extra.perma_x_chips
    
            -- Temporary scoring bonus only if it's a Pair
            if context.scoring_name == 'Three of a Kind'
            or context.scoring_name == 'Four of a Kind' 
            or context.scoring_name == 'Five of a Kind' 
            or context.scoring_name == 'Flush Five'
            or context.scoring_name == 'Full House' 
            or context.scoring_name == 'sbeven_The Authority'
            or context.scoring_name == 'Flush House' then
                return {
                    x_chips = card.ability.extra.sugilite_x_chipsmult,
                    x_mult = card.ability.extra.sugilite_x_chipsmult,
                    card = oc,
                    colour = G.C.CHIPS,
                    message = "You ain't nothing!",
                    func = function() oc:juice_up(0.6, 0.6) end
                }
            end
        end
        if context.joker_main 
        and (context.scoring_name == 'Five of a Kind' 
        or context.scoring_name == 'Flush Five'
        or context.scoring_name == 'sbeven_The Authority') then
            G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'j_sbeven_pale_rose', edition = 'e_negative' } 
                return true 
            end}))
            return {
                message = 'It feels great to be me!',
                colour = G.C.EDITION,
                e_mult = card.ability.extra.sugilite_e_mult,
            }
        end 
    end,
    remove_from_deck = function(self, card)
        G.E_MANAGER:add_event(Event({ func = function()
            --SMODS.add_card{ key = 'j_sbeven_garnet' }
            --SMODS.add_card{ key = 'j_sbeven_amethyst' }
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_sugilite' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_sugilite')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Alexandrite
    key = 'alex', --joker key
    loc_txt = {
        name = '{C:tarot,E:1,s:1.7}A{C:enhanced,E:1,s:1.7}l{C:legendary,E:1,s:1.7}e{C:uncommon,E:1,s:1.7}x{C:tarot,E:1,s:1.7}a{C:enhanced,E:1,s:1.7}n{C:legendary,E:1,s:1.7}d{C:uncommon,E:1,s:1.7}r{C:tarot,E:1,s:1.7}i{C:enhanced,E:1,s:1.7}t{C:legendary,E:1,s:1.7}e{}',
        text = { 
            'Each played cards give {X:mult,C:white,E:1}X#1#{} Mult and {X:chips,C:white,E:1}X#1#{} Chips',
            'and {C:white,X:dark_edition,E:1}^#2#{} {C:white,X:dark_edition,E:1}Chips&Mult{} when scored,',
            'if played hand contains a {C:attention,E:2}Four of a Kind{}.',
            'Playing cards also {C:attention,E:2}permanently gain{} {X:mult,C:white,E:1}X#3#{} Mult and', 
            '{X:chips,C:white,E:1}X#4#{} Chips when scored.',
            'If played hand is a {C:attention,E:2}Five of a Kind{} or a {C:attention,E:2}Flush Five{},',
            'create {C:edition,E:1}A Single Pale Rose{} and gives {X:dark_edition,C:white,E:1}^#5#{} {C:white,X:dark_edition,E:1}Chips&Mult{}.',
            '{C:tarot,s:0.8,E:1}You{} {C:diamonds,s:0.8,E:2}t{}{C:blue,s:0.8,E:2}w{C:diamonds,s:0.8,E:2}o{} {C:tarot,s:0.8,E:1}should spennd some time apart.{}',
            '{C:legendary,s:0.7,E:1}- From \"Super Watermelon Island\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 250,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            alex_x_multchips = 25,
            alex_e_multchips = 1.5,
            alex_special_e_mult = 2,
            perma_x_mult = 1,
            perma_x_chips = 1
        }
    },
    loc_vars = function(self, info_queue, card)
        return {
            vars = {
                card.ability.extra.alex_x_multchips,
                card.ability.extra.alex_e_multchips,
                card.ability.extra.perma_x_mult,
                card.ability.extra.perma_x_chips,
                card.ability.extra.alex_special_e_mult
            }
        }
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local oc = context.other_card

            oc.ability.perma_x_mult = (oc.ability.perma_x_mult or 0) + card.ability.extra.perma_x_mult
            oc.ability.perma_x_chips = (oc.ability.perma_x_chips or 0) + card.ability.extra.perma_x_chips

            if context.scoring_name == 'Four of a Kind' 
            or context.scoring_name == 'Five of a Kind' 
            or context.scoring_name == 'sbeven_The Authority'
            or context.scoring_name == 'Flush Five' then
                return {
                    x_mult = card.ability.extra.alex_x_multchips,
                    x_chips = card.ability.extra.alex_x_multchips,
                    e_chips = card.ability.extra.alex_e_multchips,
                    e_mult = card.ability.extra.alex_e_multchips,
                    card = oc,
                    colour = G.C.EDITION,
                    message = 'Steveeen!',
                    func = function() oc:juice_up(0.5, 0.5) end
                }
            end
        end

        if context.joker_main 
        and (context.scoring_name == 'Five of a Kind' 
        or context.scoring_name == 'Flush Five'
        or context.scoring_name == 'sbeven_The Authority') then
            G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'j_sbeven_pale_rose', edition = 'e_negative' } 
                return true 
            end}))
            return {
                message = 'Hey! Don\'t forget about me!',
                colour = G.C.EDITION,
                e_mult = card.ability.extra.alex_special_e_mult,
                e_chips = card.ability.extra.alex_special_e_mult,
            }
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_alex' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_alex')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{
    key = 'obsidian',
    loc_txt = {
        name = '{C:legendary,E:1,s:1.8}O{C:hearts,E:1,s:1.8}b{C:planet,E:1,s:1.8}s{C:purple,E:1,s:1.8}i{C:tarot,E:1,s:1.8}d{C:inactive,E:1,s:1.8}i{C:legendary,E:1,s:1.8}a{C:hearts,E:1,s:1.8}n{}',
        text = {
            'Each played card gives {X:mult,C:white,E:1}X50{} Mult and {X:chips,C:white,E:1}X50{} Chips',
            'and {C:white,X:dark_edition,E:1}^2{} {C:white,X:dark_edition,E:1}Chips&Mult{} when scored,',
            'if played hand contains a {C:attention,E:2}Five of a Kind{}.',
            'Playing cards also {C:attention,E:2}permanently gain{} {X:mult,C:white,E:1}X2{} Mult and',
            '{X:chips,C:white,E:1}X2{} Chips when scored.',
            'If played hand is a {C:attention,E:2}Five of a Kind{} or a {C:attention,E:2}Flush Five{},',
            'create {C:dark_edition,E:1}negative{} {C:attention,E:2}Black Hole{}, a {C:dark_edition,E:1}negative{} {C:attention,E:2}Cryptid{},',
            'a {C:dark_edition,E:1}negative{} {C:attention,E:2}The Soul{}, and gives {X:dark_edition,C:white,E:1}^3{} {C:white,X:dark_edition,E:1}Chips&Mult{}.',
            '{C:green,s:0.8,E:1}They\'re huuuuge!{}',
            '{C:inactive,s:0.8,E:1}amazing art by @jasbear.art on TikTok{}',
            '{C:legendary,s:0.7,E:1}- From \"Change Your Mind\"{}'
        }
    },
    atlas = 'Obsidian',
    rarity = 'sbeven_PFusion',
    cost = 750,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0},
    credit = {
        art = "@jasbear.art",
        code = "Pink Focalors",
        concept = "@jasbear.art"
    },
    config = {
        extra = {
            Xmult = 50,
            Xchips = 50,
            repetitions = 2,
            perma_x_mult = 2,
            perma_x_chips = 2,
            card_limit = 2
        }
    },
    loc_vars = function(self, info_queue, center)
        local vars = {0, 0, 0, 0}
        if center and center.ability and center.ability.extra then
            vars = {
                center.ability.extra.Xmult or 0,
                center.ability.extra.Xchips or 0,
                center.ability.extra.perma_x_mult or 0,
                center.ability.extra.perma_x_chips or 0,
                center.ability.extra.card_limit or 2
            }
        end
        return { vars = vars }
    end,
    calculate = function(self, card, context)
        local extra = card.ability and card.ability.extra or {}

        if context.individual and context.cardarea == G.play and context.other_card then
            local oc = context.other_card
            oc.ability = oc.ability or {}

            -- Apply permanent multipliers
            oc.ability.perma_x_mult = (oc.ability.perma_x_mult or 0) + (extra.perma_x_mult or 0)
            oc.ability.perma_x_chips = (oc.ability.perma_x_chips or 0) + (extra.perma_x_chips or 0)

            if context.scoring_name == 'Five of a Kind' 
            or context.scoring_name == 'Flush Five' 
            or context.scoring_name == 'sbeven_The Authority' then
                return {
                    x_mult = extra.Xmult or 50,
                    x_chips = extra.Xchips or 50,
                    e_chips = 2,
                    e_mult = 2,
                    card = oc,
                    colour = G.C.EDITION,
                    message = 'Change Your Mind!',
                    func = function() oc:juice_up(0.5, 0.5) end
                }
            end
        end

        if context.joker_main 
        and (context.scoring_name == 'Five of a Kind' 
        or context.scoring_name == 'Flush Five'
        or context.scoring_name == 'sbeven_The Authority') then
            G.E_MANAGER:add_event(Event({ func = function()
                SMODS.add_card{ key = 'c_black_hole', edition = 'e_negative' }
                SMODS.add_card{ key = 'c_soul', edition = 'e_negative' }
                SMODS.add_card{ key = 'c_cryptid', edition = 'e_negative' }
                return true
            end }))
            return {
                message = 'The Crystal Temple...',
                colour = G.C.EDITION,
                e_mult = 3,
                e_chips = 3
            }
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_obsidian' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_obsidian')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_obsidian_sword", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_obsidian_sword')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end
}



SMODS.Joker{ --Zebra
    key = 'zebra', --joker key
    loc_txt = {
        name = '{C:diamonds}Z{C:gold}e{C:diamonds}b{C:gold}r{C:diamonds}a{C:gold} {C:diamonds}J{C:gold}a{C:diamonds}s{C:gold}p{C:diamonds}e{C:gold}r{}',
        text = {
            '{C:white,X:dark_edition,s:1.25,E:1}^#1#{} {C:white,X:mult}Mult{} and {C:white,X:dark_edition,s:1.25,E:1}^#2#{} {C:white,X:chips}Chips{} if played hand contains a {C:attention}Pair{}.',
            '{C:diamonds,s:0.8,E:2}I\'ve been fighting since I broke free from the Earth\'s crust!{}',
            '{C:diamonds,s:0.8,E:2}Because of what{} {C:hearts,s:0.8,E:1}you{} {C:diamonds,s:0.8,E:2}did to my colony,{}',
            '{C:diamonds,s:0.8,E:}Because of what{} {C:hearts,s:0.8,E:1}you{} {C:diamonds,s:0.8,E:2}did to my planet,{}',
            '{C:diamonds,s:0.8,E:2}Because of what{} {C:hearts,s:0.8,E:1}you{} {C:diamonds,s:0.8,E:2}did to my{} {C:hearts,s:0.8,E:1}Diamond!{}',
            '{C:legendary,s:0.7,E:1}- From \"Earthlings\"{}'
        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Monster', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 375,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 4, y = 3}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
      extra = {
        zebra_e_mult = 1.75,
        zebra_e_chips = 1.5 --configurable value
      }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.zebra_e_mult,
            card.ability.extra.zebra_e_chips
        }}
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            if context.scoring_name == 'Pair' 
            or context.scoring_name == 'Three of a Kind' 
            or context.scoring_name == 'Two Pair'
            or context.scoring_name == 'Four of a Kind'
            or context.scoring_name == 'Flush'
            or context.scoring_name == 'Full House'
            or context.scoring_name == 'Straight'
            or context.scoring_name == 'Straight Flush'
            or context.scoring_name == 'sbeven_The Authority'
            or context.scoring_name == 'Flush House' then
                return {
                    message  = 'My Diamond…',
                    e_mult   = card.ability.extra.zebra_e_mult,
                    e_chips  = card.ability.extra.zebra_e_chips,
                    colour   = G.C.EDITION,
                    card     = card
                }
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_zebra' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_zebra')) then
            card:start_dissolve()
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Corrupter Steven
    key = 'monster', --joker key
    loc_txt = {
        name = '{C:legendary,E:1,s:2}Corrupted Steven{}',
        text = {
            'Each playing card gives {E:1,C:white,X:dark_edition,s:1.25}^^#1#{} {X:dark_edition,C:edition,E:1}Chips&Mult{}',
            'if played hand contains a {C:attention,E:2}High Card{}.',
            '{C:hearts,s:0.8,E:2}No! No-n-n-n-no! Th-Th-This isn\'t happening...! I didn\'t think about shattering{} {C:edition,s:0.8}White{}.',
            '{C:hearts,s:0.8,E:2}I-I-I didn\'t shatter{} {C:diamonds,s:0.8}Jasper{}. {C:hearts,s:0.8}I didn\'t fight with Dad.',
            '{C:hearts,s:0.8,E:2}I-I\'m Steven Universe! I\'m fine. I\'m fine!',
            '{C:legendary,s:0.7,E:1}- From \"Everything\'s Fine\"{}'

        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Monster', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 999,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 1, y = 1}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = { 
            slots = 4,
            monster_ee_multchips = 1.11
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.monster_ee_multchips
        }}
    end,
    calculate = function(self, card, context)
        -- only run on individual card scoring passes
        if context.individual and context.cardarea == G.play then
            local scored = context.other_card
            local suit = scored.base.suit
            if suit == 'Diamonds' 
            or suit == 'Spades' 
            or suit == 'Hearts' 
            or suit == 'Clubs' then
                return {
                    message  = 'I\'m a monster...',
                    ee_mult = card.ability.extra.monster_ee_multchips,
                    ee_chips = card.ability.extra.monster_ee_multchips,
                    colour = G.C.EDITION,
                    card = card
                }
            end
        end
    end,-- Prevent more than one copy from spawning in shops
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_monster' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    remove_from_deck = function(self, card)
        if card.ability and card.ability.extra and card.ability.extra.slots then
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
        end
    end,
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_monster')) then
        card:start_dissolve()
        end
        if card.ability and card.ability.extra and card.ability.extra.slots then
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        end
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}


SMODS.Joker{ -- Mega Pearl
    key = 'mega', --joker key
    loc_txt = {
        name = '{C:hearts,E:1,s:1.2}M{C:red,E:1,s:1.2}e{C:hearts,E:1,s:1.2}g{C:red,E:1,s:1.2}a{C:hearts,E:1,s:1.2} {C:red,E:1,s:1.2}P{C:hearts,E:1,s:1.2}e{C:red,E:1,s:1.2}a{C:hearts,E:1,s:1.2}r{C:red,E:1,s:1.2}l{}',
        text = {
            'All playing cards {C:attention,E:1}permanently gain{}', 
            '{X:mult,C:white,E:1}X0.5{} Mult and {X:chips,C:white,E:1}X0.5{} Chips when scored.',
            'If played hand is a {C:attention,E:1}Pair{}, create a {C:dark_edition,E:1}negative Spectral card.{}',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:hearts,s:0.8,E:1}Your mother\'s Pearls{} {C:hearts,s:0.8,E:2}never had the whole picture.{}',
            '{C:hearts,s:0.8,E:2}One knew{} {C:hearts,s:0.8,E:1}your mother{} {C:hearts,s:0.8,E:2}was trying to change,{}',
            '{C:hearts,s:0.8,E:2}but she couldn\'t understand why.{}',
            '{C:hearts,s:0.8,E:2}The other never expected her to change at all.{}',
            '{C:hearts,s:0.8,E:2}Now, I get to understand everything.{}',
            '{C:hearts,s:0.8,E:2}Now, they finally get to have each other.{}',
            '{C:legendary,s:0.7,E:1}- From \"Volleyball\"{}'

        }
    },
    atlas = 'Jokers', --atlas' key
    rarity = 'sbeven_Fusion', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 150,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 1}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            perma_x_mult = 0.5, --configurable value
            perma_x_chips = 0.5, --configurable value
            card_limit = 2,
        }
    },

    --loc_vars = function(self, info_queue, card)
    --    return {vars = {card.ability.extra.perma_x_mult, card.ability.extra.perma_x_chips}} --displays configurable value: the #1# in the description is replaced with the configurable value
    --end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            local oc = context.other_card
            oc.ability.perma_x_mult = oc.ability.perma_x_mult or 0
            oc.ability.perma_x_chips = oc.ability.perma_x_chips or 0
            oc.ability.perma_x_mult = oc.ability.perma_x_mult + 0.5
            oc.ability.perma_x_chips = oc.ability.perma_x_chips + 0.5
            return { 
                extra = { message = 'It\'s up to you now, Steven.', color = G.C.SUITS.Hearts }
            }
        end
        if context.joker_main and context.scoring_name == 'Pair' then
            G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ set = 'Spectral', edition = 'e_negative' } 
                return true 
            end}))
            return {
                message = 'Pink...',
                colour = G.C.EDITION,
            }
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_drill_wand", stickers = {"eternal"} }
                return true
            end}))
        end  
    end,-- Prevent more than one copy from spawning in shops
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_drill_wand')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            SMODS.add_card{ key = 'j_sbeven_pearl' }
            SMODS.add_card{ key = 'j_sbeven_volleyball' }
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_mega' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    
    -- If an extra copy somehow lands in the deck (e.g. via debuff), dissolve it immediately
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_mega')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
            SMODS.add_card{ key = "c_sbeven_drill_wand", stickers = {"eternal"} }
            return true
        end}))
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{
    key = "cluster",
    loc_txt = {
        name = '{C:dark_edition,E:1,s:1.5}The Cluster{}',
        text = {
            '{C:attention}Destroys{} all held consumables at {C:attention}end of round{}.',
            'Gain {C:white,X:mult}X#1#{} mult per consumable destroyed.',
            '{C:inactive}Currently {C:white,X:mult}X#2#{} {C:inactive}Mult.',
            '{C:green,s:0.8,E:1}These early experiments only combine two or three shards.',
            '{C:green,s:0.8,E,1}The Cluster will be a billion times bigger.{}',
            '{C:green,s:0.8,E,1}An inseparable fusion capable of destroying worlds,',
            '{C:green,s:0.8,E:1}starting with this one.{}',
            '{s:0.7,C:legendary,E:1}- From \"Gem Drill\"{}'
        }
    },
    name = "The cluster",
    rarity = 'sbeven_Hidden2',
    perishable_compat = false,
    blueprint_compat = true,
    pos = {x = 0, y = 0},
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    cost = 20,
    atlas = 'Cluster',
    config = {extra = {Xmult = 1, Xmult_mod = 1}},
    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Xmult_mod, card.ability.extra.Xmult}}
    end,
    calculate = function(self, card, context)
        if context.end_of_round and not card.getting_sliced and (context.individual or context.repetition) then
            if G.consumeables and #G.consumeables.cards > 0 then
                local destructable_consus = {}
                for i = 1, #G.consumeables.cards do
                    if not G.consumeables.cards[i].ability.eternal and not G.consumeables.cards[i].getting_sliced
                    and (G.consumeables.cards[i].ability.set == "Tarot" 
                    or G.consumeables.cards[i].ability.set == "Planet"
                    or G.consumeables.cards[i].ability.set == "Spectral") then
                        destructable_consus[#destructable_consus+1] = G.consumeables.cards[i]
                    end
                end
                if #destructable_consus > 0 then
                    for _, v in ipairs(destructable_consus) do
                        v.getting_sliced = true
                        G.E_MANAGER:add_event(Event({func = function()
                            card:juice_up(0.8, 0.8)
                            v:start_dissolve({G.C.RED}, nil, 1.6)
                        return true end }))
                        card.ability.extra.Xmult = card.ability.extra.Xmult + card.ability.extra.Xmult_mod
                        card_eval_status_text(card, 'extra', nil, nil, nil, {message = localize{type = 'variable', key = 'a_xmult', vars = {card.ability.extra.Xmult}}})
                    end
                end
            end
        end
        if context.joker_main and card.ability.extra.Xmult ~= 1 then
            return {
                Xmult = card.ability.extra.Xmult,
                message = "FORM!",
                colour = G.C.EDITION
            }
        end
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_cluster')) then
            card:start_dissolve()
        end
    end,
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Carbonado Debut
    key = 'carbonado',
    loc_txt = {
        name = '{C:dark_edition,E:1,s:1.5}Black Diamond{}', -- name of joker
        text = {
            'Each played {C:attention}stone{} card gives {X:chips,C:white}X#1#{} Chips when scored.',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:inactive,s:0.8,E:1}NO LORE TEXT RN',
            '{C:legendary,s:0.7,E:1}- From \"KJD\'s Carbonado Lore\" by artifiziell{}',
        },
    },
    atlas = 'CarbonadoDebut',
    rarity = 'sbeven_Diamond', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 777,
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    pos = {x = 0, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right 
    credit = {
        art = "artifiziell",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
        extra = { 
            card_limit = 3,
            xchips = 3 
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {card.ability.extra.xchips}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
    calculate = function(self, card, context)
        if context.individual 
        and context.cardarea == G.play 
        and SMODS.has_enhancement(context.other_card, 'm_stone') then
            return {
                x_chips = card.ability.extra.xchips or 3,
                colour = G.C.EDITION,
                message = 'Darkness...',
            }, true
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                    SMODS.add_card{ key = "c_sbeven_mural", stickers = {"eternal"} }
                    return true
                end
            }))
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_carbonado' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,    
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_carbonado')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
                G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
                SMODS.add_card{ key = "c_sbeven_mural", stickers = {"eternal"} }
                SMODS.add_card{ key = "j_sbeven_black_pearl" }
                return true
            end
        }))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_mural')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Atlas{ key = "CarbonadoMural", path = "CarbonadoMural.png", px = 71, py = 95 }

SMODS.Consumable{  -- Carbonado's Mural
    key = 'mural',
    set = 'Ability',
    atlas = 'CarbonadoMural',
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = '{C:dark_edition}Black Diamond\'s Mural',
        text = {
            'Applies the {C:attention}stone{} enhancement',
            'to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'artifiziell',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 3,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 3 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_stone'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 3)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        --[[local has_blood = (#SMODS.find_card('j_sbeven_carbonado') > 0)
        if not has_blood then
          card:start_dissolve()
        end]]
        if not from_debuff and next(SMODS.find_card('c_sbeven_mural')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return true end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Joker{ -- Black Pearl
    key = 'black_pearl',
    loc_txt = {
        name = '{C:dark_edition,E:1}Black Pearl{}', -- name of joker
        text = {
            'Gives {C:white,X:chips}X#1#{} per {C:attention}stone{} card in deck.',
            '{C:attention}Stone{} cards also give {C:white,X:money}$#3#{} when scored.',
            '{C:inactive}Currently {C:white,X:chips}X#2#{} {C:inactive}Chips.',
            '{C:diamonds,s:0.8,E:1}NO LORE TEXT RN',
            '{C:legendary,s:0.7,E:1}- From \"Carbonado\'s Lore\" by artifiziell{}',
        },
    },
    atlas = 'Black Pearl', -- atlas' key
    rarity = 'sbeven_Gem', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 17,
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    pos = {x = 0, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right 
    credit = {
        art = "artifiziell",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { extra = { 
        xchips = 0.25,
        dollars = 3
    } },
    loc_vars = function(self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_CENTERS.m_stone

        local stone_tally = 0
        if G.playing_cards then
            for _, playing_card in ipairs(G.playing_cards) do
                if SMODS.has_enhancement(playing_card, 'm_stone') then stone_tally = stone_tally + 1 end
            end
        end
        return { vars = { 
            card.ability.extra.xchips,
            1 + card.ability.extra.xchips * stone_tally,
            card.ability.extra.dollars
        } 
    }
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local stone_tally = 0
            for _, playing_card in ipairs(G.playing_cards) do
                if SMODS.has_enhancement(playing_card, 'm_stone') then stone_tally = stone_tally + 1 end
            end
            return {
                xchips = 1 + (card.ability.extra.xchips * stone_tally)
            }
        end
        if context.individual
        and context.cardarea == G.play 
        and SMODS.has_enhancement(context.other_card, 'm_stone') then
            G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0 ) + card.ability.extra.dollars
            return {
                message = 'Yes, My Diamond...',
                colour = G.C.DARK_EDITION,
                dollars = card.ability.extra.dollars,
                func = function ()
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            G.GAME.dollar_buffer = 0
                            return true
                        end
                    }))
                end
            }
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_black_pearl' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,    
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_black_pearl')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
                SMODS.add_card{ key = "c_tower", stickers = {"eternal"} }
                SMODS.add_card{ key = "c_tower", stickers = {"eternal"} }
                SMODS.add_card{ key = "c_tower", stickers = {"eternal"} }
                return true
            end
        }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Black Diamond
    key = 'black', --joker key
    loc_txt = {
        name = '{C:dark_edition,E:1,s:1.5}Carbonado{}',
        text = {
            '{C:attention}Immediately{} defeat selected {C:attention}blind{}.',
            '{s:0.95,E:1}The Wasteland Queen,{} {C:dark_edition,s:0.95,E:1}Black Diamond{}.', 
            '{C:inactive,s:0.8,E:1}In the beginning, there were two.{}',
            '{C:inactive,s:0.8,E:1}One formed in Light, and one in Dark.{}',
            '{C:inactive,s:0.8,E:1}Designed to perfectly balance each other.',
            '{C:legendary,s:0.7,E:1}- From \"Carbonado\'s Backstory\" by artifiziell{}'
        }
    },
    atlas = 'Black', --atlas' key
    rarity = 'sbeven_Unobtainable', --rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    --soul_pos = { x = 0, y = 0 },
    cost = 7500,
    unlocked = true,
    discovered = true,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    pos = {x = 0, y = 0}, --position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "artifiziell",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    calculate = function(self, card, context)
        if context.setting_blind and not context.blueprint then
            G.E_MANAGER:add_event(Event({
                blocking = false,
                func     = function()
                    if G.STATE == G.STATES.SELECTING_HAND then --edit
                        G.GAME.chips     = G.GAME.blind.chips
                        G.STATE          = G.STATES.HAND_PLAYED
                        G.STATE_COMPLETE = true
                        end_round()
                        return true
                    end
                end
            }))
            return {
                message = "Oh, White...",
                colour = G.C.DARK_EDITION
            }
        end
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_black')) then
            card:start_dissolve()
        end
        if not next(SMODS.find_card('j_sbeven_clars')) then
            card:start_dissolve()
        end -- turn this back on some other time
    end,
    
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "?????",          -- Text displayed on the badge
            G.C.BLACK,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,

}

SMODS.Joker{ -- Black Aura Quartz (Black Pearl and Carbonado Fusion)
    key = 'aura',
    loc_txt = {
        name = '{C:dark_edition,E:1,s:1.75}Black Aura Quartz{}', -- name of joker
        text = {
            'Grants the {C:attention}ability{} to make playing cards into {C:attention}stone{} cards.',
            'Each played {C:attention}stone{} card gives',
            '{X:chips,C:white}X#1#{} & {C:white,X:dark_edition}^#2#{} Chips when scored.',
            'Gains {C:white,X:dark_edition}^#5#{} Chips per {C:attention}stone{} card in deck.',
            '{C:attention}Stone{} cards also give {C:white,X:money}$#4#{} when scored.',
            '{C:inactive}Currently {C:white,X:dark_edition}^#3#{} {C:inactive}Chips.',
            '{C:dark_edition,s:0.8,E:1}A fusion of Black Diamond and her Pearl.',
            '{C:legendary,s:0.7,E:1}- From \"Carbonado\'s Lore\" by artifiziell{}',
        },
    },
    atlas = 'Aura',
    rarity = 'sbeven_Fusion', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 177,
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    pos = {x = 0, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right 
    credit = {
        art = "artifiziell",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = { 
        extra = { 
            card_limit = 5,
            xchips = 7,
            e_chips = 1.2,
            e_chips_gain = 0.2, -- configurable value
            dollars = 7,

        }
    },
    loc_vars = function (self, info_queue, card)
        info_queue[#info_queue + 1] = G.P_CENTERS.m_stone
        local stone_tally = 0
        if G.playing_cards then
            for _, playing_card in ipairs(G.playing_cards) do
                if SMODS.has_enhancement(playing_card, 'm_stone') then stone_tally = stone_tally + 1 end
            end
        end
        return {vars = {
            card.ability.extra.xchips,
            card.ability.extra.e_chips,
            1 + (card.ability.extra.e_chips_gain * stone_tally),
            card.ability.extra.dollars,
            card.ability.extra.e_chips_gain
        }
    } --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
    calculate = function(self, card, context)
        if context.joker_main then
            local stone_tally = 0
            for _, playing_card in ipairs(G.playing_cards) do
                if SMODS.has_enhancement(playing_card, 'm_stone') then stone_tally = stone_tally + 1 end
            end
            return {
                e_chips = 1 + (card.ability.extra.e_chips_gain * stone_tally)
            }
        end
        if context.individual
        and context.cardarea == G.play 
        and SMODS.has_enhancement(context.other_card, 'm_stone') then
            G.GAME.dollar_buffer = (G.GAME.dollar_buffer or 0 ) + card.ability.extra.dollars
            return {
                message = '...',
                xchips = card.ability.extra.xchips,
                e_chips = card.ability.extra.e_chips,
                colour = G.C.DARK_EDITION,
                dollars = card.ability.extra.dollars,
                func = function ()
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            G.GAME.dollar_buffer = 0
                            return true
                        end
                    }))
                end
            }
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                    SMODS.add_card{ key = "c_sbeven_mural", stickers = {"eternal"} }
                    return true
                end
            }))
        end
    end,

    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_aura' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,    
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_aura')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
                G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
                SMODS.add_card{ key = "c_sbeven_mural", stickers = {"eternal"} }
                --SMODS.add_card{ key = "j_sbeven_black_pearl" }
                return true
            end
        }))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_mural')) do
            bm:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.Joker{ -- Blue Aura Quartz
    key = 'blue_aura',
    loc_txt = {
        name = '{C:planet,E:1,s:1.75}Blue Aura Quartz{}', -- name of joker
        text = {
            'Each played {C:attention}Ace{} gives {X:dark_edition,C:white}^#1#{} Mult when scored.',
            'Played {C:clubs}Clubs{} cards become {C:red}red{} seal {C:attention}polychrome{} cards.',
            '{C:attention}Retriggers{} held in hand abilities {C:attention}twice{}.',

        },
    },
    atlas = 'BlueAura',
    rarity = 'sbeven_Fusion', -- rarity: 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary
    cost = 177,
    unlocked = true, -- where it is unlocked or not: if true,
    discovered = true, -- whether or not it starts discovered
    blueprint_compat = true, -- can it be blueprinted/brainstormed/other
    eternal_compat = true, -- can it be eternal
    perishable_compat = true, -- can it be perishable
    pos = {x = 0, y = 0}, -- position in atlas, starts at 0, scales by the atlas' card size (px and py): {x = 1, y = 0} would mean the sprite is 71 pixels to the right
    credit = {
        art = "thediamond637",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    config = {
        extra = {
            blue_aura_e_mult = 1.8,
            card_limit = 12,
            slots = 2,
            blue_aura_repetitions = 2,
        }
    },
    loc_vars = function (self, info_queue, card)
        return {vars = {
            card.ability.extra.blue_aura_e_mult,
            card.ability.extra.blue_aura_repetitions
        }} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
    calculate = function(self, card, context)
        if context.repetition 
        and context.cardarea == G.hand 
        and (next(context.card_effects[1]) 
        or #context.card_effects > 1) then
            return {
                repetitions = card.ability.extra.blue_aura_repetitions,
                message = "...",   
                colour  = G.C.DARK_EDITION
            }
        end
        if context.before and context.main_eval and not context.blueprint then
            local turned = false
            for _, scored_card in ipairs(context.scoring_hand) do
                if scored_card.base.suit == 'Clubs' then
                    turned = true
                    scored_card:set_seal("Red")
                    scored_card:set_edition("e_polychrome")
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            scored_card:juice_up(0.2, 0.2)
                            return true
                        end
                    }))
                end
            end
            if turned then
                return {
                    message = "...",
                    colour = G.C.EDITION,
                }
            end
        end
        if context.individual
        and context.cardarea == G.play then
            if context.other_card:get_id() == 14 then
                return {
                    e_mult = card.ability.extra.blue_aura_e_mult,
                }
            end
        end
        if context.joker_main then
            if context.scoring_name == 'sbeven_The Authority' then
                G.E_MANAGER:add_event(Event({ func = function()
                    SMODS.add_card{ key = 'c_sbeven_Era 3', edition = 'e_negative' }
                    return true
                end }))
                return {
                    e_mult = card.ability.extra.blue_aura_e_mult,
                }
            end
        end
    end,
    in_pool = function(self, current_shop_jokers, shop_level)
        for _, owned in ipairs(current_shop_jokers or {}) do
            if owned.key == 'j_sbeven_blue_aura' then
                return false, { allow_duplicates = false }
            end
        end
        return true, { allow_duplicates = false }
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_blue_aura')) then
            card:start_dissolve()
        end
        G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.slots
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
                G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.card_limit
                --SMODS.add_card{ key = "c_sbeven_mural", stickers = {"eternal"} }
                return true
            end
        }))
    end,
    remove_from_deck = function(self, card)
        G.jokers.config.card_limit = G.jokers.config.card_limit - card.ability.extra.slots
        G.E_MANAGER:add_event(Event({ func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.card_limit
            return true
        end }))
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

-- Color
loc_colour()
G.ARGS.LOC_COLOURS.sbeven_seppy = HEX('C5CAD3')
SMODS.Joker{
    key = 'seppy',
    loc_txt = {
        name = '{C:spectral}Sepulcher Black Spinel',
        text = {
            'Gains {E:1,C:white,X:dark_edition}^^#2#{} Mult when hand contains',
            'just a single {C:spades}Ace of Spades{}',
            '{C:inactive,E:1}Currently {C:white,X:dark_edition,E:1}^^#1#{} {C:inactive,E:1}Mult',
            '{C:attention}Once per round{}, grants an {C:dark_edition}ability card{}.',
            '{C:sbeven_seppy,E:1,s:0.8}\"How many moons until I find my path again?\"'
        }
    },
    atlas = 'Seppy',
    rarity = 'sbeven_AGem',
    cost = 250,
    unlocked = true,
    discovered = true,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    post = { x = 0, y = 0},
    credit = {
        art = ".firsttry.",
        code = "Pink Focalors",
        concept = ".firsttry."
    },
    config = {
        extra = {
            seppy_mult = 1,
            seppy_gain = 1,
        }
    },
    loc_vars = function(self, info_queue, card)
        return {vars = {
            card.ability.extra.seppy_mult, 
            card.ability.extra.seppy_gain,
        }}
    end,
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if #context.full_hand == 1
            and context.full_hand[1]:get_id() == 14
            and context.other_card:is_suit("Spades") then
                card.ability.extra.seppy_mult = card.ability.extra.seppy_mult + card.ability.extra.seppy_gain
                return {
                    message_card = card,
                    message = localize('k_upgrade_ex')
                }
            end
        end
        local seppy = seppy_quotes[ math.random(#seppy_quotes) ]
        if context.joker_main then
           return {
                ee_mult = card.ability.extra.seppy_mult,
                message_card = card,
                message = seppy
            }
        end
        if context.setting_blind then
            G.E_MANAGER:add_event(Event({
                delay = 0,
                func = function()
                SMODS.add_card{ key = "c_sbeven_thunder_arm", stickers = {"eternal"} }
                return true
            end}))
        end
    end,
    in_pool = function()
        return true
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff and next(SMODS.find_card('j_sbeven_seppy')) then
            card:start_dissolve()
        end
        G.E_MANAGER:add_event(Event({
            delay = 0,
            func = function()
            SMODS.add_card{ key = "c_sbeven_thunder_arm", stickers = {"eternal"} }
            return true
        end}))
    end,
    remove_from_deck = function(self, card)
        for _, bm in ipairs(SMODS.find_card('c_sbeven_thunder_arm')) do
            bm:start_dissolve()
        end
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

-------------------------------------------------------------------------------
--Consumables (i greatly apologize for using chatgpt, i was very new to coding at the time but now i am a changed they/them)
-------------------------------------------------------------------------------
SMODS.ConsumableType{
    key             = 'Ability',   -- must match set below
    collection_rows = {5,5},              -- pages in collection UI (optional)
    primary_colour  = G.C.RED,            -- badge background
    secondary_colour= G.C.BLACK,          -- badge outline/text
    loc_txt = {
      collection   = 'Ability Cards',   -- which collection it appears under
      name         = 'Ability',           -- name on the badge
      undiscovered = {
        name = 'Hidden Ability',      -- before it’s discovered
        text = { 'Obtain a Joker with this ability to unlock.' }
      },
    },
    shop_rate = 0    -- never shows up in normal shop
}

SMODS.Consumable{
    key = 'thunder_arm',
    set = 'Ability',
    atlas = 'ThunderArm',
    pos = {x = 0, y = 0},
    loc_txt = {
        name = '{C:spectral}Thundering Arm',
        text = {
            'Converts up to #1# selected cards into',
            '{C:default}Steel {C:spades}Ace of Spades'
        }
    },
    credit = {
        art = ".firsttry.",
        code = "Pink Focalors",
        concept = ".firsttry."
    },
    cost = 6.7,
    config = {
        extra = {
            all_shaking_thunder = 5,
            mod_conv = 'm_steel'
        }
    },
    loc_vars = function(self, info_queue, center)
        return { vars = {
            center.ability.extra.all_shaking_thunder,
            center.ability.extra.mod_conv
        }}
    end,
    use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_steel'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Spades'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        assert(SMODS.change_base(G.hand.highlighted[i], nil, 'Ace'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    keep_on_use = function()
        return false
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_seppy') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_thunder_arm')) then
            card:start_dissolve()
        end  
      end
    end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{ -- Crystal Temple
    key = 'temple',
    set = 'Tarot',
    atlas = 'Temple',
    pos = {x = 0, y = 0},
    loc_txt = {
        name = '{C:dark_edition,E:1}Crystal Temple',
        text = {
            '{C:attention}Summon{} a member of the {C:attention}Crystal Gems{}.',
            '{C:inactive}(Must have room){}'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
	use = function(self, card, context, copier)
		local new_card = create_card('Joker', G.jokers, nil, "sbeven_CGem", nil, nil, nil, 'sbeven')
        new_card:add_to_deck()
        G.jokers:emplace(new_card)
        new_card:start_materialize()
        G.GAME.joker_buffer = 0
	end,
	can_use = function(self, card)
		if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
			return true
		else
			return false
		end
	end,
    --[[add_to_deck = function(self, card, from_debuff)
        if not from_debuff then
            if next(SMODS.find_card('c_sbeven_temple')) then
                card:start_dissolve()
            end
        end
    end,]]
    keep_on_use = function() return false end,
    in_pool = function() 
        return true 
    end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{ -- Homeworld
    key = 'homeworld',
    set = 'Spectral',
    atlas = 'Homeworld',
    pos = {x = 0, y = 0},
    loc_txt = {
        name = '{C:dark_edition,E:1}Homeworld',
        text = {
            '{C:attention}Summon{} a {C:dark_edition,E:1}Gem Matriarch{}.',
            '{C:inactive}(Must have room){}'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
	use = function(self, card, context, copier)
		local new_card = create_card('Joker', G.jokers, nil, "sbeven_Diamond", nil, nil, nil, 'sbeven')
        new_card:add_to_deck()
        G.jokers:emplace(new_card)
        new_card:start_materialize()
        G.GAME.joker_buffer = 0
	end,
	can_use = function(self, card)
		if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
			return true
		else
			return false
		end
	end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff then
            if next(SMODS.find_card('c_sbeven_homeworld')) then
                card:start_dissolve()
            end
        end
    end,
    keep_on_use = function() return false end,
    in_pool = function() 
        return true 
    end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'pink_ship',
    set = 'Ability',
    atlas = 'DiamondShips',
    pos = {x = 1, y = 1},
    loc_txt = {
        name = '{C:hearts,E:1}Pink Diamond\'s Ship',
        text = {
            'Select up to {C:attention}#1#{} playing cards.',
            'All selected cards become',
            '{C:red}Red{} seal {C:hearts}Hearts{}.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 4
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 4 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Red", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Hearts'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 4)
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff then
            if #SMODS.find_card('j_sbeven_pink') == 0 then
                card:start_dissolve()
            end
            if next(SMODS.find_card('c_sbeven_pink_ship')) then
                card:start_dissolve()
            end
        end
    end,

    keep_on_use = function() return false end,
    in_pool      = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'yellow_ship',
    set = 'Ability',
    atlas = 'DiamondShips',
    pos = {x = 3, y = 1},
    loc_txt = {
        name = '{C:diamonds,E:1}Yellow Diamond\'s Ship',
        text = {
            'Select up to {C:attention}#1#{} playing cards.',
            'All selected cards become',
            '{C:gold}Gold{} seal {C:diamonds}Diamonds{}.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 4
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 4 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Gold", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Diamonds'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 4)
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff then
            if #SMODS.find_card('j_sbeven_yellow') == 0 then
                card:start_dissolve()
            end
            if next(SMODS.find_card('c_sbeven_yellow_ship')) then
                card:start_dissolve()
            end
        end
    end,

    keep_on_use = function() return false end,
    in_pool      = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'blue_ship',
    set = 'Ability',
    atlas = 'DiamondShips',
    pos = {x = 7, y = 1},
    loc_txt = {
        name = '{C:planet,E:1}Blue Diamond\'s Ship',
        text = {
            'Select up to {C:attention}#1#{} playing cards.',
            'All selected cards become',
            '{C:planet}Blue{} seal {C:clubs}Clubs{}.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 4
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 4 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Blue", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Clubs'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 4)
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff then
            if #SMODS.find_card('j_sbeven_blue') == 0 then
                card:start_dissolve()
            end
            if next(SMODS.find_card('c_sbeven_blue_ship')) then
                card:start_dissolve()
            end
        end
    end,

    keep_on_use = function() return false end,
    in_pool      = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'white_ship',
    set = 'Ability',
    atlas = 'DiamondShips',
    pos = {x = 5, y = 1},
    loc_txt = {
        name = '{C:edition,E:1}White Diamond\'s Ship',
        text = {
            'Select up to {C:attention}#1#{} playing cards.',
            'All selected cards become',
            '{C:dark_edition}Controlled{} {C:spades}Spades{}.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 4
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 4 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability('m_sbeven_controlled')            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Spades'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 4)
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff then
            if #SMODS.find_card('j_sbeven_white') == 0 then
                card:start_dissolve()
            end
            if next(SMODS.find_card('c_sbeven_white_ship')) then
                card:start_dissolve()
            end
        end
    end,

    keep_on_use = function() return false end,
    in_pool      = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key   = 'blood_money',
    set   = 'Ability',
    atlas = 'bloodM',
    pos   = { x = 0, y = 0 },
  
    loc_txt = {
      name = '{C:tarot}B{C:green}l{C:tarot}o{C:green}o{C:tarot}d{C:green} {C:tarot}M{C:green}o{C:tarot}n{C:green}e{C:tarot}y{}',
      text = {
        '{C:dark_edition,E:1}Destroy{} up to {C:attention}#1#{} selected cards.',
        'Gain {C:white,X:gold,E:1}$#2#{} per use.'
      }
    },
    cost = 1,
    credit = {
        art     = '@yellowpinks',
        code    = 'Pink Focalors',
        concept = '@yellowpinks',
    },
    config = {
      extra = {
        blood_destroy = 5,
        blood_dollar   = 5,
      }
    },
  
    loc_vars = function(self, info_queue, center)
      return { vars = { 
        center.ability.extra.blood_destroy,
        center.ability.extra.blood_dollar
    } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    SMODS.destroy_cards(G.hand.highlighted)
                    return true
                end
            }))
            delay(0.3)
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(5).." $", colour = G.C.MONEY})
                    ease_dollars(5, true)
                    return true
                end
            }))
            delay(0.6)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    keep_on_use = function(self, card)
      return true
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_blood') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_blood_money')) then
            card:start_dissolve()
        end  
      end
    end,
    
    in_pool = function(self, current_shop_cards, shop_level)
      for _, c in ipairs(current_shop_cards or {}) do
        if c.key == 'c_sbeven_blood_money' then
          return false, { allow_duplicates = false }
        end
      end
      return true, { allow_duplicates = false }
    end,
    calculate = function(self, card, context)
        if context.selling then
            return { sell = 0 }
        end
    end,
    
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
    
}

SMODS.Consumable{
    key = 'bubbled',
    set = 'Ability',
    atlas = 'Bubble',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:hearts}Bubble',
        text = {
            'Applies the {C:hearts}Bubbled{} enhancement',
            'to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 4,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 4 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability("m_sbeven_bubbledE")            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 4)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_pink') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_bubbled')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return true end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'rejuvenator',
    set = 'Ability',
    atlas = 'Rejuvenator',
    pos = { x = 0, y = 0 },
    loc_txt = {
      name = '{C:red}Spinel\'s Rejuvenator{}',
      text = {
        '{C:dark_edition}Rejuvenates{} a selected Joker.',
        'Usable {C:attention}once per round{}.',
        '{C:inactive,s:0.8}(Removes all editions and stickers.){}',
      }
    },
    cost = 10,
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.jokers.highlighted == 1 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.jokers.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.jokers.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.jokers.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.jokers.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.jokers.highlighted[i]:set_edition(nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.jokers.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    G.jokers.highlighted[1].ability.eternal = false
                    G.jokers.highlighted[1].ability.rental = false
                    G.jokers.highlighted[1].ability.perishable = false
                        return true
                    end
                }))
            end
            for i = 1, #G.jokers.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.jokers.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.jokers.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.jokers:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.jokers.highlighted == 1)
    end,
    keep_on_use = function()
        return false 
    end,
    in_pool = function(self, current_shop_cards, shop_level)
        return false, { allow_duplicates = false }
    end,
    add_to_deck = function(self, card, from_debuff)
        if not from_debuff then
          local has_blood = (#SMODS.find_card('j_sbeven_spinel') > 0)
          if not has_blood then
            card:start_dissolve()
          end
          if not from_debuff and next(SMODS.find_card('c_sbeven_rejuvenator')) then
              card:start_dissolve()
          end  
        end
    end,

    -- Optional: Steven Universe badge
    set_badges = function(self, card, badges)
      badges[#badges + 1] = create_badge(
        "Steven Universe",
        G.C.PURPLE,
        G.C.EDITION,
        1
      )
    end,
}

SMODS.Consumable{
    key = 'wand', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'Wand', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:planet,E:1}Aquamarine\'s Wand{}',
        text = { --text of card
            'Changes the {C:attention}suit{} of up to {C:attention}#1#{}',
            'selected playing cards to {C:clubs}Clubs{} suit.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 5
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Clubs'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_aqua') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_wand')) then
            card:start_dissolve()
        end  
      end
    end,
    keep_on_use = function() return false end,
    in_pool      = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'ice', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'Cutlass', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:planet,E:1}Blue{C:mult,E:1}bird\'s{} {C:planet,E:1}Ice Cutlass{}',
        text = { --text of card
            'Select up to {C:attention}#1#{} playing cards.',
            '{C:attention}Every other{} card becomes',
            'a {C:red}Red{} seal {C:clubs}Club{} card.',
            '{C:attention}The rest{} become {C:attention}Lucky{} {C:hearts}Hearts{}.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 5
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,

    can_use = function(self, card)
        -- only in hand or play-draw states, and 1 ≤ highlighted ≤ maxSelected
        local n = #G.hand.highlighted
        return n >= 1
           and n <= card.ability.maxSelected
    end,

    use = function(self, card, area, copier)
        for i, c in ipairs(G.hand.highlighted) do
            local suit = (i % 2 == 1) and "Clubs" or "Hearts"  -- Odd = Clubs, Even = Hearts

            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay   = 0.2 * i,
                func    = function()
                    c:flip()
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.1,
                        func = function()
                            if i % 2 == 1 then
                                c:set_seal("Red")
                            else
                                c:set_ability("m_lucky")
                            end
                            return true
                        end
                    }))
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay   = 0.15,
                        func    = function()
                            SMODS.change_base(c, suit, nil)
                            c:flip()
                            return true
                        end
                    }))
                    return true
                end
            }))
        end

        -- unhighlight afterward
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay   = 0.2 * (#G.hand.highlighted + 1),
            func    = function()
                G.hand:unhighlight_all()
                return true
            end
        }))

        -- delay to keep sequence timing smooth
        delay(0.2 * (#G.hand.highlighted + 2))
    end,

    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_bluebird') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_ice')) then
            card:start_dissolve()
        end  
      end
    end,
    keep_on_use = function() return false end,
    in_pool      = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'steven_shield', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'StevenS', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:hearts,E:1}Steven\'s Shield{}',
        text = { --text of card
            'Changes the {C:attention}suit{} of up to {C:attention}#1#{}',
            'selected playing cards to {C:diamonds}Diamonds{} suit.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 5
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Diamonds'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_steven') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_steven_shield')) then
            card:start_dissolve()
        end  
      end
    end,
    keep_on_use = function() return false end,
    in_pool      = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'connie_sword', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'ConnieW', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:legendary,E:1}Connie\'s Sword{}',
        text = { --text of card
            'Changes the {C:attention}suit{} of up to {C:attention}#1#{}',
            'selected playing cards to {C:spades}Spades{} suit.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 5
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Spades'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_connie') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_connie_sword')) then
            card:start_dissolve()
        end  
      end
    end,
    keep_on_use = function() return false end,
    in_pool      = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'stevonnie_weapons', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'StevonnieW', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:legendary,E:1}Stevonnie\'s{}{C:enhanced,E:1}Sword{}&{C:hearts,E:1}Shield{}',
        text = { --text of card
            'Add the {C:dark_edition}negative{} edition to',
            'up to {C:attention}#1#{} selected playing cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    cost = 10,
    config = {
        extra = {
            cards = 5, --configurable value
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_edition('e_negative', true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    keep_on_use = function() return false    
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_stevonnie') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_stevonnie_weapons')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'ribbon_wand', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'RibbonWand', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:red,E:1}Volleyball\'s Ribbon Wand{}',
        text = { --text of card
            'Changes the {C:attention}suit{} of up to {C:attention}#1#{}',
            'selected playing cards to {C:hearts}Hearts{} suit.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        maxSelected = 5
    },
    loc_vars = function(self, info_queue, card)
        return { vars = { card.ability.maxSelected } }
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                    assert(SMODS.change_base(G.hand.highlighted[i], 'Hearts'))
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_volleyball') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_ribbon_wand')) then
            card:start_dissolve()
        end  
      end
    end,
    keep_on_use = function() return false end,
    in_pool      = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,
}

SMODS.Consumable{
    key = 'drill_wand', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'DrillWand', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:red,E:1}Mega Pearl\'s Ribbon-Drill Wand{}',
        text = { --text of card
            'Applies the {C:attention}polychrome{} edition & {C:attention}glass{} enhancement',
            'to up to {C:attention}#1#{} selected playing cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        extra = {
            cards = 3, --configurable value
        }
    },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 3 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_glass'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_edition('e_polychrome', true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 3)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_mega') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_drill_wand')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'tablet',
    set = 'Ability',
    atlas = 'PeridotT',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:green}Peridot\'s Tablet',
        text = {
            'Applies the {C:attention}Steel{} enhancement',
            'to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 3,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 3 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_steel'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 3)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_peridot') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_tablet')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'yellow_destabilizer',
    set = 'Ability',
    atlas = 'Destabilizer',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:diamonds}Yellow\'s Destabilizer',
        text = {
            'Applies the {C:diamonds}Destabilized{} enhancement',
            'to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 4,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 4 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability('m_sbeven_destabilized')            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 4)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_yellow') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_yellow_destabilizer')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'helmet',
    set = 'Ability',
    atlas = 'JasperH',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:diamonds}Jasper\'s Helmet',
        text = {
            'Applies the {C:diamonds}Destabilized{} enhancement',
            'to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 2,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 2 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability('m_sbeven_destabilized')            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 2)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_jasper') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_helmet')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'spear',
    set = 'Ability',
    atlas = 'PearlS',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:hearts}Pearl\'s Spear',
        text = {
            'Applies the {C:attention}Glass{} enhancement to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 3,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 3 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_glass'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 3)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_pearl') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_spear')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'whip',
    set = 'Ability',
    atlas = 'AmethystW',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:tarot}Amethyst\'s Whip',
        text = {
            'Applies the {C:tarot}Purple{} seal to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 2,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 2 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Purple", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 2)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_amethyst') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_whip')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'arm',
    set = 'Ability',
    atlas = 'RubyG',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:mult}Ruby\'s Gauntlet',
        text = {
            'Applies the {C:red}Red{} seal to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 2,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 2 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Red", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 2)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_ruby') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_arm')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'gaunt',
    set = 'Ability',
    atlas = 'Gauntlets',
    pos = { x = 0, y = 0},
    loc_txt = {
        name = '{C:tarot}Garnet\'s Gauntlets',
        text = {
            'Applies the {C:red}Red{} seal & {C:attention}Lucky{} enhancement',
            'to up to {C:attention}#1#{} selected cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
        art = 'Crewniverse',
        code = 'Pink Focalors',
        concept = 'Pink Focalors',
    },
    config = { extra = { cards = 4,} },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 4 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_lucky'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Red", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 4)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_garnet') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_gaunt')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,
    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'bow', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'OpalB', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:planet,E:1}Opal\'s Bow{}',
        text = { --text of card
            'Applies the {C:attention}steel{} enhancement & {C:blue}blue{} seal',
            'to up to {C:attention}#1#{} selected playing cards.',
            'Usable {C:attention}once per round{}.'
        }
    },
    credit = {
      art = 'Crewniverse',
      code = 'Pink Focalors',
      concept = 'Pink Focalors',
    },
    config = {
        extra = {
            cards = 3, --configurable value
        }
    },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 3 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_steel'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Blue", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 3)
    end,
    keep_on_use = function() return false 
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_opal') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_bow')) then
            card:start_dissolve()
        end  
      end
    end,
    in_pool = function() return false end,

    set_badges = function(self, card, badges)
        badges[#badges+1] = create_badge("Steven Universe", G.C.PURPLE, G.C.EDITION, 1)
    end,
}

SMODS.Consumable{
    key = 'obsidian_sword', --key
    set = 'Ability', --the set of the card: corresponds to a consumable type
    atlas = 'ObsidianSword', --atlas
    pos = {x = 0, y = 0}, --position in atlas
    loc_txt = {
        name = '{C:legendary}O{C:hearts}b{C:planet}s{C:purple}i{C:tarot}d{C:inactive}i{C:legendary}a{C:hearts}n{C:planet}\'{C:purple}s{C:tarot}{C:inactive}G{C:legendary}r{C:hearts}e{C:planet}a{C:purple}t{C:tarot}s{C:inactive}w{C:legendary}o{C:hearts}r{C:planet}d',
        text = { --text of card
            'Applies a {C:attention}Red{} seal, {C:attention}Glass{} enhancement,',
            'and {C:attention}polychrome{} edition to up to {C:attention}#1#{} selected {C:attention}playing cards{}.',
            '{C:inactive,s:0.8,E:1}amazing art by @jasbear.art on TikTok{}'
        }
    },
    credit = {
      art = '@jasbear.art',
      code = 'Pink Focalors',
      concept = '@jasbear.art',
    },
    cost = 100,
    config = {
      extra = {
        cards = 5,
      }
    },
    loc_vars = function(self,info_queue, center)
        return {vars = {center.ability.extra.cards}} --displays configurable value: the #1# in the description is replaced with the configurable value
    end,
use = function(self, card, area, copier)
        local used_card = copier or card
        if #G.hand.highlighted <= 5 then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('tarot1')
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            for i = 1, #G.hand.highlighted do
                local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('card1', percent)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            delay(0.2)
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_ability(G.P_CENTERS['m_glass'])            
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_seal("Red", nil, true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.1,
                    func = function()
                        G.hand.highlighted[i]:set_edition('e_polychrome', true)
                        return true
                    end
                }))
            end
            for i = 1, #G.hand.highlighted do
                local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
                G.E_MANAGER:add_event(Event({
                    trigger = 'after',
                    delay = 0.15,
                    func = function()
                        G.hand.highlighted[i]:flip()
                        play_sound('tarot2', percent, 0.6)
                        G.hand.highlighted[i]:juice_up(0.3, 0.3)
                        return true
                    end
                }))
            end
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.2,
                func = function()
                    G.hand:unhighlight_all()
                    return true
                end
            }))
            delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (#G.hand.highlighted <= 5)
    end,
    keep_on_use = function(self, card)
      return true
    end,
    in_pool = function(self, current_shop_cards, shop_level)
        return false, { allow_duplicates = false }
      end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_obsidian') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_obsidian_sword')) then
            card:start_dissolve()
        end  
      end
    end,
    
    in_pool = function(self, current_shop_cards, shop_level)
      for _, c in ipairs(current_shop_cards or {}) do
        if c.key == 'c_sbeven_obsidian_sword' then
          return false, { allow_duplicates = false }
        end
      end
      return true, { allow_duplicates = false }
    end,
    calculate = function(self, card, context)
        if context.selling then
            return { sell = 0 }
        end
    end,
    
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",
            G.C.PURPLE,
            G.C.EDITION,
            1
        )
    end,

}

SMODS.Back{ 
    object_type = "Back",
    key         = "diamond_deck",
    name        = "Diamonds Deck",
    config      = { ante_scaling = 7.5, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,
    atlas       = "Consumables",
    pos         = { x = 0, y = 0 },

    loc_txt = {
        name = "{C:dark_edition}Diamond Authority Deck",
        text = {
            "All playing cards are of",
            "the {C:diamonds}Diamonds{} suit.",
            "Start with a random joker",
            "of {C:dark_edition}Diamond{} rarity.",
            "{C:inactive}99.9% chance of Diamond.",
            "{C:inactive}0.1% of Carbonado.",
            "{C:white,X:mult}X7.5{} base Blind Size.",
            "{C:inactive}Idea by: Pink Focalors"
        }
    },
	apply = function(self)
		G.E_MANAGER:add_event(Event({
			func = function()
				for _, card in ipairs(G.playing_cards) do
					if card:is_suit("Hearts") then
						assert(SMODS.change_base(card, "Diamonds"))
					end
					if card:is_suit("Spades") then
						assert(SMODS.change_base(card, "Diamonds"))
					end
					if card:is_suit("Clubs") then
						assert(SMODS.change_base(card, "Diamonds"))
					end
				end
				return true
		   	end
		}))
        G.E_MANAGER:add_event(Event({
            func = function()
                if not G.jokers then return true end

                local roll = love.math.random()
                local choice = (roll < 0.001)
                    and "sbeven_Unobtainable"
                    or "sbeven_Diamond"

                local jcard = create_card(
                    "Joker",
                    G.jokers,
                    nil,
                    choice,
                    nil, nil, nil,
                    "j_" .. choice:lower()
                )

                jcard:add_to_deck()
                jcard:start_materialize()
                G.jokers:emplace(jcard)
                return true
            end
        }))
	end,
    unlocked   = true,
    discovered = true,

}

SMODS.Back{ 
    object_type = "Back",  
    key         = "quartizine_deck",  
    name        = "Quartizine Deck",            -- what shows on the deck‐select screen
    config      = { ante_scaling = 3, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,
    atlas       = "Cluster",        
    pos         = { x = 0, y = 0 },             

    -- ─── localization & description ───────────────────────────────
    loc_txt = {
        name = "{C:dark_edition}Quartizine Deck",
        text = {
            "Start off with a random joker",
            "of {C:legendary}Gem{} or ",
            "{C:legendary}Crystal Gem{} rarity.",
            "{C:white,X:mult}X3{} base Blind Size.",
            "{C:inactive}Idea by: Pink Focalors"
      }
    },
    -- ────────────────────────────────────────────────────────────────

    apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                if not G.jokers then return true end

                local pool   = { "sbeven_Gem", "sbeven_CGem", "sbeven_Hidden2" }
                local choice = pool[ math.random(#pool) ]

                local card = create_card(
                    "Joker",         
                    G.jokers,        
                    nil,             
                    choice,          
                    nil, nil, nil,   
                    "j_" .. choice:lower()
                )

                card:add_to_deck()
                card:start_materialize()
                G.jokers:emplace(card)
                return true
            end
        }))
    end,
    unlocked   = true,
    discovered = true,

}

SMODS.Back{ 
    object_type = "Back",  
    key         = "fusion_deck",  
    name        = "Fusion Deck",            -- what shows on the deck‐select screen
    config      = { ante_scaling = 3, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,
    atlas       = "Obsidian",        
    pos         = { x = 0, y = 0 },             

    -- ─── localization & description ───────────────────────────────
    loc_txt = {
        name = "{C:dark_edition}Fusions Deck",
        text = {
            "Start off with a random",
            "{C:dark_edition}Fusion{} joker.",
            "{C:inactive,s:0.8}No Corrupted Fusions.",
            "{C:white,X:mult}X3{} base Blind Size.",
            "{C:inactive}Idea by: Pink Focalors"
      }
    },
    -- ────────────────────────────────────────────────────────────────

    apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                if not G.jokers then return true end

                local pool   = { "sbeven_Fusion", "sbeven_UFusion", "sbeven_Hidden2", "sbeven_PFusion" }
                local choice = pool[ math.random(#pool) ]

                local card = create_card(
                    "Joker",         
                    G.jokers,        
                    nil,             
                    choice,          
                    nil, nil, nil,   
                    "j_" .. choice:lower()
                )

                card:add_to_deck()
                card:start_materialize()
                G.jokers:emplace(card)
                return true
            end
        }))
    end,
    unlocked   = true,
    discovered = true,

}

SMODS.Back{ 
    object_type = "Back",  
    key         = "blue_pearl_deck",  
    name        = "Blue Pearl Deck",            -- what shows on the deck‐select screen
    config      = { ante_scaling = 4, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,
    atlas       = "DiamondShips",        
    pos         = { x = 2, y = 0 },             

    -- ─── localization & description ───────────────────────────────
    loc_txt = {
        name = "{C:dark_edition}Deck of Pearls",
        text = {
            "All cards in deck are",
            "{C:attention}Bubbled{} {C:clubs}Club{} cards.",
            "Start off with all {C:attention}Pearls{}.",
            "{C:white,X:mult}X4{} base Blind Size.",
            "{C:inactive}Idea by: Pink Focalors"
      }
    },
    -- ────────────────────────────────────────────────────────────────

    apply = function(self)
        G.E_MANAGER:add_event(Event({
          func = function()
            if not G.jokers then return true end
      
            -- ALWAYS spawn exactly those two Jokers by key:
            local keys = { 
            "j_sbeven_blue_pearl",
            "j_sbeven_yellow_pearl",
            --"j_sbeven_lonely_pearl",
            "j_sbeven_pearl",
            "j_sbeven_volleyball" }  -- replace with your two
            for _, key in ipairs(keys) do
              local card = SMODS.add_card{
                key      = key,
                location = G.jokers,
                set      = true
              }
              if card then
                card:start_materialize()
              end
            end
      
            return true
          end
        }))
        G.E_MANAGER:add_event(Event({
            trigger  = 'after',
            delay    = 0,
            blocking = false,
            func     = function()
        -- apply Lucky enhancement to all playing cards
                local cards = G.playing_cards or G.GAME.cards
                if not cards then return true end
                for _, card in ipairs(cards) do
            -- use card:set_ability if enhancement uses ability API
                    if card.set_ability then
                        card:set_ability("m_sbeven_bubbledE")
                    elseif card.add_enhancement then
                        card:add_enhancement("m_sbeven_bubbledE")
                    elseif SMODS.add_enhancement then
                        SMODS.add_enhancement{ key = "m_sbeven_bubbledE", card = card }
                    end
                    card:start_materialize()
                end
            return true
        end
        }))
        G.E_MANAGER:add_event(Event({
            trigger  = 'immediate',
            func = function()
                for _, card in ipairs(G.playing_cards) do
					if card:is_suit("Hearts") then
						assert(SMODS.change_base(card, "Clubs"))
					end
					if card:is_suit("Spades") then
						assert(SMODS.change_base(card, "Clubs"))
					end
					if card:is_suit("Diamonds") then
						assert(SMODS.change_base(card, "Clubs"))
					end
                end
                return true
            end
        }))
    end,
    unlocked   = true,
    discovered = true,
}

SMODS.Back{ 
    object_type = "Back",  
    key         = "unstable_deck",  
    name        = "Unstable Deck",            -- what shows on the deck‐select screen
    config      = { ante_scaling = 3, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,
    atlas       = "Destabilizer",        
    pos         = { x = 0, y = 0 },             

    -- ─── localization & description ───────────────────────────────
    loc_txt = {
        name = "{C:dark_edition}Unstable Deck",
        text = {
            "All cards in deck are",
            "{C:attention}Destabilized{} cards.",
            "Start off with a random",
            "{C:attention}Unstable Fusion{} joker.",
            "{C:white,X:mult}X3{} base Blind Size.",
            "{C:inactive}Idea by: Pink Focalors"
      }
    },
    -- ────────────────────────────────────────────────────────────────

    apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                if not G.jokers then return true end

                local pool   = { "sbeven_UFusion", "sbeven_Hidden2" }
                local choice = pool[ math.random(#pool) ]

                local card = create_card(
                    "Joker",         
                    G.jokers,        
                    nil,             
                    choice,          
                    nil, nil, nil,   
                    "j_" .. choice:lower()
                )

                card:add_to_deck()
                card:start_materialize()
                G.jokers:emplace(card)
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            trigger  = 'after',
            delay    = 0,
            blocking = false,
            func     = function()
        -- apply Lucky enhancement to all playing cards
                local cards = G.playing_cards or G.GAME.cards
                if not cards then return true end
                for _, card in ipairs(cards) do
            -- use card:set_ability if enhancement uses ability API
                    if card.set_ability then
                        card:set_ability("m_sbeven_destabilized")
                    elseif card.add_enhancement then
                        card:add_enhancement("m_sbeven_destabilized")
                    elseif SMODS.add_enhancement then
                        SMODS.add_enhancement{ key = "m_sbeven_destabilized", card = card }
                    end
                    card:start_materialize()
                end
            return true
        end
        }))
    end,
    unlocked   = true,
    discovered = true,
}

SMODS.Back{ 
    object_type = "Back",
    key         = "stevonnie_deck",
    name        = "Stevonnie Deck",
    config      = { ante_scaling = 2, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,
    atlas       = "StevonnieW",
    pos         = { x = 0, y = 0 },

    loc_txt = {
        name = "{C:dark_edition}Stevonnie's Deck",
        text = {
            "Deck contains {C:attention}26{} {C:spades}Spades{} and",
            "{C:attention}26{} {C:diamonds}Diamonds{}.",
            "Start with {C:hearts}Steven{} & {C:spades}Connie{}.",
            "{C:white,X:mult}X2{} base Blind Size.",
            "{C:inactive}Idea by: Pink Focalors"
        }
    },

    apply = function(self)
        -- Convert Hearts→Spades and Clubs→Diamonds
        G.E_MANAGER:add_event(Event({
            trigger  = 'immediate',
            func = function()
                for _, card in ipairs(G.playing_cards) do
                    if card:is_suit("Hearts") then
                        assert(SMODS.change_base(card, "Spades"))
                    elseif card:is_suit("Clubs") then
                        assert(SMODS.change_base(card, "Diamonds"))
                    end
                end
                return true
            end
        }))

        -- Spawn either Steven or Connie as the starting Joker
        G.E_MANAGER:add_event(Event({
          func = function()
            if not G.jokers then return true end
      
            -- ALWAYS spawn exactly those two Jokers by key:
            local keys = { "j_sbeven_connie", "j_sbeven_steven" }  -- replace with your two
            for _, key in ipairs(keys) do
              local card = SMODS.add_card{
                key      = key,
                location = G.jokers,
                set      = true
              }
              if card then
                card:start_materialize()
              end
            end
      
            return true
          end
        }))
    end,
    unlocked   = true,
    discovered = true,

}


SMODS.Back{
    object_type = "Back",
    key         = "emerald_deck",  
    config      = { all_sevens = '7', ante_scaling = 3, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,
    name        = "Fanfic Deck",

    loc_txt = {
        name = "{C:dark_edition}Lapidot Deck",
        text = {
            "All cards in deck are {C:attention}7s{}.",
            "Start off with {C:blue}Lapis{} & {C:green}Peridot{}.",
            "{C:white,X:mult}X3{} base Blind Size.",
            "{C:inactive}Idea by: tenmei_kak"
        }
    },

    atlas = "Jokers",
    pos   = { x = 2, y = 0 },

    apply = function(self)
        G.E_MANAGER:add_event(Event({
          func = function()
            if not G.jokers then return true end
      
            -- ALWAYS spawn exactly those two Jokers by key:
            local keys = { "j_sbeven_lapis", "j_sbeven_peridot" }  -- replace with your two
            for _, key in ipairs(keys) do
              local card = SMODS.add_card{
                key      = key,
                location = G.jokers,
                set      = true
              }
              if card then
                card:start_materialize()
              end
            end
      
            return true
          end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                for _, card in ipairs(G.playing_cards) do
                    assert(SMODS.change_base(card, nil, self.config.all_sevens))
                end
                return true
            end
        }))
    end,
        
    unlocked   = true,
    discovered = true,
}

SMODS.Back{
    object_type = "Back",
    key         = "off_color_deck",  
    name        = "Stars Deck",
    config      = { ante_scaling = 2.5, vouchers = { 'v_overstock_norm', 'v_overstock_plus', 'v_money_tree', 'v_reroll_surplus' } },
    loc_vars = function(self, info_queue, back)
        return {
            vars = { localize { type = 'name_text', key = self.config.vouchers[1], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[2], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[3], set = 'Voucher' },
                localize { type = 'name_text', key = self.config.vouchers[4], set = 'Voucher' }
            }
        }
    end,

    loc_txt = {
        name = "{C:dark_edition}Off-Color Deck",
        text = {
            "Start off with {C:legendary}Captain Lars{}.",
            "{C:white,X:mult}X2.5{} base Blind Size.",
            "{C:inactive}Idea by: Pink Focalors"
        }
    },

    atlas = "CLars",
    pos   = { x = 0, y = 0 },

    apply = function(self)
        G.E_MANAGER:add_event(Event({
          func = function()
            if not G.jokers then return true end
      
            -- ALWAYS spawn exactly Moonstone by key:
            local card = SMODS.add_card{
              key      = "j_sbeven_clars", -- your Joker’s key
              location = G.jokers,              -- Joker row
              set      = true                   -- auto-add_to_deck()
            }
      
            if card then
              card:start_materialize()
            end
      
            return true
          end
        }))
      end,
            

    unlocked   = true,
    discovered = true,
}

SMODS.PokerHand{
    key = 'QuartzHand',
    chips = 300,
    mult = 5,
    l_chips = 50,
    l_mult = 1,
    example = {
        { 'S_7', true, enhancement = 'm_stone' },
        { 'S_7', true, enhancement = 'm_stone' },
        { 'S_7', true, enhancement = 'm_stone' },
        { 'S_7', true, enhancement = 'm_stone' },
        { 'S_7', true, enhancement = 'm_stone' },
    },
    loc_txt = {
        ['en-us'] = {
            name = 'Quartizine Quintuplet',
            description = {
                '5 stone cards.',
            }
        }
    },
    evaluate = function(parts, hand)
        -- only trigger on full 5-card hands
        if #hand < 5 then
            return {}
        end

        -- count how many cards have the stone enhancement
        local stone_count = 0
        for _, c in ipairs(hand) do
            if SMODS.has_enhancement(c, 'm_stone') then
                stone_count = stone_count + 1
            end
        end

        -- return the full hand if *all* 5 are stone
        if stone_count == 5 then
            return { hand }
        end

        return {}
    end,
}

SMODS.Atlas{ key = 'QuartzHandPlanet', path = 'QuartzPlanet.png', px = 71, py = 95 }

SMODS.Consumable{
    set = 'Planet',
    key = 'QuartzPlanet',
    config = { hand_type = 'sbeven_QuartzHand' },
    pos = {x = 0, y = 0 },
    atlas = 'QuartzHandPlanet',
    credit = {
        art = "Crewniverse",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    cost = 15,
    set_card_type_badge = function(self, card, badges)
        badges[1] = create_badge(localize('k_planet_q'), get_type_colour(self or card.config, card), nil, 1.2)
    end,
    process_loc_text = function(self)
        --use another planet's loc txt instead
        local target_text = G.localization.descriptions[self.set]['c_mercury'].text
        SMODS.Consumable.process_loc_text(self)
        G.localization.descriptions[self.set][self.key].text = target_text
    end,
    generate_ui = 0,
    loc_txt = {
        ['en-us'] = {
            name = 'Kindergarten Quartz',
        }
    },
        -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

SMODS.PokerHand {
    key = 'The Authority',
    chips = 75,
    mult = 7.5,
    l_chips = 25,
    l_mult = 2.5,
    example = {
        { 'S_5', true },
        { 'H_9', true },
        { 'C_2', true },
        { 'D_K', true },
        --{ 'H_1', false}
    },
    loc_txt = {
        ['en-us'] = {
            name = 'The Authority',
            description = {
                '4 cards each with a different suit.',
                'Ranks do not matter.',
                'All Steven Universe Joker abilities',
                'that require specific hands',
                'will be triggered by The Authority.'
            }
        }
    },
    evaluate = function(parts, hand)
        -- Ensure exactly 4 cards in hand
        if #hand == 4 then
            local suits = {}
            for _, card in ipairs(hand) do
                suits[card.base.suit] = true
            end
            -- Count unique suits
            local unique_suits = 0
            for _ in pairs(suits) do unique_suits = unique_suits + 1 end

            if unique_suits == 4 then
                return {hand}
            end
        end
    end,
}

SMODS.Atlas{ key = 'Era3 Planet', path = 'Era3 Planet.png', px = 71, py = 95 }

SMODS.Consumable {
    set = 'Planet',
    key = 'Era 3',
    --! `h_` prefix was removed
    config = { hand_type = 'sbeven_The Authority' },
    pos = {x = 0, y = 0 },
    atlas = 'Era3 Planet',
    credit = {
        art = "u/TheTophatDemon",
        code = "Pink Focalors",
        concept = "Pink Focalors"
    },
    cost = 12,
    set_card_type_badge = function(self, card, badges)
        badges[1] = create_badge(localize('k_planet_q'), get_type_colour(self or card.config, card), nil, 1.2)
    end,
    process_loc_text = function(self)
        --use another planet's loc txt instead
        local target_text = G.localization.descriptions[self.set]['c_mercury'].text
        SMODS.Consumable.process_loc_text(self)
        G.localization.descriptions[self.set][self.key].text = target_text
    end,
    generate_ui = 0,
    loc_txt = {
        ['en-us'] = {
            name = 'Diamond Authority'
        }
    },
    -- Add the "UNIVERSE" badge at the bottom of the card
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end,
}

--[[SMODS.Consumable {
    set = "Spectral",
    key = "diamondseal_card",
	config = {
        -- How many cards can be selected.
        max_highlighted = 1,
        -- the key of the seal to change to
        extra = 'sbeven_diamond_seal',
    },
    loc_vars = function(self, info_queue, card)
        -- Handle creating a tooltip with seal args.
        info_queue[#info_queue+1] = G.P_SEALS[(card.ability or self.config).extra]
        -- Description vars
        return {vars = {(card.ability or self.config).max_highlighted}}
    end,
    loc_txt = {
        name = '{C:edition}Authority',
        text = {
            "Select {C:attention}#1#{} playing card and",
            "apply a {C:dark_edition}Diamond Seal{}."
        }
    },
    cost = 4,
    atlas = "Consumables",
    pos = {x=0, y=0},
    use = function(self, card, area, copier)
        for i = 1, math.min(#G.hand.highlighted, card.ability.max_highlighted) do
            G.E_MANAGER:add_event(Event({func = function()
                play_sound('tarot1')
                card:juice_up(0.3, 0.5)
                return true end }))
            
            G.E_MANAGER:add_event(Event({trigger = 'after',delay = 0.1,func = function()
                G.hand.highlighted[i]:set_seal(card.ability.extra, nil, true)
                return true end }))
            
            delay(0.5)
        end
        G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.2,func = function() G.hand:unhighlight_all(); return true end }))
    end,
    add_to_deck = function(self, card, from_debuff)
      if not from_debuff then
        local has_blood = (#SMODS.find_card('j_sbeven_white') > 0)
        if not has_blood then
          card:start_dissolve()
        end
        if not from_debuff and next(SMODS.find_card('c_sbeven_diamondseal_card')) then
            card:start_dissolve()
        end  
      end
    end,
}

SMODS.Seal {
    name = "Diamond_Seal",
    key = "diamond_seal",
    badge_colour = HEX("1d4fd7"),
	config = { mult = 5, chips = 2, money = 5, x_mult = 2  },
    loc_txt = {
        -- Badge name (displayed on card description when seal is applied)
        label = 'Diamond Seal',
        -- Tooltip description
        name = 'Diamond Seal',
        text = {
            '{X:mult,C:white}X#4#{} Mult',
            '{X:chips,C:white}X#2#{} Chips',
            '{C:money}$#3#{}',
        }
    },
    loc_vars = function(self, info_queue)
        return { vars = {self.config.mult, self.config.chips, self.config.money, self.config.x_mult, } }
    end,
    atlas = "modicon",
    pos = {x=0, y=0},

    -- self - this seal prototype
    -- card - card this seal is applied to
    calculate = function(self, card, context)
        -- main_scoring context is used whenever the card is scored
        if context.main_scoring and context.cardarea == G.play then
            return {
                mult = self.config.mult,
                x_chips = self.config.chips,
                dollars = self.config.money,
                x_mult = self.config.x_mult
            }
        end
    set_badges = function(self, card, badges)
        badges[#badges + 1] = create_badge(
            "Steven Universe",          -- Text displayed on the badge
            G.C.PURPLE,          -- Badge background color
            G.C.EDITION,           -- Text color
            1                    -- Scaling factor (default size)
        )
    end
end
}]]

----------------------------------------------
------------MOD CODE END----------------------
    
