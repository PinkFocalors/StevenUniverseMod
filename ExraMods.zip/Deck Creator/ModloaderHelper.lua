local ModloaderHelper = {}

ModloaderHelper.DeckCreatorLoader = false
ModloaderHelper.BalamodLoaded = false
ModloaderHelper.SteamoddedLoaded = false
ModloaderHelper.ModsMenuOpenedBy = nil

return ModloaderHelper
